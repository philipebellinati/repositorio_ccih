import type { ProtocolRule } from '@/domain/types'
import { CRITERIO_MACROLIDEO_PEDIATRICO } from '../criterios'

/**
 * 6.3 — INFECÇÕES COMUNITÁRIAS, PEDIATRIA (página 3 do protocolo).
 *
 * NOTA ³ (crítica para a segurança do cálculo): salvo indicação explícita de
 * "/dia", todos os valores em mg/kg são DOSE POR ADMINISTRAÇÃO, não dose diária.
 * Por isso `base: 'dose'` é o padrão e `base: 'dia'` aparece apenas onde o
 * protocolo escreve "/dia" (Azitromicina e Gentamicina).
 */
export const SECAO_6_3: readonly ProtocolRule[] = [
  // --- Pneumonia -----------------------------------------------------------
  {
    id: '6.3.pneumonia.aspirativa',
    secao: '6.3',
    focoId: 'pneumonia',
    condicaoLabel: 'Aspirativa',
    prioridade: 20,
    match: (m) => m.aspirativa === true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
      {
        drugId: 'clindamicina',
        dosePonderal: { valor: [7.5, 10], unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ceftriaxona 50mg/kg EV 12/12h + Clindamicina 7,5-10mg/kg EV 6/6h',
  },
  {
    id: '6.3.pneumonia.1a',
    secao: '6.3',
    focoId: 'pneumonia',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
      {
        drugId: 'azitromicina',
        // Única entrada pediátrica em mg/kg/DIA — o protocolo grafa "10mg/kg/dia".
        dosePonderal: { valor: 10, unidade: 'mg/kg', base: 'dia' },
        via: 'EV/VO',
        intervalo: 'q24h',
        facultativo: true,
        criterioFacultativo: CRITERIO_MACROLIDEO_PEDIATRICO,
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ceftriaxona 50mg/kg EV 12/12h +/- Azitromicina 10mg/kg/dia EV/VO 1x/dia',
  },

  // --- ITU -----------------------------------------------------------------
  {
    id: '6.3.itu.complicada',
    secao: '6.3',
    focoId: 'itu',
    condicaoLabel: 'Uso de ATB prévio / ITU de repetição',
    prioridade: 10,
    match: (m) => m.atbPrevio === true || m.ituRecorrente === true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
          observacoes: [
            'mg/kg calculado APENAS sobre o componente piperacilina (proporção 8:1). ' +
            'Bula: 100 mg/kg/dose de piperacilina a cada 6 ou 8 h em > 9 meses; ' +
            '80 mg/kg/dose a cada 8 h entre 2 e 9 meses. Máximo 24 g/dia. ' +
            'Acima de 40 kg, usar dose de adulto.',
          ],
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Piperacilina/tazobactam 75mg/kg EV 6/6h',
  },
  {
    id: '6.3.itu.1a',
    secao: '6.3',
    focoId: 'itu',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ceftriaxona 50mg/kg EV 12/12h',
  },

  // --- Infecção abdominal --------------------------------------------------
  {
    id: '6.3.abdominal.2a',
    secao: '6.3',
    focoId: 'abdominal',
    condicaoLabel: '2ª opção',
    prioridade: 10,
    match: (m) => m.segundaOpcao === true,
    prescricoes: [
      {
        drugId: 'ampicilina',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
      {
        drugId: 'gentamicina',
        dosePonderal: { valor: [5, 7], unidade: 'mg/kg', base: 'dia' },
        via: 'EV',
        intervalo: 'q24h',
      },
      {
        drugId: 'metronidazol',
        dosePonderal: { valor: [7.5, 10], unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
    ],
    notas: ['n3'],
    textoOriginal:
      'Ampicilina 50mg/kg EV 6/6h + Gentamicina 5-7mg/kg/dia + Metronidazol 7,5-10mg/kg EV 6/6h',
  },
  {
    id: '6.3.abdominal.1a',
    secao: '6.3',
    focoId: 'abdominal',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
      {
        drugId: 'metronidazol',
        dosePonderal: { valor: [7.5, 10], unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ceftriaxona 50mg/kg EV 12/12h + Metronidazol 7,5-10mg/kg EV 6/6h',
  },

  // --- Pele e partes moles -------------------------------------------------
  {
    id: '6.3.pele.necrose',
    secao: '6.3',
    focoId: 'pele_partes_moles',
    condicaoLabel: 'Com necrose',
    prioridade: 10,
    match: (m) => m.necrose === true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
      {
        drugId: 'clindamicina',
        dosePonderal: { valor: [7.5, 10], unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ceftriaxona 50mg/kg EV 12/12h + Clindamicina 7,5-10mg/kg EV 6/6h',
  },
  {
    id: '6.3.pele.sem-necrose',
    secao: '6.3',
    focoId: 'pele_partes_moles',
    condicaoLabel: 'Sem necrose',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'oxacilina',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Oxacilina 50mg/kg EV 6/6h',
  },

  // --- Sepse sem foco ------------------------------------------------------
  {
    id: '6.3.sepse.1a',
    secao: '6.3',
    focoId: 'sepse_sem_foco',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ceftriaxona 50mg/kg EV 12/12h',
  },

  // --- Meningite bacteriana ------------------------------------------------
  {
    id: '6.3.meningite.1a',
    secao: '6.3',
    focoId: 'meningite',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
      {
        drugId: 'vancomicina',
        via: 'EV',
        intervalo: 'q6h',
        facultativo: true,
        // A nota ⁴ é MAIS forte que o "+/-" da tabela: em < 5 anos ela determina
        // a associação. O motor promove este item a obrigatório nesse caso.
        criterioFacultativo:
          'Nota ⁴: em menores de 5 anos, ASSOCIAR Vancomicina ao tratamento ' +
          'empírico inicial (resistência do S. pneumoniae, sorotipo 19A). ' +
          'Suspender apenas após confirmação laboratorial de sensibilidade.',
      },
      {
        drugId: 'dexametasona',
        dosePonderal: { valor: 0.15, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'Duração de 4 dias.',
          'Administrar 10 a 20 min ANTES da primeira dose do antibiótico, ou junto.',
        ],
      },
    ],
    notas: ['n1', 'n3', 'n4'],
    textoOriginal:
      'Ceftriaxona 50mg/kg EV 12/12h +/- Vancomicina¹ + Dexametasona 0,15mg/kg EV 6/6h por 4 dias',
  },

  // --- Endocardite aguda ---------------------------------------------------
  {
    id: '6.3.endocardite.aguda',
    secao: '6.3',
    focoId: 'endocardite',
    condicaoLabel: 'Aguda',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
      {
        drugId: 'oxacilina',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
      {
        drugId: 'gentamicina',
        dosePonderal: { valor: [5, 7], unidade: 'mg/kg', base: 'dia' },
        via: 'EV',
        intervalo: 'q24h',
      },
    ],
    notas: ['n3'],
    textoOriginal:
      'Ceftriaxona 50mg/kg EV 12/12h + Oxacilina 50mg/kg EV 6/6h + Gentamicina 5-7mg/kg/dia',
  },

  // --- Infecção óssea / articular ------------------------------------------
  {
    id: '6.3.osteoarticular.1a',
    secao: '6.3',
    focoId: 'osteoarticular',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'ceftriaxona',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q12h',
      },
      {
        drugId: 'clindamicina',
        dosePonderal: { valor: [7.5, 10], unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ceftriaxona 50mg/kg EV 12/12h + Clindamicina 7,5-10mg/kg EV 6/6h',
  },
]
