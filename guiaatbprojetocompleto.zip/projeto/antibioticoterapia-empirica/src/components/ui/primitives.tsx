import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'
import type { Severidade } from '@/domain/types'

/**
 * Primitivas visuais do guia. Deliberadamente pequenas e sem dependência de
 * biblioteca de componentes: o guia é distribuído como PWA offline e cada
 * quilobyte de bundle conta no celular do plantonista.
 */

// --- Painel com borda, base de quase toda a interface ----------------------
export function Panel({
  className,
  children,
  id,
}: {
  className?: string
  children: ReactNode
  id?: string
}) {
  return (
    <div id={id} className={cn('rounded-lg border border-border bg-card', className)}>
      {children}
    </div>
  )
}

// --- Célula do painel de fatos-chave (grade 2×2 do topo) -------------------
export function FactCell({
  rotulo,
  children,
  nota,
  className,
}: {
  rotulo: string
  children: ReactNode
  nota?: string
  className?: string
}) {
  return (
    <div className={cn('p-4', className)}>
      <p className="kicker mb-1.5">{rotulo}</p>
      <div className="text-[15px] font-semibold leading-snug text-foreground">{children}</div>
      {nota && <p className="mt-1 text-xs text-muted-foreground">{nota}</p>}
    </div>
  )
}

// --- Chip de filtro (faixa horizontal rolável) -----------------------------
export function Chip({
  ativo,
  onClick,
  children,
}: {
  ativo: boolean
  onClick: () => void
  children: ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={ativo}
      className={cn(
        'shrink-0 whitespace-nowrap rounded-md border px-3.5 py-2 text-xs font-bold uppercase tracking-wider transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        ativo
          ? 'border-primary bg-primary/15 text-primary'
          : 'border-border bg-secondary/60 text-secondary-foreground hover:bg-secondary',
      )}
    >
      {children}
    </button>
  )
}

// --- Botão-pílula de alternância (espelha o "● ALERGIA" da referência) -----
export function TogglePill({
  ativo,
  onClick,
  children,
  title,
}: {
  ativo: boolean
  onClick: () => void
  children: ReactNode
  title?: string
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={ativo}
      title={title}
      className={cn(
        'flex shrink-0 items-center gap-2 rounded-lg border px-4 py-3 text-xs font-bold uppercase tracking-wider transition-colors',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        ativo
          ? 'border-destructive bg-destructive/20 text-destructive-foreground'
          : 'border-border bg-secondary/60 text-muted-foreground hover:bg-secondary',
      )}
    >
      <span
        aria-hidden
        className={cn(
          'h-2 w-2 rounded-full transition-colors',
          ativo ? 'bg-destructive' : 'bg-muted-foreground/60',
        )}
      />
      {children}
    </button>
  )
}

// --- Faixa de título interna dos cards ("QUATRO REGRAS") -------------------
export function BlockHeader({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-t-md bg-accent px-4 py-2.5 text-sm font-bold uppercase tracking-wide text-accent-foreground">
      {children}
    </div>
  )
}

// --- Linha numerada dentro de um bloco -------------------------------------
export function NumberedRow({
  numero,
  titulo,
  children,
}: {
  numero: string
  titulo: string
  children: ReactNode
}) {
  return (
    <div className="border-t border-border px-4 py-3 first:border-t-0">
      <p className="mb-1 text-[11px] font-bold uppercase tracking-wider text-primary">
        {numero} · {titulo}
      </p>
      <div className="text-sm leading-relaxed text-foreground/90">{children}</div>
    </div>
  )
}

// --- Aviso colorido por severidade -----------------------------------------
const ESTILO_SEVERIDADE: Record<Severidade, string> = {
  info: 'border-primary/40 bg-primary/10',
  atencao: 'border-warning/50 bg-warning/10',
  critico: 'border-destructive/50 bg-destructive/10',
}

const ROTULO_SEVERIDADE: Record<Severidade, string> = {
  info: 'text-primary',
  atencao: 'text-warning',
  critico: 'text-destructive',
}

export function Callout({
  severidade,
  titulo,
  fonte,
  children,
}: {
  severidade: Severidade
  titulo: string
  fonte?: string
  children: ReactNode
}) {
  return (
    <div className={cn('rounded-md border px-4 py-3', ESTILO_SEVERIDADE[severidade])}>
      <p
        className={cn(
          'text-[11px] font-bold uppercase tracking-wider',
          ROTULO_SEVERIDADE[severidade],
        )}
      >
        {titulo}
      </p>
      <div className="mt-1 text-sm leading-relaxed text-foreground/90">{children}</div>
      {fonte && <p className="mt-1.5 text-[11px] text-muted-foreground">{fonte}</p>}
    </div>
  )
}

// --- Etiqueta compacta ------------------------------------------------------
export function Badge({
  children,
  tom = 'neutro',
}: {
  children: ReactNode
  tom?: 'neutro' | 'primario' | 'alerta' | 'critico'
}) {
  const tons = {
    neutro: 'border-border bg-secondary text-muted-foreground',
    primario: 'border-primary/40 bg-primary/15 text-primary',
    alerta: 'border-warning/40 bg-warning/15 text-warning',
    critico: 'border-destructive/40 bg-destructive/15 text-destructive',
  } as const
  return (
    <span
      className={cn(
        'inline-flex items-center rounded border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider',
        tons[tom],
      )}
    >
      {children}
    </span>
  )
}
