import { describe, expect, it } from 'vitest'
import {
  ckdEpi,
  cockcroftGault,
  pesoAjustado,
  pesoIdealDevine,
  superficieCorporal,
  validarEntradaRenal,
} from '@/domain/renal'
import { AJUSTE_RENAL, ajustePorFarmaco, faixaAplicavel } from '@/data/ajuste-renal'
import { DRUGS, TODAS_AS_REGRAS } from '@/data'
import { converterDosePonderal, totalPipTazo } from '@/domain/dose-ponderal'

/**
 * Verificação da função renal e dos pesos de referência.
 *
 * O ponto crítico aqui não é a aritmética, e sim a distinção entre TFG indexada
 * e ClCr absoluto: é ela que decide a faixa de dose.
 */

describe('pesos de referência', () => {
  it('peso ideal por Devine, homem e mulher de 1,70 m', () => {
    // 170 cm = 66,93 pol → 6,93 pol acima de 5 pés → 2,3 × 6,93 = 15,9
    expect(pesoIdealDevine(170, 'M')).toBeCloseTo(65.9, 1)
    expect(pesoIdealDevine(170, 'F')).toBeCloseTo(61.4, 1)
  })

  it('peso ajustado usa 40% do excesso sobre o ideal', () => {
    // Ideal 65,9; atual 100 → 65,9 + 0,4 × 34,1 = 79,5
    expect(pesoAjustado(100, 65.9)).toBeCloseTo(79.5, 1)
  })

  it('abaixo do peso ideal, o ajustado degrada para o peso real', () => {
    // A fórmula crua devolveria valor ACIMA do real, o que superdosaria.
    expect(pesoAjustado(50, 65.9)).toBe(50)
    expect(pesoAjustado(65.9, 65.9)).toBe(65.9)
  })

  it('peso ideal tem piso, para não ficar negativo em baixa estatura', () => {
    expect(pesoIdealDevine(120, 'F')).toBeGreaterThanOrEqual(30)
  })

  it('superfície corporal por Du Bois', () => {
    expect(superficieCorporal(70, 170)).toBeCloseTo(1.81, 2)
  })
})

describe('função renal', () => {
  it('CKD-EPI devolve indexado e absoluto, e eles diferem fora de 1,73 m²', () => {
    const r = ckdEpi(1.0, 60, 'M', 100, 180)
    expect(r.formula).toBe('CKD-EPI 2021')
    // Paciente grande: superfície > 1,73 → absoluto MAIOR que o indexado.
    expect(r.absoluto).toBeGreaterThan(r.indexado)
  })

  it('paciente pequeno tem absoluto MENOR que o indexado', () => {
    const r = ckdEpi(1.0, 60, 'F', 45, 150)
    expect(r.absoluto).toBeLessThan(r.indexado)
  })

  it('CKD-EPI aplica o fator feminino', () => {
    const h = ckdEpi(1.0, 50, 'M', 70, 170).indexado
    const m = ckdEpi(1.0, 50, 'F', 70, 170).indexado
    expect(m).not.toBeCloseTo(h, 1)
  })

  it('Cockcroft-Gault já devolve valor absoluto', () => {
    const r = cockcroftGault(1.0, 40, 'M', 70)
    // ((140-40) × 70) / (72 × 1,0) = 97,2
    expect(r.absoluto).toBeCloseTo(97.2, 1)
    expect(r.indexado).toBe(r.absoluto)
  })

  it('Cockcroft-Gault aplica o fator 0,85 no sexo feminino', () => {
    const h = cockcroftGault(1.0, 40, 'M', 70).absoluto
    const m = cockcroftGault(1.0, 40, 'F', 70).absoluto
    expect(m).toBeCloseTo(h * 0.85, 4)
  })

  it('clearance cai quando a creatinina sobe', () => {
    const bom = cockcroftGault(0.8, 60, 'M', 70).absoluto
    const ruim = cockcroftGault(3.2, 60, 'M', 70).absoluto
    expect(ruim).toBeLessThan(bom)
  })

  it('validação recusa campos ausentes ou fora de faixa', () => {
    expect(validarEntradaRenal({})).not.toEqual([])
    const completo = { creatininaMgDl: 1, idadeAnos: 50, pesoKg: 70, alturaCm: 170, sexo: 'M' as const }
    expect(validarEntradaRenal(completo)).toEqual([])
    expect(validarEntradaRenal({ ...completo, creatininaMgDl: 99 })).not.toEqual([])
    expect(validarEntradaRenal({ ...completo, pesoKg: 900 })).not.toEqual([])
  })
})

describe('tabelas de ajuste renal', () => {
  it('todo fármaco marcado como "no protocolo" existe no catálogo', () => {
    // A tabela institucional é mais ampla que o protocolo empírico: só os
    // marcados com `noProtocolo` precisam ter entrada em DRUGS.
    for (const a of AJUSTE_RENAL.filter((x) => x.noProtocolo)) {
      expect(DRUGS[a.id], a.id).toBeDefined()
    }
  })

  it('todo fármaco que o protocolo prescreve está na tabela de ajuste', () => {
    const naTabela = new Set(AJUSTE_RENAL.map((a) => a.id))
    const prescritos = new Set(
      TODAS_AS_REGRAS.flatMap((r) => r.prescricoes.map((p) => p.drugId)),
    )
    // A dexametasona é adjuvante, não antimicrobiano, e não consta da tabela.
    prescritos.delete('dexametasona')
    for (const id of prescritos) {
      expect(naTabela.has(id), id).toBe(true)
    }
  })

  it('os identificadores da tabela são únicos', () => {
    const ids = AJUSTE_RENAL.map((a) => a.id)
    expect(new Set(ids).size).toBe(ids.length)
  })

  it('fármaco sem ajuste não declara faixas, e vice-versa', () => {
    for (const f of AJUSTE_RENAL) {
      if (f.semAjuste) expect(f.esquemas, f.nome).toEqual([])
    }
  })

  it('cefepime: faixa correta em cada extremo, nos dois esquemas', () => {
    const cefepime = ajustePorFarmaco('cefepime')!
    const usual = cefepime.esquemas[0]!
    const alta = cefepime.esquemas[1]!

    expect(faixaAplicavel(usual, 90)?.dose).toBe('2 g 12/12h')
    expect(faixaAplicavel(usual, 45)?.dose).toBe('2 g 1x/dia')
    expect(faixaAplicavel(usual, 20)?.dose).toBe('1 g 1x/dia')
    expect(faixaAplicavel(usual, 5)?.dose).toBe('500 mg 1x/dia')

    // O mesmo clearance dá dose diferente no esquema de alta dose.
    expect(faixaAplicavel(alta, 45)?.dose).toBe('2 g 12/12h')
    expect(faixaAplicavel(alta, 5)?.dose).toBe('1 g 1x/dia')
  })

  it('meropenem: o esquema de 2 g mantém dose maior no mesmo clearance', () => {
    const mero = ajustePorFarmaco('meropenem')!
    const usual = faixaAplicavel(mero.esquemas[0]!, 30)?.dose
    const alta = faixaAplicavel(mero.esquemas[1]!, 30)?.dose
    expect(usual).toBe('1 g 12/12h')
    expect(alta).toBe('2 g 12/12h')
  })

  it('gentamicina exige peso ajustado e traz a dose de sinergismo', () => {
    const genta = ajustePorFarmaco('gentamicina')!
    expect(genta.pesoDeReferencia).toBe('ajustado')
    expect(genta.observacoes?.some((o) => o.includes('1 mg/kg'))).toBe(true)
    expect(faixaAplicavel(genta.esquemas[0]!, 100)?.dose).toBe('5 mg/kg 1x/dia')
    expect(faixaAplicavel(genta.esquemas[0]!, 35)?.dose).toBe('2,5 mg/kg 1x/dia')
  })

  it('amicacina exige peso ajustado e tem dose de ataque', () => {
    const ami = ajustePorFarmaco('amicacina')!
    expect(ami.pesoDeReferencia).toBe('ajustado')
    expect(ami.doseAtaque).toContain('15 mg/kg')
    expect(faixaAplicavel(ami.esquemas[0]!, 60)?.dose).toBe('15 mg/kg 1x/dia')
    expect(faixaAplicavel(ami.esquemas[0]!, 5)?.dose).toBe('7,5 mg/kg 48/48h')
  })

  it('fármacos sem ajuste renal não têm faixas', () => {
    for (const id of ['ceftriaxona', 'oxacilina', 'clindamicina']) {
      const f = ajustePorFarmaco(id)!
      expect(f.semAjuste, id).toBe(true)
      expect(f.esquemas, id).toEqual([])
    }
  })

  it('vão da tabela devolve undefined em vez de inventar dose', () => {
    // O metronidazol não define conduta entre 10 e 50 mL/min.
    const metro = ajustePorFarmaco('metronidazol')!
    expect(faixaAplicavel(metro.esquemas[0]!, 30)).toBeUndefined()
    expect(faixaAplicavel(metro.esquemas[0]!, 80)).toBeDefined()
  })

  it('as faixas de um esquema não se sobrepõem', () => {
    for (const f of AJUSTE_RENAL) {
      for (const esq of f.esquemas) {
        for (const clcr of [0, 5, 12, 22, 35, 45, 55, 70, 85, 120]) {
          const casadas = esq.faixas.filter((fx) => {
            const acima = fx.min === null || clcr >= fx.min
            const abaixo = fx.max === null || clcr < fx.max
            return acima && abaixo
          })
          expect(casadas.length, `${f.nome} / ${esq.partida} / ClCr ${clcr}`).toBeLessThanOrEqual(1)
        }
      }
    }
  })
})

// ---------------------------------------------------------------------------
describe('conversão de dose ponderal em miligramas', () => {
  it('dose escalar por administração', () => {
    // Amicacina 7,5 mg/kg em 80 kg → 600 mg por dose.
    const r = converterDosePonderal('7,5 mg/kg 1x/dia', 80)
    expect(r?.min).toBe(600)
    expect(r?.max).toBe(600)
    expect(r?.porDia).toBe(false)
    expect(r?.texto).toBe('= 600 mg por dose')
  })

  it('faixa grafada com "a"', () => {
    // Aciclovir 5 a 12,5 mg/kg em 70 kg → 350 a 875 mg.
    const r = converterDosePonderal('5 a 12,5 mg/kg a cada 8 h', 70)
    expect(r?.min).toBe(350)
    expect(r?.max).toBe(875)
  })

  it('faixa grafada com travessão', () => {
    const r = converterDosePonderal('5–20 mg/kg/dia a cada 6–12 h', 60)
    expect(r?.min).toBe(300)
    expect(r?.max).toBe(1200)
  })

  it('distingue dose diária de dose por administração', () => {
    expect(converterDosePonderal('5–20 mg/kg/dia a cada 6–12 h', 60)?.porDia).toBe(true)
    expect(converterDosePonderal('6 mg/kg a cada 48 h', 60)?.porDia).toBe(false)
    expect(converterDosePonderal('5–20 mg/kg/dia a cada 6–12 h', 60)?.texto).toContain('por dia')
  })

  it('preserva uma casa decimal abaixo de 10 mg — relevante em neonatologia', () => {
    // 2,5 mg/kg em 1,4 kg → 3,5 mg.
    expect(converterDosePonderal('2,5 a 6,25 mg/kg a cada 24 h', 1.4)?.min).toBe(3.5)
  })

  it('devolve undefined quando a conduta não é ponderal', () => {
    expect(converterDosePonderal('2 g 8/8h', 70)).toBeUndefined()
    expect(converterDosePonderal('CONTRAINDICADA', 70)).toBeUndefined()
    expect(converterDosePonderal('4 milhões UI 4/4h', 70)).toBeUndefined()
  })

  it('recusa peso inválido em vez de devolver número absurdo', () => {
    expect(converterDosePonderal('7,5 mg/kg 1x/dia', 0)).toBeUndefined()
    expect(converterDosePonderal('7,5 mg/kg 1x/dia', -5)).toBeUndefined()
    expect(converterDosePonderal('7,5 mg/kg 1x/dia', NaN)).toBeUndefined()
  })

  it('converte todas as faixas ponderais da tabela institucional sem quebrar', () => {
    let convertidas = 0
    for (const f of AJUSTE_RENAL) {
      for (const esq of f.esquemas) {
        for (const fx of esq.faixas) {
          if (!/mg\s*\/\s*kg/i.test(fx.dose)) continue
          const r = converterDosePonderal(fx.dose, 70)
          expect(r, `${f.nome} · ${fx.rotulo} · ${fx.dose}`).toBeDefined()
          expect(r!.min).toBeGreaterThan(0)
          expect(r!.max).toBeGreaterThanOrEqual(r!.min)
          convertidas++
        }
      }
    }
    // Guarda contra uma regressão que fizesse o padrão parar de casar.
    expect(convertidas).toBeGreaterThan(15)
  })
})

// ---------------------------------------------------------------------------
describe('proporção 8:1 da piperacilina/tazobactam', () => {
  it('o total da apresentação soma o tazobactam', () => {
    // 100 mg/kg × 20 kg = 2000 mg de piperacilina → 250 mg de tazobactam.
    const r = totalPipTazo(2000)
    expect(r.piperacilina).toBe(2000)
    expect(r.tazobactam).toBe(250)
    expect(r.total).toBe(2250)
  })

  it('bate com a apresentação adulta de 4,5 g', () => {
    // 4 g de piperacilina + 0,5 g de tazobactam = 4,5 g.
    const r = totalPipTazo(4000)
    expect(r.tazobactam).toBe(500)
    expect(r.total).toBe(4500)
  })
})

// ---------------------------------------------------------------------------
describe('integridade das referências entre fichas', () => {
  it('toda referência "ficha NN" aponta para uma ficha existente', async () => {
    // Regressão real: ao reordenar as fichas, referências espalhadas por
    // componentes e tabelas continuaram apontando para os números antigos.
    const { CARDS } = await import('@/data/cards')
    const numeros = new Set(CARDS.map((c) => c.numero))

    const modulos = import.meta.glob('../**/*.{ts,tsx}', { as: 'raw', eager: true })
    const quebradas: string[] = []

    for (const [arquivo, conteudo] of Object.entries(modulos)) {
      if (arquivo.includes('__tests__')) continue
      for (const m of (conteudo as string).matchAll(/ficha (\d{2})\b/g)) {
        const n = Number(m[1])
        if (!numeros.has(n)) quebradas.push(`${arquivo} → ficha ${m[1]}`)
      }
    }

    expect(quebradas).toEqual([])
  })

  it('a numeração das fichas é sequencial e sem buracos', async () => {
    const { CARDS } = await import('@/data/cards')
    expect(CARDS.map((c) => c.numero)).toEqual(CARDS.map((_, i) => i + 1))
  })

  it('os identificadores das fichas são únicos', async () => {
    const { CARDS } = await import('@/data/cards')
    const ids = CARDS.map((c) => c.id)
    expect(new Set(ids).size).toBe(ids.length)
  })
})
