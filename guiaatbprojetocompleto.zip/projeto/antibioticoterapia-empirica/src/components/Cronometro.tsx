import { useEffect, useState } from 'react'
import { Clock, RotateCcw } from 'lucide-react'
import { Callout } from './ui/primitives'
import { cn } from '@/lib/utils'

/**
 * Cronômetro de janelas terapêuticas.
 *
 * No guia de profilaxia cirúrgica o cronômetro controla o REPIQUE intraoperatório.
 * Na terapia empírica as duas janelas que o protocolo estabelece são outras:
 *   • suspeita clínica → primeira dose, em 1–3 h (item 5, etapa 4);
 *   • primeira dose → reavaliação, em 48–72 h (item 5, etapa 5).
 *
 * Os marcos ficam em localStorage para sobreviver ao fechamento do app — um
 * plantão dura mais que uma aba de navegador.
 */

const CHAVE_SUSPEITA = 'atb-empirico:marco:suspeita'
const CHAVE_PRIMEIRA_DOSE = 'atb-empirico:marco:primeira-dose'

const HORA = 3600_000

function lerMarco(chave: string): number | null {
  try {
    const bruto = localStorage.getItem(chave)
    if (!bruto) return null
    const n = Number(bruto)
    return Number.isFinite(n) ? n : null
  } catch {
    // localStorage indisponível (modo privativo restrito): degrada em memória.
    return null
  }
}

function gravarMarco(chave: string, valor: number | null): void {
  try {
    if (valor === null) localStorage.removeItem(chave)
    else localStorage.setItem(chave, String(valor))
  } catch {
    /* ignorado — o cronômetro continua funcionando na sessão atual */
  }
}

/** Formata uma duração em milissegundos como "2 h 14 min". */
function formatarDuracao(ms: number): string {
  const totalMin = Math.floor(Math.abs(ms) / 60_000)
  const h = Math.floor(totalMin / 60)
  const min = totalMin % 60
  if (h === 0) return `${min} min`
  return `${h} h ${String(min).padStart(2, '0')} min`
}

function formatarHorario(ts: number): string {
  return new Date(ts).toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}

interface JanelaProps {
  rotulo: string
  descricao: string
  marco: number | null
  agora: number
  /** Início e fim da janela desejada, em horas a partir do marco. */
  janelaH: [number, number]
  onMarcar: () => void
  onLimpar: () => void
}

function Janela({ rotulo, descricao, marco, agora, janelaH, onMarcar, onLimpar }: JanelaProps) {
  const [inicioH, fimH] = janelaH

  let estado: 'aguardando' | 'dentro' | 'estourado' = 'aguardando'
  let decorrido = 0
  if (marco !== null) {
    decorrido = agora - marco
    if (decorrido > fimH * HORA) estado = 'estourado'
    else if (decorrido >= inicioH * HORA) estado = 'dentro'
  }

  const cor =
    estado === 'estourado'
      ? 'border-destructive/60 bg-destructive/10'
      : estado === 'dentro'
        ? 'border-success/60 bg-success/10'
        : 'border-border bg-secondary/40'

  return (
    <div className={cn('rounded-md border p-4', cor)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="kicker">{rotulo}</p>
          <p className="mt-1 text-sm text-muted-foreground">{descricao}</p>
        </div>
        {marco !== null && (
          <button
            type="button"
            onClick={onLimpar}
            aria-label={`Limpar marco de ${rotulo}`}
            className="shrink-0 rounded p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <RotateCcw className="h-4 w-4" aria-hidden />
          </button>
        )}
      </div>

      {marco === null ? (
        <button
          type="button"
          onClick={onMarcar}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-bold uppercase tracking-wider text-primary-foreground transition-opacity hover:opacity-90"
        >
          <Clock className="h-4 w-4" aria-hidden />
          Marcar agora
        </button>
      ) : (
        <div className="mt-3">
          <p className="text-2xl font-bold tabular-nums text-foreground">
            {formatarDuracao(decorrido)}
          </p>
          <p className="mt-0.5 text-xs text-muted-foreground">
            marcado em {formatarHorario(marco)} · janela de {inicioH}–{fimH} h
          </p>
          <p
            className={cn(
              'mt-2 text-xs font-bold uppercase tracking-wider',
              estado === 'estourado'
                ? 'text-destructive'
                : estado === 'dentro'
                  ? 'text-success'
                  : 'text-muted-foreground',
            )}
          >
            {estado === 'estourado'
              ? `Janela ultrapassada há ${formatarDuracao(decorrido - fimH * HORA)}`
              : estado === 'dentro'
                ? 'Dentro da janela'
                : `Faltam ${formatarDuracao(inicioH * HORA - decorrido)} para a janela`}
          </p>
        </div>
      )}
    </div>
  )
}

export function Cronometro() {
  const [suspeita, setSuspeita] = useState<number | null>(() => lerMarco(CHAVE_SUSPEITA))
  const [primeiraDose, setPrimeiraDose] = useState<number | null>(() =>
    lerMarco(CHAVE_PRIMEIRA_DOSE),
  )
  const [agora, setAgora] = useState(() => Date.now())

  // Atualiza a cada 30 s: resolução suficiente para janelas medidas em horas,
  // sem manter o rádio do celular acordado à toa.
  useEffect(() => {
    const id = setInterval(() => setAgora(Date.now()), 30_000)
    return () => clearInterval(id)
  }, [])

  const marcar = (setter: (v: number | null) => void, chave: string) => () => {
    const ts = Date.now()
    setter(ts)
    gravarMarco(chave, ts)
    setAgora(ts)
  }

  const limpar = (setter: (v: number | null) => void, chave: string) => () => {
    setter(null)
    gravarMarco(chave, null)
  }

  return (
    <div className="space-y-3 px-4 py-4">
      <Janela
        rotulo="Suspeita clínica → primeira dose"
        descricao="Prescrever e administrar a primeira dose dentro de 1–3 h."
        marco={suspeita}
        agora={agora}
        janelaH={[1, 3]}
        onMarcar={marcar(setSuspeita, CHAVE_SUSPEITA)}
        onLimpar={limpar(setSuspeita, CHAVE_SUSPEITA)}
      />

      <Janela
        rotulo="Primeira dose → reavaliação"
        descricao="Reavaliar resposta clínica e culturas em 48–72 h; descalonar quando possível."
        marco={primeiraDose}
        agora={agora}
        janelaH={[48, 72]}
        onMarcar={marcar(setPrimeiraDose, CHAVE_PRIMEIRA_DOSE)}
        onLimpar={limpar(setPrimeiraDose, CHAVE_PRIMEIRA_DOSE)}
      />

      <Callout severidade="atencao" titulo="O cronômetro não substitui a prescrição">
        Os marcos são um lembrete local, gravados apenas neste aparelho. Não há
        notificação em segundo plano nem registro em prontuário — o horário real da dose
        deve ser documentado no prontuário eletrônico.
      </Callout>
    </div>
  )
}
