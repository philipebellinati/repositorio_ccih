import { AlertTriangle, ExternalLink, Replace } from 'lucide-react'
import { REGRAS_POR_SECAO, FOCOS, ALTERNATIVAS_ALERGIA, substitutoDe } from '@/data'
import type { ProtocolRule, SecaoId } from '@/domain/types'
import { BETALACTAMICOS, formatarRegime, regraTemBetalactamico } from '@/domain/format'
import { Badge } from './ui/primitives'
import { MarkedText } from './MarkedText'
import { cn } from '@/lib/utils'

/**
 * Renderiza uma tabela do protocolo (6.1 … 6.6) a partir das MESMAS regras que
 * alimentam o motor de decisão — nunca de uma cópia do texto.
 *
 * @param secaoId       seção do protocolo a exibir
 * @param pesoKg        quando informado, converte as doses mg/kg em miligramas
 * @param regrasCasadas quando não vazio, exibe apenas as linhas que a busca casou
 * @param modoAlergia   destaca as linhas que contêm betalactâmico
 */
export function TabelaSecao({
  secaoId,
  pesoKg,
  regrasCasadas,
  modoAlergia,
  onAbrirFicha,
}: {
  secaoId: SecaoId
  pesoKg?: number
  regrasCasadas?: Set<string>
  modoAlergia: boolean
  onAbrirFicha?: (id: string, vancoPopulacao?: 'adulto' | 'neoped') => void
}) {
  // A citação de Vancomicina deve abrir a ABA CERTA da ficha: as tabelas
  // pediátricas e neonatais têm lógica de ajuste incompatível com a do adulto
  // (percentual x miligramas, com e sem dose de ataque).
  const vancoPopulacao: 'adulto' | 'neoped' =
    secaoId === '6.3' || secaoId === '6.4' || secaoId === '6.6' ? 'neoped' : 'adulto'

  const todas = REGRAS_POR_SECAO[secaoId] ?? []
  const filtrando = regrasCasadas !== undefined && regrasCasadas.size > 0
  const regras = filtrando ? todas.filter((r) => regrasCasadas.has(r.id)) : todas

  // Agrupa por foco para reproduzir a leitura da tabela impressa, em que a
  // coluna FOCO só aparece uma vez e as condições ficam alinhadas abaixo dela.
  const porFoco = new Map<string, ProtocolRule[]>()
  for (const r of regras) {
    const lista = porFoco.get(r.focoId) ?? []
    lista.push(r)
    porFoco.set(r.focoId, lista)
  }

  if (regras.length === 0) {
    return (
      <p className="px-4 py-3 text-sm text-muted-foreground">
        Nenhuma linha desta seção corresponde à busca.
      </p>
    )
  }

  return (
    <div className="divide-y divide-border">
      {filtrando && (
        <p className="bg-primary/10 px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-primary">
          Exibindo {regras.length} de {todas.length} linhas — filtrado pela busca
        </p>
      )}

      {[...porFoco.entries()].map(([focoId, linhas]) => {
        const foco = FOCOS[focoId]
        return (
          <section key={focoId} className="px-4 py-3">
            <h4 className="text-sm font-bold text-foreground">{foco?.nome ?? focoId}</h4>
            {foco?.descricao && (
              <p className="mt-0.5 text-xs text-muted-foreground">{foco.descricao}</p>
            )}

            <div className="mt-2.5 space-y-2.5">
              {linhas
                .slice()
                .sort((a, b) => a.prioridade - b.prioridade)
                .map((regra) => {
                  const linhasRegime = formatarRegime(regra, pesoKg)
                  const alertaAlergia = modoAlergia && regraTemBetalactamico(regra)
                  // Âncora da opção por foco: o primeiro betalactâmico da regra.
                  const primeiroBeta = linhasRegime.findIndex((x) =>
                    BETALACTAMICOS.has(x.drugId),
                  )
                  const altFoco = alertaAlergia
                    ? ALTERNATIVAS_ALERGIA.find((a) => a.focoId === regra.focoId)
                    : undefined

                  return (
                    <div
                      key={regra.id}
                      className={cn(
                        'rounded-md border bg-secondary/40 p-3',
                        alertaAlergia ? 'border-destructive/50' : 'border-border',
                      )}
                    >
                      <div className="mb-2 flex flex-wrap items-center gap-2">
                        <Badge tom={regra.prioridade === 0 ? 'neutro' : 'primario'}>
                          {regra.condicaoLabel}
                        </Badge>
                        {alertaAlergia && <Badge tom="critico">Betalactâmico</Badge>}
                      </div>

                      <ul className="space-y-1.5">
                        {linhasRegime.map((l, i) => (
                          <li key={i} className="text-sm leading-snug">
                            <span className="font-semibold text-foreground">{l.nome}</span>{' '}
                            <span className={cn(l.protocoloExterno ? 'text-warning' : 'text-primary')}>
                              {l.dose}
                            </span>{' '}
                            <span className="text-muted-foreground">
                              {l.via} · {l.intervalo}
                            </span>
                            {l.facultativo && (
                              <span className="ml-1.5 text-xs text-muted-foreground">
                                (associação facultativa)
                              </span>
                            )}
                            {l.criterioFacultativo && (
                              <span className="mt-1 block rounded border-l-2 border-primary/50 bg-primary/5 py-1 pl-2 text-xs leading-snug text-muted-foreground">
                                <MarkedText texto={l.criterioFacultativo} />
                              </span>
                            )}
                            {l.memoria && (
                              <span className="ml-1.5 text-xs text-muted-foreground">
                                — {l.memoria}
                              </span>
                            )}
                            {/* Substituto DESTE fármaco, no modo alergia. A opção
                                por foco aparece uma vez ao pé da regra; esta
                                responde "o que ponho no lugar desta droga". */}
                            {modoAlergia &&
                              (() => {
                                const sub = substitutoDe(l.drugId)
                                if (!sub) return null
                                return (
                                  <span className="mt-1 block rounded border-l-2 border-destructive/60 bg-destructive/5 py-1 pl-2 text-xs leading-snug">
                                    <span className="font-bold uppercase tracking-wider text-destructive">
                                      Trocar {l.nome} por:{' '}
                                    </span>
                                    <span className="text-foreground/90">
                                      <MarkedText texto={sub.substituto} />
                                    </span>
                                    {sub.razao && (
                                      <span className="mt-0.5 block text-muted-foreground">
                                        <MarkedText texto={sub.razao} />
                                      </span>
                                    )}
                                  </span>
                                )
                              })()}
                            {l.protocoloExterno &&
                              (onAbrirFicha ? (
                                <button
                                  type="button"
                                  onClick={() => onAbrirFicha('vancomicina', vancoPopulacao)}
                                  className="mt-0.5 flex items-center gap-1 rounded text-left text-xs font-semibold text-warning underline decoration-dotted underline-offset-2 hover:text-warning/80 focus:outline-none focus:ring-1 focus:ring-ring"
                                >
                                  <ExternalLink className="h-3 w-3 shrink-0" aria-hidden />
                                  {l.protocoloExterno} — abrir ficha{' '}
                                  {vancoPopulacao === 'neoped' ? 'neonatal/pediátrica' : 'adulto'} e
                                  calcular a dose
                                </button>
                              ) : (
                                <span className="mt-0.5 flex items-center gap-1 text-xs text-warning">
                                  <ExternalLink className="h-3 w-3" aria-hidden />
                                  {l.protocoloExterno}
                                </span>
                              ))}
                            {l.tabelaDose &&
                              (onAbrirFicha ? (
                                <button
                                  type="button"
                                  onClick={() => onAbrirFicha('secao-6-6')}
                                  className="mt-0.5 flex items-center gap-1 rounded text-left text-xs font-semibold text-warning underline decoration-dotted underline-offset-2 hover:text-warning/80 focus:outline-none focus:ring-1 focus:ring-ring"
                                >
                                  <ExternalLink className="h-3 w-3 shrink-0" aria-hidden />
                                  {l.tabelaDose} — abrir
                                </button>
                              ) : (
                                <span className="mt-0.5 flex items-center gap-1 text-xs text-warning">
                                  <ExternalLink className="h-3 w-3 shrink-0" aria-hidden />
                                  {l.tabelaDose}
                                </span>
                              ))}
                            {l.excedeTetoAdulto && (
                              <span className="mt-0.5 flex items-center gap-1 text-xs text-warning">
                                <AlertTriangle className="h-3 w-3" aria-hidden />
                                Dose acima da maior dose adulta prevista no protocolo —
                                confira o peso
                              </span>
                            )}
                            {l.observacoes.map((o, j) => (
                              <span
                                key={j}
                                className="mt-0.5 block text-xs leading-snug text-muted-foreground"
                              >
                                {o}
                              </span>
                            ))}

                            {/* A opção por FOCO fica ancorada ao PRIMEIRO
                                betalactâmico da regra, e não no rodapé do bloco:
                                no rodapé ela ficava separada do fármaco por
                                outras drogas e suas notas, e quem lê a linha do
                                betalactâmico não deve ter de caçar a troca. */}
                            {alertaAlergia && i === primeiroBeta && altFoco && (
                              <span className="mt-1.5 block rounded-md border border-destructive/40 bg-destructive/5 p-2.5">
                                <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-destructive">
                                  <Replace className="h-3 w-3 shrink-0" aria-hidden />
                                  Alergia — opção para {altFoco.foco.toLowerCase()}
                                  {altFoco.incerto && ' · sem bom substituto'}
                                </span>
                                <span className="mt-1 block text-sm leading-snug text-foreground/90">
                                  <MarkedText texto={altFoco.esquema} />
                                </span>
                                {altFoco.ressalva && (
                                  <span className="mt-1 block text-xs leading-snug text-muted-foreground">
                                    <MarkedText texto={altFoco.ressalva} />
                                  </span>
                                )}
                                <span className="mt-1 block text-[10px] uppercase tracking-wider text-muted-foreground">
                                  Proposta — depende de aprovação do SCIH · ficha 15
                                </span>
                              </span>
                            )}
                          </li>
                        ))}
                      </ul>

                    </div>
                  )
                })}
            </div>
          </section>
        )
      })}
    </div>
  )
}
