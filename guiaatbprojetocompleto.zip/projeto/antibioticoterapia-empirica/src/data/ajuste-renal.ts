/**
 * Ajuste de dose por função renal — tabela institucional completa.
 *
 * Transcrição da "Tabela para ajuste de doses de antimicrobianos – HE"
 * (SCIH e Farmácia Clínica, revisão de março/2023).
 *
 * O PDF de origem é diagramado em três colunas — fármaco à esquerda, faixas de
 * clearance ao centro, observações à direita — e a extração linear embaralha a
 * ordem. A transcrição foi feita casando as coordenadas de cada bloco, para que
 * nenhuma faixa de dose fosse atribuída ao fármaco errado.
 *
 * As faixas são confrontadas com o ClCr ABSOLUTO em mL/min — nunca com a TFG
 * indexada por 1,73 m². Ver a advertência em `src/domain/renal.ts`.
 */

export interface FaixaAjuste {
  /** Limite inferior, em mL/min. `null` = sem piso. */
  min: number | null
  /** Limite superior, em mL/min. `null` = sem teto. */
  max: number | null
  rotulo: string
  dose: string
}

export interface EsquemaAjuste {
  /** Rótulo do esquema de partida, ex.: "a partir de 2 g 8/8h". */
  partida: string
  /** Quando usar este esquema em vez do outro do mesmo fármaco. */
  indicacao?: string
  faixas: readonly FaixaAjuste[]
  /** Conduta em hemodiálise, fora da lógica de faixas. */
  hemodialise?: string
}

export interface AjusteFarmaco {
  /** Identificador estável. Coincide com o `drugId` quando o fármaco é usado
   *  pelo protocolo empírico; caso contrário é apenas um slug da tabela. */
  id: string
  nome: string
  /** Classe, para agrupar a lista. */
  classe: 'antibacteriano' | 'antifungico' | 'antiviral'
  /** O protocolo de antibioticoterapia empírica prescreve este fármaco. */
  noProtocolo?: boolean
  /** Dose habitual, quando a tabela a declara. */
  doseHabitual?: string
  /**
   * Maior dose adulta prevista. É o TETO do cálculo: nenhuma conversão por peso
   * pode ultrapassá-la sem alerta explícito.
   */
  doseMaxima?: string
  /** Dose de ataque, quando a tabela institucional prevê uma. */
  doseAtaque?: string
  /** Uso restrito: liberado só com identificação microbiológica. */
  restrito?: string
  /** Divergência ou ambiguidade que o SCIH precisa resolver. */
  alertaConferencia?: string
  /** Peso a usar no cálculo, quando a dose é ponderal. */
  pesoDeReferencia?: 'atual' | 'ajustado' | 'ideal'
  /** `true` quando a tabela declara explicitamente "sem ajuste renal". */
  semAjuste?: boolean
  observacoes?: readonly string[]
  esquemas: readonly EsquemaAjuste[]
}

export const AJUSTE_RENAL: readonly AjusteFarmaco[] = [
  // =========================================================================
  // ANTIBACTERIANOS
  // =========================================================================
  {
    id: 'amicacina',
    nome: 'Amicacina',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseAtaque: '15 mg/kg em dose única; depois ajustar conforme ClCr',
    pesoDeReferencia: 'ajustado',
    observacoes: [
      'Usar PESO AJUSTADO: Pajustado = Pideal + 0,4 × (Patual − Pideal).',
      'Dose máxima 25–30 mg/kg/dia. Ao usar 30 mg/kg/dia, dobrar a dose habitual ' +
        'conforme a função renal.',
      'No período NEONATAL vale a tabela por idade gestacional e pós-natal — ficha 12.',
    ],
    esquemas: [
      {
        partida: 'a partir de 15 mg/kg 1x/dia',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '15 mg/kg 1x/dia' },
          { min: 10, max: 50, rotulo: '10–50', dose: '7,5 mg/kg 1x/dia' },
          { min: null, max: 10, rotulo: '< 10', dose: '7,5 mg/kg 48/48h' },
        ],
        hemodialise: '7,5 mg/kg 48/48h + 3,75 mg/kg após HD',
      },
    ],
  },
  {
    id: 'azitromicina',
    nome: 'Azitromicina',
    classe: 'antibacteriano',
    noProtocolo: true,
    semAjuste: true,
    doseHabitual: '500 mg 1x/dia EV (adulto) · 10 mg/kg/dia (pediatria)',
    observacoes: [
      'SEM ajuste por função renal: a eliminação é predominantemente biliar e ' +
        'apenas cerca de 6% é excretado inalterado na urina.',
      'Não requer ajuste em nenhum estágio de doença renal crônica. Em diálise, ' +
        'faltam dados para a formulação endovenosa.',
      'Sem ajuste na disfunção hepática leve a moderada; não estudada na grave.',
      'Não constava da tabela institucional — acrescentada por definição do SCIH.',
    ],
    esquemas: [],
  },
  {
    id: 'amoxicilina_clavulanato',
    nome: 'Amoxicilina (1000 mg) + Clavulanato (200 mg)',
    classe: 'antibacteriano',
    doseAtaque: '1000 mg / 200 mg',
    observacoes: ['Não administrar por via IM.', 'Infusão direta ou em 30 a 40 min.'],
    esquemas: [
      {
        partida: 'a partir de 1000/200 mg 8/8h',
        faixas: [
          { min: 30, max: null, rotulo: '> 30', dose: '1000 mg / 200 mg 8/8h' },
          { min: 10, max: 30, rotulo: '10–30', dose: '500 mg / 100 mg 12/12h' },
          { min: null, max: 10, rotulo: '< 10', dose: '500 mg / 100 mg 1x/dia' },
        ],
        hemodialise: '500 mg / 100 mg 1x/dia + dose após HD',
      },
    ],
  },
  {
    id: 'ampicilina',
    nome: 'Ampicilina',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseHabitual: '1 a 2 g EV a cada 4 ou 6 h',
    observacoes: ['Infusão em 15 a 30 min.'],
    esquemas: [
      {
        partida: 'a partir de 1–2 g a cada 6 h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '1–2 g a cada 6 h' },
          { min: 30, max: 49, rotulo: '30–49', dose: '1–2 g a cada 8 h' },
          { min: 10, max: 29, rotulo: '10–29', dose: '1–2 g a cada 12 h' },
        ],
        hemodialise: '1–2 g a cada 12 h (uma das doses após HD)',
      },
    ],
  },
  {
    id: 'ampicilina_sulbactam',
    nome: 'Ampicilina-sulbactam',
    classe: 'antibacteriano',
    doseHabitual: '3 g 6/6h',
    doseMaxima: '9 g 8/8h (esquema anti-Acinetobacter)',
    doseAtaque: 'Manter 3 g 6/6h',
    restrito:
      'A indicação anti-Acinetobacter (dose alta) é de uso restrito — só com ' +
      'identificação microbiológica.',
    observacoes: [
      'Contra Acinetobacter o componente ativo é o SULBACTAM: 9 g da associação ' +
        '8/8h equivalem a 9 g de sulbactam por dia, que é a dose alta consagrada.',
      'A tabela institucional manda "multiplicar por 3 a dose correspondente ao ' +
        'ClCr" — é o que o esquema de dose alta abaixo faz.',
    ],
    alertaConferencia:
      'No ClCr > 50 a regra do "×3" sobre a dose usual (3 g 6/6h) daria 9 g 6/6h ' +
      '= 36 g/dia, acima das 27 g/dia do esquema de 9 g 8/8h definido pelo SCIH. ' +
      'O guia adota 9 g 8/8h; confirmar a intenção na revisão.',
    esquemas: [
      {
        partida: 'a partir de 3 g 6/6h',
        indicacao: 'Dose usual',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '3 g 6/6h' },
          { min: 30, max: 50, rotulo: '30–50', dose: '3 g 8/8h' },
          { min: 15, max: 29, rotulo: '15–29', dose: '3 g 12/12h' },
          { min: null, max: 10, rotulo: '< 10', dose: '3 g 1x/dia' },
        ],
        hemodialise: '3 g 1x/dia + 3 g após HD',
      },
      {
        partida: 'a partir de 9 g 8/8h',
        indicacao: 'Acinetobacter — dose alta de sulbactam',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '9 g 8/8h' },
          { min: 30, max: 50, rotulo: '30–50', dose: '9 g 8/8h' },
          { min: 15, max: 29, rotulo: '15–29', dose: '9 g 12/12h' },
          { min: null, max: 10, rotulo: '< 10', dose: '9 g 1x/dia' },
        ],
        hemodialise: '9 g 1x/dia + 9 g após HD',
      },
    ],
  },
  {
    id: 'aztreonam',
    nome: 'Aztreonam',
    classe: 'antibacteriano',
    doseHabitual: '2 g 8/8h',
    doseAtaque: 'Manter 2 g 8/8h; depois ajustar conforme ClCr',
    observacoes: [
      'Infecções graves: 2 g 6/6h em infusão estendida. Dose máxima 8 g/dia.',
    ],
    esquemas: [
      {
        partida: 'a partir de 2 g 8/8h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '2 g 8/8h' },
          { min: 10, max: 50, rotulo: '10–50', dose: '1 g 8/8h' },
          { min: null, max: 10, rotulo: '< 10', dose: '2 g 1x/dia' },
        ],
        hemodialise: '2 g 1x/dia + dose após HD',
      },
    ],
  },
  {
    id: 'cefalotina',
    nome: 'Cefalotina',
    classe: 'antibacteriano',
    doseHabitual: '2 g a cada 6 h',
    esquemas: [
      {
        partida: 'a partir de 2 g 6/6h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '2 g 6/6h' },
          { min: 10, max: 50, rotulo: '10–50', dose: '1 g 6/6h' },
        ],
        hemodialise: '1 g 12/12h (uma das doses após HD)',
      },
    ],
  },
  {
    id: 'cefazolina',
    nome: 'Cefazolina',
    classe: 'antibacteriano',
    semAjuste: true,
    doseHabitual: '1–2 g 8/8h por 24 a 48 h',
    observacoes: ['Apenas para profilaxia cirúrgica, quando indicado.'],
    esquemas: [],
  },
  {
    id: 'cefepime',
    nome: 'Cefepime',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseHabitual: '2 g 12/12h',
    observacoes: [
      'A dose de 2 g 8/8h destina-se a neutropenia febril, infecções por BGN ' +
        'multirresistente, Pseudomonas e meningite.',
    ],
    esquemas: [
      {
        partida: 'a partir de 2 g 12/12h',
        indicacao: 'Dose usual',
        faixas: [
          { min: 60, max: null, rotulo: '> 60', dose: '2 g 12/12h' },
          { min: 30, max: 60, rotulo: '30–60', dose: '2 g 1x/dia' },
          { min: 11, max: 29, rotulo: '11–29', dose: '1 g 1x/dia' },
          { min: null, max: 11, rotulo: '< 11', dose: '500 mg 1x/dia' },
        ],
        hemodialise: '500 mg 1x/dia + dose após HD',
      },
      {
        partida: 'a partir de 2 g 8/8h',
        indicacao: 'Neutropenia febril · BGN MR · Pseudomonas · meningite',
        faixas: [
          { min: 60, max: null, rotulo: '> 60', dose: '2 g 8/8h' },
          { min: 30, max: 60, rotulo: '30–60', dose: '2 g 12/12h' },
          { min: 11, max: 29, rotulo: '11–29', dose: '2 g 1x/dia' },
          { min: null, max: 11, rotulo: '< 11', dose: '1 g 1x/dia' },
        ],
        hemodialise: '1 g 1x/dia + dose após HD',
      },
    ],
  },
  {
    id: 'ceftazidima',
    nome: 'Ceftazidima',
    classe: 'antibacteriano',
    doseHabitual: '2 g 8/8h',
    doseAtaque: 'Manter 2 g 8/8h; depois ajustar conforme ClCr',
    esquemas: [
      {
        partida: 'a partir de 2 g 8/8h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '2 g 8/8h' },
          { min: 10, max: 50, rotulo: '10–50', dose: '2 g 12/12h' },
          { min: null, max: 10, rotulo: '< 10', dose: '2 g 1x/dia' },
        ],
        hemodialise: '1 g 1x/dia + dose após HD',
      },
    ],
  },
  {
    id: 'ceftazidima_avibactam',
    nome: 'Ceftazidima-avibactam',
    classe: 'antibacteriano',
    doseAtaque: '2,5 g 8/8h por 24 h; depois ajustar conforme ClCr',
    observacoes: [
      'Ativa contra enterobactérias. Pouca atividade contra Pseudomonas. Sem ação ' +
        'contra Acinetobacter.',
    ],
    esquemas: [
      {
        partida: 'a partir de 2,5 g 8/8h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '2,5 g 8/8h' },
          { min: 31, max: 50, rotulo: '31–50', dose: '1,25 g 8/8h' },
          { min: 16, max: 30, rotulo: '16–30', dose: '0,94 g 12/12h' },
          { min: 5, max: 15, rotulo: '5–15', dose: '0,94 g 1x/dia' },
        ],
        hemodialise: '0,94 g 48/48h + 0,94 g após HD',
      },
    ],
  },
  {
    id: 'ceftolozana_tazobactam',
    nome: 'Ceftolozana-tazobactam',
    classe: 'antibacteriano',
    esquemas: [
      {
        partida: 'a partir de 1,5 g 8/8h',
        indicacao: 'ITU e abdome',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '1,5 g 8/8h' },
          { min: 30, max: 50, rotulo: '30–50', dose: '750 mg 8/8h' },
          { min: 15, max: 29, rotulo: '15–29', dose: '375 mg 8/8h' },
        ],
        hemodialise: '750 mg de ataque, 150 mg 8/8h + 150 mg após HD',
      },
      {
        partida: 'a partir de 3 g 8/8h',
        indicacao: 'Pneumonia',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '3 g 8/8h' },
          { min: 30, max: 50, rotulo: '30–50', dose: '1,5 g 8/8h' },
          { min: 15, max: 29, rotulo: '15–29', dose: '750 mg 8/8h' },
        ],
        hemodialise: '2,25 g de ataque, 450 mg 8/8h + 450 mg após HD',
      },
    ],
  },
  {
    id: 'ceftriaxona',
    nome: 'Ceftriaxona',
    classe: 'antibacteriano',
    noProtocolo: true,
    semAjuste: true,
    doseHabitual: '1–2 g 24/24h ou 1 g 12/12h',
    observacoes: ['Dose máxima 4 g/dia. Em meningite, 2 g 12/12h.'],
    esquemas: [],
  },
  {
    id: 'cefuroxima',
    nome: 'Cefuroxima',
    classe: 'antibacteriano',
    semAjuste: true,
    doseHabitual: '1 g 8/8h por 24 h',
    observacoes: ['Apenas para profilaxia cirúrgica, quando indicado.'],
    esquemas: [],
  },
  {
    id: 'ciprofloxacino',
    nome: 'Ciprofloxacino',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseHabitual: '400 mg 12/12h',
    observacoes: [
      'Se infecção por Pseudomonas, 400 mg 8/8h — dobrar a dose conforme ClCr quando < 50.',
    ],
    esquemas: [
      {
        partida: 'a partir de 400 mg 12/12h',
        indicacao: 'Dose usual',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '400 mg 12/12h' },
          { min: 30, max: 50, rotulo: '30–50', dose: '200 mg 12/12h' },
          { min: 5, max: 29, rotulo: '5–29', dose: '200 mg 1x/dia' },
        ],
        hemodialise: '200 mg 1x/dia + dose após HD',
      },
      {
        partida: 'a partir de 400 mg 8/8h',
        indicacao: 'Pseudomonas',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '400 mg 8/8h' },
          { min: 30, max: 50, rotulo: '30–50', dose: '400 mg 12/12h' },
          { min: 5, max: 29, rotulo: '5–29', dose: '400 mg 1x/dia' },
        ],
        hemodialise: '400 mg 1x/dia + dose após HD',
      },
    ],
  },
  {
    id: 'claritromicina',
    nome: 'Claritromicina',
    classe: 'antibacteriano',
    doseHabitual: '500 mg 12/12h',
    esquemas: [
      {
        partida: 'a partir de 500 mg 12/12h',
        faixas: [
          { min: 10, max: 50, rotulo: '10–50', dose: '500 mg 12/12h a 24/24h' },
          { min: null, max: 10, rotulo: '< 10', dose: '500 mg 1x/dia' },
        ],
        hemodialise: '500 mg 1x/dia + dose após HD',
      },
    ],
  },
  {
    id: 'clindamicina',
    nome: 'Clindamicina',
    classe: 'antibacteriano',
    noProtocolo: true,
    semAjuste: true,
    doseHabitual: '600 mg 6/6h ou 900 mg 8/8h EV · 300 mg 8/8h ou 6/6h VO',
    observacoes: [
      'Dose máxima 1.800 mg/dia por via oral e 4.800 mg/dia por via endovenosa.',
      'Sem ação contra Enterococcus. Resistente contra Bacteroides. Não recomendada ' +
        'para tratamento de infecções abdominais.',
    ],
    esquemas: [],
  },
  {
    id: 'daptomicina',
    nome: 'Daptomicina',
    classe: 'antibacteriano',
    pesoDeReferencia: 'atual',
    doseHabitual: '6 a 12 mg/kg, conforme o sítio de infecção',
    observacoes: [
      '6 mg/kg para infecções de pele e partes moles.',
      '12 mg/kg para bacteremia por Gram-positivo e endocardite direita.',
      'Não usar em pneumonia: é inativada pelo surfactante pulmonar.',
    ],
    esquemas: [
      {
        partida: 'a partir de 6 mg/kg',
        indicacao: 'Pele e partes moles',
        faixas: [
          { min: 30, max: null, rotulo: '> 30', dose: '6 mg/kg 1x/dia' },
          { min: null, max: 30, rotulo: '< 30', dose: '6 mg/kg 48/48h' },
        ],
        hemodialise: '6 mg/kg 48/48h + 6 mg/kg após HD',
      },
    ],
  },
  {
    id: 'delafloxacino',
    nome: 'Delafloxacino',
    classe: 'antibacteriano',
    doseHabitual: '300 mg a cada 12 h',
    esquemas: [
      {
        partida: 'a partir de 300 mg 12/12h',
        faixas: [
          { min: 30, max: 89, rotulo: 'TFGe 30–89', dose: '300 mg a cada 12 h' },
          { min: 15, max: 29, rotulo: 'TFGe 15–29', dose: '200 mg a cada 12 h' },
          { min: null, max: 15, rotulo: 'TFGe < 15', dose: 'Uso não recomendado' },
        ],
        hemodialise: 'Uso não recomendado',
      },
    ],
  },
  {
    id: 'doxiciclina',
    nome: 'Doxiciclina',
    classe: 'antibacteriano',
    semAjuste: true,
    doseHabitual: '100 mg a cada 12 h',
    observacoes: [
      'Ativa contra CA-MRSA, Leptospira, Borrelia, Rickettsia, Mycoplasma, ' +
        'Ureaplasma e Anaplasma. Pode ser usada na profilaxia da malária.',
    ],
    esquemas: [],
  },
  {
    id: 'ertapenem',
    nome: 'Ertapenem',
    classe: 'antibacteriano',
    doseHabitual: '1 g 1x/dia',
    doseAtaque: '1 g em dose única; depois ajustar conforme ClCr',
    observacoes: [
      'Sem ação contra Pseudomonas. Droga de escolha para ITU por ESBL.',
    ],
    esquemas: [
      {
        partida: 'a partir de 1 g 1x/dia',
        faixas: [
          { min: 30, max: null, rotulo: '> 30', dose: '1 g 1x/dia' },
          { min: 10, max: 30, rotulo: '10–30', dose: '500 mg 1x/dia' },
        ],
        hemodialise: '500 mg 1x/dia + 150 mg após HD',
      },
    ],
  },
  {
    id: 'fosfomicina',
    nome: 'Fosfomicina',
    classe: 'antibacteriano',
    semAjuste: true,
    doseHabitual:
      'ITU não complicada: 3 g em dose única · ITU complicada: 3 g a cada 72 h, ' +
      '3 doses · Prostatite: 3 g a cada 72 h, 7 doses · BGN XDR: 3 g 8/8h por 7 dias',
    observacoes: [
      'Ativa contra bactérias produtoras de ESBL e resistentes a carbapenêmicos ' +
        '(E. coli, Proteus, Klebsiella, Enterobacter, Serratia, Citrobacter, ' +
        'Providencia). Sem ação contra Acinetobacter.',
    ],
    esquemas: [],
  },
  {
    id: 'gentamicina',
    nome: 'Gentamicina',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseAtaque: '5 mg/kg em dose única; depois ajustar conforme ClCr',
    pesoDeReferencia: 'ajustado',
    observacoes: [
      'Usar PESO AJUSTADO: Pajustado = Pideal + 0,4 × (Patual − Pideal).',
      'Dose máxima 7 mg/kg.',
      'A dose de 1 mg/kg a cada 8 h destina-se APENAS a sinergismo na endocardite.',
    ],
    esquemas: [
      {
        partida: 'dose plena, a partir de 5 mg/kg 1x/dia',
        faixas: [
          { min: 80, max: null, rotulo: '> 80', dose: '5 mg/kg 1x/dia' },
          { min: 60, max: 80, rotulo: '60–80', dose: '4 mg/kg 1x/dia' },
          { min: 40, max: 60, rotulo: '40–60', dose: '3,5 mg/kg 1x/dia' },
          { min: 30, max: 40, rotulo: '30–40', dose: '2,5 mg/kg 1x/dia' },
          { min: 20, max: 30, rotulo: '20–30', dose: '4 mg/kg a cada 48 h' },
          { min: 10, max: 20, rotulo: '10–20', dose: '3 mg/kg a cada 48 h' },
        ],
        hemodialise: '2 mg/kg a cada 72 h + 50% da dose após HD',
      },
    ],
  },
  {
    id: 'imipenem',
    nome: 'Imipenem',
    classe: 'antibacteriano',
    doseAtaque: '1 g 6/6h por 24 h; depois ajustar conforme ClCr',
    observacoes: [
      'A dose de 1 g 6/6h destina-se a choque séptico, Pseudomonas e bactérias com ' +
        'susceptibilidade intermediária.',
      'Infusão em 3 h. Evitar uso em pacientes com ClCr < 15.',
    ],
    esquemas: [
      {
        partida: 'a partir de 500 mg 6/6h',
        indicacao: 'Dose usual',
        faixas: [
          { min: 60, max: null, rotulo: '> 60', dose: '500 mg 6/6h' },
          { min: 30, max: 60, rotulo: '30–60', dose: '500 mg 8/8h' },
          { min: null, max: 30, rotulo: '< 30', dose: '500 mg 12/12h' },
        ],
        hemodialise: '500 mg 12/12h (uma dose após a diálise)',
      },
      {
        partida: 'a partir de 1 g 6/6h',
        indicacao: 'Choque séptico · Pseudomonas · sensibilidade intermediária',
        faixas: [
          { min: 60, max: null, rotulo: '> 60', dose: '1 g 6/6h' },
          { min: 30, max: 60, rotulo: '30–60', dose: '1 g 8/8h' },
          { min: null, max: 30, rotulo: '< 30', dose: '1 g 12/12h' },
        ],
        hemodialise: '1 g 12/12h (uma dose após a diálise)',
      },
    ],
  },
  {
    id: 'levofloxacino',
    nome: 'Levofloxacino',
    classe: 'antibacteriano',
    doseAtaque: '750 mg em dose única; depois ajustar conforme ClCr',
    observacoes: ['Ativa contra Pseudomonas. Infusão em 90 min para a dose de 750 mg.'],
    esquemas: [
      {
        partida: 'a partir de 750 mg 1x/dia',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '750 mg 1x/dia' },
          { min: 20, max: 49, rotulo: '20–49', dose: '750 mg 1x/dia' },
          { min: null, max: 20, rotulo: '< 20', dose: '750 mg 48/48h' },
        ],
        hemodialise: '750 mg 48/48h',
      },
    ],
  },
  {
    id: 'linezolida',
    nome: 'Linezolida',
    classe: 'antibacteriano',
    semAjuste: true,
    doseHabitual: '600 mg 12/12h',
    observacoes: [
      'Ativa contra MRSA e VRE.',
      'Atenção ao uso com inibidores de recaptação de serotonina e noradrenalina — ' +
        'risco de síndrome serotoninérgica.',
    ],
    esquemas: [],
  },
  {
    id: 'meropenem',
    nome: 'Meropenem',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseAtaque: '2 g 8/8h por 24 h; depois ajustar conforme ClCr',
    observacoes: [
      'A dose de 2 g 8/8h destina-se a choque séptico, meningite e Pseudomonas.',
      'Infusão em 3 h. A PRIMEIRA dose deve ser infundida rapidamente, em 3–5 min.',
    ],
    esquemas: [
      {
        partida: 'a partir de 1 g 8/8h',
        indicacao: 'Dose usual',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '1 g 8/8h' },
          { min: 25, max: 50, rotulo: '25–50', dose: '1 g 12/12h' },
          { min: 10, max: 25, rotulo: '10–25', dose: '500 mg 12/12h' },
          { min: null, max: 10, rotulo: '< 10', dose: '500 mg 1x/dia' },
        ],
        hemodialise: '500 mg 1x/dia + 500 mg após HD',
      },
      {
        partida: 'a partir de 2 g 8/8h',
        indicacao: 'Choque séptico · meningite · Pseudomonas',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '2 g 8/8h' },
          { min: 25, max: 50, rotulo: '25–50', dose: '2 g 12/12h' },
          { min: 10, max: 25, rotulo: '10–25', dose: '1 g 12/12h' },
          { min: null, max: 10, rotulo: '< 10', dose: '1 g 1x/dia' },
        ],
        hemodialise: '1 g 1x/dia + 1 g após HD',
      },
    ],
  },
  {
    id: 'metronidazol',
    nome: 'Metronidazol',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseHabitual: '7,5 mg/kg a cada 6 h',
    doseAtaque: 'Em infecções graves, 15 mg/kg em dose única',
    pesoDeReferencia: 'atual',
    observacoes: [
      'Ativa contra Bacteroides e Entamoeba histolytica.',
      'Se usada por via oral para tratamento de Clostridioides, não corrigir a dose ' +
        '(400–500 mg VO 6/6h).',
    ],
    esquemas: [
      {
        partida: 'a partir de 7,5 mg/kg 6/6h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '7,5 mg/kg a cada 6 h' },
          { min: null, max: 10, rotulo: '< 10', dose: '7,5 mg/kg a cada 12 h' },
        ],
        hemodialise: '7,5 mg/kg a cada 12 h (uma das doses após HD)',
      },
    ],
  },
  {
    id: 'moxifloxacino',
    nome: 'Moxifloxacino',
    classe: 'antibacteriano',
    semAjuste: true,
    doseHabitual: '400 mg 1x/dia (EV ou VO)',
    observacoes: [
      'Ação contra patógenos respiratórios e entéricos. NÃO é ativa contra Pseudomonas.',
      'Infusão em 60 min.',
    ],
    esquemas: [],
  },
  {
    id: 'nitrofurantoina',
    nome: 'Nitrofurantoína',
    classe: 'antibacteriano',
    doseHabitual: '100 mg 6/6h VO',
    observacoes: [
      'CONTRAINDICADA se ClCr < 50.',
      'Ativa contra Enterococcus, S. saprophyticus e BGN.',
    ],
    esquemas: [
      {
        partida: 'a partir de 100 mg 6/6h',
        faixas: [
          { min: 50, max: null, rotulo: '≥ 50', dose: '100 mg 6/6h' },
          { min: null, max: 50, rotulo: '< 50', dose: 'CONTRAINDICADA' },
        ],
        hemodialise: 'Contraindicada',
      },
    ],
  },
  {
    id: 'oxacilina',
    nome: 'Oxacilina',
    classe: 'antibacteriano',
    noProtocolo: true,
    semAjuste: true,
    doseHabitual: '2 g 4/4h',
    observacoes: ['Ativa apenas contra MSSA. Infusão em 60 min.'],
    esquemas: [],
  },
  {
    id: 'penicilina_g',
    nome: 'Penicilina G cristalina',
    classe: 'antibacteriano',
    doseHabitual: '4 milhões UI 4/4h',
    esquemas: [
      {
        partida: 'a partir de 4 milhões UI 4/4h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '4 milhões UI 4/4h' },
          { min: 10, max: 50, rotulo: '10–50', dose: '4 milhões UI 8/8h' },
          { min: null, max: 10, rotulo: '< 10', dose: '4 milhões UI 12/12h' },
        ],
        hemodialise: '4 milhões UI 12/12h + 4 milhões UI após HD',
      },
    ],
  },
  {
    id: 'piperacilina_tazobactam',
    nome: 'Piperacilina/tazobactam',
    classe: 'antibacteriano',
    noProtocolo: true,
    doseAtaque: '4,5 g 6/6h por 24 h; depois ajustar conforme ClCr',
    observacoes: [
      'A dose de 4,5 g 6/6h destina-se a choque séptico, meningite e Pseudomonas.',
      'Em pediatria, o mg/kg é calculado APENAS sobre o componente piperacilina ' +
        '(proporção 8:1) — base de 240 a 300 mg/kg/dia, dividida a cada 6 ou 8 h.',
    ],
    esquemas: [
      {
        partida: 'a partir de 4,5 g 8/8h',
        indicacao: 'Dose usual',
        faixas: [
          { min: 40, max: null, rotulo: '> 40', dose: '4,5 g 8/8h' },
          { min: 20, max: 40, rotulo: '20–40', dose: '2,25 g 6/6h' },
          { min: null, max: 20, rotulo: '< 20', dose: '2,25 g 8/8h' },
        ],
        hemodialise: '2,25 g 12/12h + 0,75 g após HD',
      },
      {
        partida: 'a partir de 4,5 g 6/6h',
        indicacao: 'Choque séptico · meningite · Pseudomonas',
        faixas: [
          { min: 40, max: null, rotulo: '> 40', dose: '4,5 g 6/6h' },
          { min: 20, max: 40, rotulo: '20–40', dose: '4,5 g 8/8h' },
          { min: null, max: 20, rotulo: '< 20', dose: '2,25 g 6/6h' },
        ],
        hemodialise: '2,25 g 8/8h + 0,75 g após HD',
      },
    ],
  },
  {
    id: 'polimixina_b',
    nome: 'Polimixina B',
    classe: 'antibacteriano',
    semAjuste: true,
    pesoDeReferencia: 'atual',
    doseAtaque: '2,5 mg/kg em dose única',
    observacoes: [
      'Preferível à polimixina E, exceto no tratamento de ITU.',
      'Sem ajuste para função renal. Dose de manutenção sugerida por faixa de peso: ' +
        '≤ 50 kg 60 mg 12/12h · 50–60 kg 75 mg · 61–70 kg 100 mg · 71–90 kg 125 mg · ' +
        '91–110 kg 150 mg · 111–120 kg 180 mg · 121–140 kg 200 mg · 141–160 kg 225 mg · ' +
        '> 161 kg 250 mg, todas 12/12h.',
      'Sem atividade contra Citrobacter, Serratia, Proteus, Providencia, Morganella ' +
        'e Burkholderia.',
    ],
    esquemas: [],
  },
  {
    id: 'polimixina_e',
    nome: 'Polimixina E (colistina/colistimetato)',
    classe: 'antibacteriano',
    pesoDeReferencia: 'atual',
    doseAtaque: '4 mg/kg em dose única, independente da função renal',
    observacoes: [
      'Preferível à polimixina B para o tratamento de ITU.',
      'Colistina inalatória (apenas Colistek® e genérico ABL): 75 mg 8/8h ou 12/12h, ' +
        'reconstituída em 4 mL de SF 0,9%.',
    ],
    esquemas: [
      {
        partida: 'manutenção, a partir de 150 mg 12/12h',
        faixas: [
          { min: 50, max: null, rotulo: '> 50', dose: '150 mg 12/12h' },
          { min: 30, max: 50, rotulo: '30–50', dose: '125 mg 12/12h' },
          { min: 10, max: 29, rotulo: '10–29', dose: '90 mg 12/12h' },
          { min: null, max: 10, rotulo: '< 10', dose: '67 mg 12/12h' },
        ],
        hemodialise: '67 mg 12/12h + 50 mg após HD',
      },
    ],
  },
  {
    id: 'sulfametoxazol_trimetoprima',
    nome: 'Sulfametoxazol-trimetoprima',
    classe: 'antibacteriano',
    pesoDeReferencia: 'atual',
    doseHabitual: '5 a 20 mg/kg/dia de trimetoprima, a cada 6 a 12 h',
    observacoes: ['Ativa contra algumas cepas de MRSA. A dose refere-se à trimetoprima.'],
    esquemas: [
      {
        partida: 'a partir de 5–20 mg/kg/dia de trimetoprima',
        faixas: [
          { min: 30, max: null, rotulo: '> 30', dose: '5–20 mg/kg/dia a cada 6–12 h' },
          { min: 10, max: 29, rotulo: '10–29', dose: '5–10 mg/kg/dia a cada 12 h' },
          {
            min: null,
            max: 10,
            rotulo: '< 10',
            dose: 'Não recomendado; se necessário, 5–10 mg/kg/dia a cada 24 h',
          },
        ],
        hemodialise: 'Não recomendado; se necessário, 5–10 mg/kg/dia a cada 24 h',
      },
    ],
  },
  {
    id: 'teicoplanina',
    nome: 'Teicoplanina',
    classe: 'antibacteriano',
    doseAtaque: '6 ou 12 mg/kg a cada 12 h por 48 h; depois ajustar conforme ClCr',
    observacoes: [
      'A dose de 12 mg/kg destina-se a infecção de corrente sanguínea, bacteremia, ' +
        'endocardite e infecções osteoarticulares.',
      'Alta ligação às proteínas plasmáticas (90–95%): na hipoalbuminemia o efeito ' +
        'cai. Nesses casos a vancomicina é mais segura, por permitir dosagem sérica.',
    ],
    esquemas: [
      {
        partida: 'a partir de 6 mg/kg',
        indicacao: 'Dose usual',
        faixas: [
          { min: 80, max: null, rotulo: '> 80', dose: '6 mg/kg a cada 24 h' },
          { min: 30, max: 80, rotulo: '30–80', dose: '6 mg/kg a cada 48 h' },
          { min: null, max: 30, rotulo: '< 30', dose: '6 mg/kg a cada 72 h' },
        ],
        hemodialise: '6 mg/kg a cada 72 h',
      },
      {
        partida: 'a partir de 12 mg/kg',
        indicacao: 'ICS · bacteremia · endocardite · osteoarticular',
        faixas: [
          { min: 80, max: null, rotulo: '> 80', dose: '12 mg/kg a cada 24 h' },
          { min: 30, max: 80, rotulo: '30–80', dose: '12 mg/kg a cada 48 h' },
          { min: null, max: 30, rotulo: '< 30', dose: '12 mg/kg a cada 72 h' },
        ],
        hemodialise: '12 mg/kg a cada 72 h',
      },
    ],
  },
  {
    id: 'tigeciclina',
    nome: 'Tigeciclina',
    classe: 'antibacteriano',
    semAjuste: true,
    doseAtaque: '100 mg em dose única',
    doseHabitual: 'Manutenção 50 mg 12/12h',
    observacoes: [
      'Ataque de 200 mg e manutenção de 100 mg 12/12h APENAS para pneumonia por ' +
        'Acinetobacter.',
    ],
    esquemas: [],
  },
  {
    id: 'vancomicina',
    nome: 'Vancomicina',
    classe: 'antibacteriano',
    noProtocolo: true,
    observacoes: [
      'Por via endovenosa, ver a ficha própria de Vancomicina — o ajuste tem tabela ' +
        'dedicada e monitorização sérica.',
      'Por via oral, para Clostridioides difficile (colite pseudomembranosa): ' +
        '125 mg 6/6h ou 250 mg 6/6h, VO ou por cateter nasoentérico.',
    ],
    esquemas: [],
  },

  // =========================================================================
  // ANTIFÚNGICOS
  // =========================================================================
  {
    id: 'anfotericina_b_convencional',
    nome: 'Anfotericina B (convencional)',
    classe: 'antifungico',
    semAjuste: true,
    doseHabitual: '1 mg/kg/dia',
    esquemas: [],
  },
  {
    id: 'anfotericina_b_lipossomal',
    nome: 'Anfotericina B (lipossomal)',
    classe: 'antifungico',
    semAjuste: true,
    doseHabitual: '3 a 5 mg/kg/dia',
    esquemas: [],
  },
  {
    id: 'fluconazol',
    nome: 'Fluconazol',
    classe: 'antifungico',
    doseHabitual: '100 a 400 mg 1x/dia',
    doseAtaque: 'Candidemia: 12 mg/kg de ataque, manter 400 mg/dia',
    observacoes: [
      'Candida krusei e C. glabrata são intrinsecamente resistentes ao fluconazol.',
    ],
    esquemas: [
      {
        partida: 'a partir de 400 mg 1x/dia',
        faixas: [
          { min: 90, max: null, rotulo: '> 90', dose: '400 mg a cada 24 h' },
          { min: null, max: 10, rotulo: '< 10', dose: '50% da dose a cada 24 h' },
        ],
        hemodialise: 'Dose plena a cada 24 h, administrada após a diálise',
      },
    ],
  },
  {
    id: 'micafungina',
    nome: 'Micafungina',
    classe: 'antifungico',
    semAjuste: true,
    doseHabitual: '100 mg 1x/dia',
    observacoes: ['Não há penetração urinária.'],
    esquemas: [],
  },
  {
    id: 'voriconazol',
    nome: 'Voriconazol',
    classe: 'antifungico',
    doseHabitual: '6 mg/kg a cada 12 h, seguido de 4 mg/kg a cada 12 h',
    esquemas: [
      {
        partida: 'formulação endovenosa',
        faixas: [
          { min: 50, max: null, rotulo: '≥ 50', dose: '6 mg/kg 12/12h, depois 4 mg/kg 12/12h' },
          { min: null, max: 50, rotulo: '< 50', dose: 'Uso endovenoso não recomendado' },
        ],
      },
    ],
  },

  // =========================================================================
  // ANTIVIRAIS
  // =========================================================================
  {
    id: 'aciclovir',
    nome: 'Aciclovir',
    classe: 'antiviral',
    doseHabitual: 'SNC: 5 a 12,5 mg/kg a cada 8 h',
    esquemas: [
      {
        partida: 'a partir de 5–12,5 mg/kg 8/8h',
        faixas: [
          { min: 50, max: 90, rotulo: '50–90', dose: '5 a 12,5 mg/kg a cada 8 h' },
          { min: 10, max: 50, rotulo: '10–50', dose: '5 a 12,5 mg/kg a cada 12 a 24 h' },
          { min: null, max: 10, rotulo: '< 10', dose: '2,5 a 6,25 mg/kg a cada 24 h' },
        ],
        hemodialise: '2,5 a 6,25 mg/kg a cada 24 h + dose após HD',
      },
    ],
  },
  {
    id: 'ganciclovir',
    nome: 'Ganciclovir',
    classe: 'antiviral',
    doseHabitual:
      'Indução 5 mg/kg EV a cada 12 h por 14 dias · Manutenção 5 mg/kg 1x/dia ou ' +
      '6 mg/kg 1x/dia em 5 dias por semana',
    esquemas: [
      {
        partida: 'indução e manutenção',
        faixas: [
          {
            min: 50,
            max: 90,
            rotulo: '50–90',
            dose: 'Indução 5 mg/kg 12/12h · Manutenção 2,5–5 mg/kg 1x/dia',
          },
          {
            min: 10,
            max: 50,
            rotulo: '10–50',
            dose: 'Indução 2,5 mg/kg 24/24h · Manutenção 1,25 mg/kg 1x/dia',
          },
          {
            min: null,
            max: 10,
            rotulo: '< 10',
            dose: 'Indução 1,25 mg/kg 3x/semana · Manutenção 0,625 mg/kg 3x/semana',
          },
        ],
        hemodialise:
          'Indução 1,25 mg/kg 3x/semana · Manutenção 0,625 mg/kg 3x/semana. No dia ' +
          'da diálise, administrar após a HD.',
      },
    ],
  },
]

/**
 * Encontra a faixa aplicável a um clearance.
 *
 * As faixas são inclusivas no limite inferior e exclusivas no superior, exceto
 * a última. Devolve `undefined` quando o clearance cai num vão da tabela — o
 * que acontece de fato: metronidazol, por exemplo, não define conduta entre
 * 10 e 50 mL/min. Nesses casos a interface mostra o vão em vez de inventar.
 */
export function faixaAplicavel(
  esquema: EsquemaAjuste,
  clcrMlMin: number,
): FaixaAjuste | undefined {
  return esquema.faixas.find((f) => {
    const acimaDoPiso = f.min === null || clcrMlMin >= f.min
    const abaixoDoTeto = f.max === null || clcrMlMin < f.max
    return acimaDoPiso && abaixoDoTeto
  })
}

export function ajustePorFarmaco(id: string): AjusteFarmaco | undefined {
  return AJUSTE_RENAL.find((a) => a.id === id)
}

/** Fármacos prescritos pelo protocolo empírico — exibidos primeiro na lista. */
export const AJUSTE_NO_PROTOCOLO = AJUSTE_RENAL.filter((a) => a.noProtocolo)
export const AJUSTE_DEMAIS = AJUSTE_RENAL.filter((a) => !a.noProtocolo)
