/// <reference types="vitest" />
import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import path from 'node:path'

// Vite + Vitest share a single config. `test` is typed by the vitest/config import.
export default defineConfig({
  // Netlify, Vercel e o arquivo único servem a partir da raiz ("/").
  // O GitHub Pages serve de /<nome-do-repositório>/, e sem esse prefixo o
  // navegador procura o JS na raiz do domínio e a página abre em branco.
  // O workflow de deploy define BASE_PATH; fora dele, vale a raiz.
  base: process.env.BASE_PATH ?? '/',
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  test: {
    globals: true,
    environment: 'node',
    include: ['src/**/*.test.ts'],
  },
})
