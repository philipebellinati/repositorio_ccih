/**
 * Função renal e pesos de referência.
 *
 * Alimenta duas necessidades distintas do protocolo:
 *  1. o AJUSTE DE DOSE por clearance, que as tabelas institucionais expressam
 *     sempre em ClCr (mL/min);
 *  2. o PESO AJUSTADO dos aminoglicosídeos, exigido pela tabela de ajuste de
 *     antimicrobianos para amicacina e gentamicina.
 *
 * ARMADILHA CENTRAL DESTE MÓDULO — leia antes de alterar qualquer coisa:
 * CKD-EPI devolve TFG estimada em mL/min/1,73 m², isto é, NORMALIZADA para a
 * superfície corporal média. As tabelas de ajuste de antimicrobianos foram
 * construídas sobre ClCr em mL/min ABSOLUTO (Cockcroft-Gault). Jogar um valor
 * indexado direto na tabela subestima a dose no paciente grande e superestima
 * no pequeno. Por isso `ckdEpi()` devolve os dois números — indexado e
 * desindexado — e o app só usa o ABSOLUTO para escolher faixa de dose.
 */

export type Sexo = 'M' | 'F'

// ---------------------------------------------------------------------------
// 1. PESOS DE REFERÊNCIA
// ---------------------------------------------------------------------------

/**
 * Peso ideal pela fórmula de Devine.
 *
 * A tabela institucional exige "peso ideal" para compor o peso ajustado sem
 * nomear a fórmula. Devine foi adotada como padrão institucional — é a
 * convenção sobre a qual as faixas de aminoglicosídeo foram historicamente
 * derivadas.
 *
 * @param alturaCm altura em centímetros
 * @param sexo     sexo biológico, que muda a constante da fórmula
 */
export function pesoIdealDevine(alturaCm: number, sexo: Sexo): number {
  const polegadasAcimaDe5Pes = alturaCm / 2.54 - 60
  const base = sexo === 'M' ? 50 : 45.5
  // Abaixo de 152 cm a fórmula fica negativa na margem; o piso evita absurdo.
  return Math.max(base + 2.3 * polegadasAcimaDe5Pes, 30)
}

/**
 * Peso ajustado, exatamente como grafado na tabela institucional:
 *
 *     Pajustado = Pideal + 0,4 × (Patual − Pideal)
 *
 * Quando o paciente pesa MENOS que o ideal, a fórmula devolveria um valor acima
 * do peso real — o que superdosaria. Nesse caso usa-se o peso real, que é a
 * conduta consagrada.
 */
export function pesoAjustado(pesoAtualKg: number, pesoIdealKg: number): number {
  if (pesoAtualKg <= pesoIdealKg) return pesoAtualKg
  return pesoIdealKg + 0.4 * (pesoAtualKg - pesoIdealKg)
}

/** Superfície corporal (Du Bois), usada para desindexar a TFG do CKD-EPI. */
export function superficieCorporal(pesoKg: number, alturaCm: number): number {
  return 0.007184 * Math.pow(alturaCm, 0.725) * Math.pow(pesoKg, 0.425)
}

// ---------------------------------------------------------------------------
// 2. FUNÇÃO RENAL
// ---------------------------------------------------------------------------

export interface ResultadoRenal {
  /** Valor em mL/min/1,73 m² — como o CKD-EPI é publicado. */
  indexado: number
  /**
   * Valor em mL/min absoluto, desindexado pela superfície corporal.
   * É ESTE que deve ser confrontado com as tabelas de ajuste de dose.
   */
  absoluto: number
  formula: 'CKD-EPI 2021' | 'Cockcroft-Gault'
}

/**
 * CKD-EPI 2021, a equação sem o coeficiente de raça.
 *
 *   TFGe = 142 × min(Scr/κ, 1)^α × max(Scr/κ, 1)^(−1,200) × 0,9938^idade × 1,012 (se F)
 *   κ = 0,7 (F) ou 0,9 (M); α = −0,241 (F) ou −0,302 (M)
 *
 * @param creatininaMgDl creatinina sérica em mg/dL
 * @param idadeAnos      idade em anos
 * @param sexo           sexo biológico
 * @param pesoKg         peso, apenas para desindexar
 * @param alturaCm       altura, apenas para desindexar
 */
export function ckdEpi(
  creatininaMgDl: number,
  idadeAnos: number,
  sexo: Sexo,
  pesoKg: number,
  alturaCm: number,
): ResultadoRenal {
  const kappa = sexo === 'F' ? 0.7 : 0.9
  const alpha = sexo === 'F' ? -0.241 : -0.302
  const razao = creatininaMgDl / kappa

  const indexado =
    142 *
    Math.pow(Math.min(razao, 1), alpha) *
    Math.pow(Math.max(razao, 1), -1.2) *
    Math.pow(0.9938, idadeAnos) *
    (sexo === 'F' ? 1.012 : 1)

  const sc = superficieCorporal(pesoKg, alturaCm)
  return {
    indexado,
    absoluto: (indexado * sc) / 1.73,
    formula: 'CKD-EPI 2021',
  }
}

/**
 * Cockcroft-Gault — a equação sobre a qual as tabelas de ajuste de dose foram
 * originalmente construídas. Já devolve mL/min absoluto.
 *
 *   ClCr = ((140 − idade) × peso) / (72 × Scr) × 0,85 (se F)
 *
 * @param pesoParaCalculoKg peso a usar. No obeso, a literatura recomenda peso
 *        ajustado ou ideal; a escolha fica com o prescritor e é explicitada na
 *        interface, porque muda a dose.
 */
export function cockcroftGault(
  creatininaMgDl: number,
  idadeAnos: number,
  sexo: Sexo,
  pesoParaCalculoKg: number,
): ResultadoRenal {
  const clcr =
    (((140 - idadeAnos) * pesoParaCalculoKg) / (72 * creatininaMgDl)) *
    (sexo === 'F' ? 0.85 : 1)
  return { indexado: clcr, absoluto: clcr, formula: 'Cockcroft-Gault' }
}

// ---------------------------------------------------------------------------
// 3. VALIDAÇÃO
// ---------------------------------------------------------------------------

export interface EntradaRenal {
  creatininaMgDl?: number
  idadeAnos?: number
  sexo?: Sexo
  pesoKg?: number
  alturaCm?: number
}

/**
 * Faixas plausíveis. Fora delas o app se recusa a calcular: um clearance
 * derivado de um dado digitado errado é pior que nenhum clearance.
 */
export const LIMITES = {
  creatinina: [0.1, 25] as const,
  idade: [0, 120] as const,
  peso: [0.3, 300] as const,
  altura: [30, 250] as const,
}

export function validarEntradaRenal(e: EntradaRenal): string[] {
  const erros: string[] = []
  const checar = (
    valor: number | undefined,
    [min, max]: readonly [number, number],
    nome: string,
    unidade: string,
  ) => {
    if (valor === undefined || Number.isNaN(valor)) {
      erros.push(`Informe ${nome}.`)
    } else if (valor < min || valor > max) {
      erros.push(`${nome} fora da faixa aceita (${min}–${max} ${unidade}).`)
    }
  }
  checar(e.creatininaMgDl, LIMITES.creatinina, 'a creatinina', 'mg/dL')
  checar(e.idadeAnos, LIMITES.idade, 'a idade', 'anos')
  checar(e.pesoKg, LIMITES.peso, 'o peso', 'kg')
  checar(e.alturaCm, LIMITES.altura, 'a altura', 'cm')
  if (!e.sexo) erros.push('Informe o sexo.')
  return erros
}
