import { describe, expect, it } from 'vitest'
import { executarProtocolo } from '@/domain/engine'
import {
  TODAS_AS_REGRAS,
  DRUGS,
  FOCOS,
  ALTERNATIVAS_ALERGIA,
  SUBSTITUTOS_BETALACTAMICO,
  substitutoDe,
} from '@/data'
import { DOSES_POR_DIA } from '@/domain/dosing'
import { BETALACTAMICOS } from '@/domain/format'
import type { ClinicalInput } from '@/domain/types'

/**
 * Suíte dedicada às duas populações, pedida pelo SCIH.
 *
 * A divisão importa porque as duas se comportam de forma OPOSTA:
 *  - no ADULTO o protocolo é dose FIXA (não se calcula por peso);
 *  - na PEDIATRIA quase tudo é mg/kg e depende do peso.
 * Um teste que misture as duas esconde exatamente o erro que interessa pegar.
 */

const SECOES_ADULTO = ['6.1', '6.2', '6.5'] as const
const SECOES_PEDIATRICAS = ['6.3', '6.4', '6.6'] as const

/** Quantas doses por dia o intervalo representa. */
function dosesDia(intervalo: keyof typeof DOSES_POR_DIA): number {
  return DOSES_POR_DIA[intervalo]
}

/** Maior valor de uma Quantidade (escalar ou faixa). */
function teto(v: number | readonly [number, number]): number {
  return Array.isArray(v) ? v[1] : (v as number)
}

// ---------------------------------------------------------------------------
describe('ADULTO — o esquema é de dose fixa', () => {
  const regrasAdulto = TODAS_AS_REGRAS.filter((r) =>
    (SECOES_ADULTO as readonly string[]).includes(r.secao),
  )

  it('há regras de adulto nas três seções', () => {
    for (const s of SECOES_ADULTO) {
      expect(regrasAdulto.filter((r) => r.secao === s).length, s).toBeGreaterThan(0)
    }
  })

  /**
   * A única prescrição adulta legitimamente ponderal é a gentamicina de
   * sinergismo na endocardite. Se aparecer outra, ou o protocolo mudou ou
   * alguém copiou uma linha pediátrica para uma tabela de adulto.
   */
  it('a única prescrição adulta em mg/kg é a gentamicina de sinergismo', () => {
    const ponderais = regrasAdulto.flatMap((r) =>
      r.prescricoes.filter((p) => p.dosePonderal).map((p) => `${p.drugId} [${r.id}]`),
    )
    expect(ponderais).toEqual(['gentamicina [6.1.endocardite.1a]'])
  })

  it('toda prescrição adulta não ponderal traz dose fixa ou protocolo externo', () => {
    for (const r of regrasAdulto) {
      for (const p of r.prescricoes) {
        if (p.dosePonderal) continue
        const externo = DRUGS[p.drugId]?.protocoloExterno
        expect(
          p.doseFixa !== undefined || externo !== undefined || p.tabelaDose !== undefined,
          `${r.id} / ${p.drugId} sem dose e sem fonte externa`,
        ).toBe(true)
      }
    }
  })

  it('nenhuma dose fixa adulta ultrapassa o teto diário do fármaco', () => {
    for (const r of regrasAdulto) {
      for (const p of r.prescricoes) {
        const drug = DRUGS[p.drugId]
        if (!drug?.tetoDiarioMg || !p.doseFixa) continue
        const mg =
          p.doseFixa.unidade === 'g' ? teto(p.doseFixa.valor) * 1000 : teto(p.doseFixa.valor)
        const diaria = mg * dosesDia(p.intervalo)
        expect(
          diaria,
          `${drug.nome} em ${r.id}: ${diaria} mg/dia > teto ${drug.tetoDiarioMg}`,
        ).toBeLessThanOrEqual(drug.tetoDiarioMg)
      }
    }
  })

  it('o adulto não precisa de peso: executa sem pesoKg e devolve dose', () => {
    const entrada: ClinicalInput = {
      populacao: 'adulto',
      origem: 'comunitaria',
      setor: 'ps',
      focoId: 'pneumonia',
      modificadores: {},
    }
    const r = executarProtocolo(entrada)
    expect(r.recomendacao.prescricoes.length).toBeGreaterThan(0)
    // Ceftriaxona 2 g → 2000 mg, sem qualquer peso informado.
    expect(r.recomendacao.prescricoes[0]?.doseCalculadaMg).toBe(2000)
  })

  it('todos os focos de adulto são alcançáveis nas três seções', () => {
    for (const secao of SECOES_ADULTO) {
      const focos = new Set(
        TODAS_AS_REGRAS.filter((r) => r.secao === secao).map((r) => r.focoId),
      )
      for (const f of focos) expect(FOCOS[f], `${secao}/${f}`).toBeDefined()
    }
  })
})

// ---------------------------------------------------------------------------
describe('PEDIATRIA — o esquema é ponderal e exige peso', () => {
  const regrasPed = TODAS_AS_REGRAS.filter((r) =>
    (SECOES_PEDIATRICAS as readonly string[]).includes(r.secao),
  )

  it('há regras pediátricas nas três seções', () => {
    for (const s of SECOES_PEDIATRICAS) {
      expect(regrasPed.filter((r) => r.secao === s).length, s).toBeGreaterThan(0)
    }
  })

  /**
   * NOTA ³ do protocolo: mg/kg é dose POR ADMINISTRAÇÃO, salvo grafia "/dia".
   * Trocar essa base multiplica ou divide a dose pelo número de tomadas — é o
   * erro de maior impacto possível nesta base de dados.
   */
  it('base "dia" só aparece onde o protocolo grafa /dia', () => {
    const porDia = regrasPed.flatMap((r) =>
      r.prescricoes
        .filter((p) => p.dosePonderal?.base === 'dia')
        .map((p) => ({ regra: r, drugId: p.drugId })),
    )
    for (const { regra, drugId } of porDia) {
      expect(
        regra.textoOriginal.toLowerCase(),
        `${regra.id}/${drugId}: base 'dia' sem "/dia" no texto original`,
      ).toContain('/dia')
    }
  })

  it('nenhuma dose ponderal pediátrica é zero ou negativa', () => {
    for (const r of regrasPed) {
      for (const p of r.prescricoes) {
        if (!p.dosePonderal) continue
        const v = p.dosePonderal.valor
        const nums = Array.isArray(v) ? v : [v as number]
        for (const n of nums) expect(n, `${r.id}/${p.drugId}`).toBeGreaterThan(0)
      }
    }
  })

  it('faixas ponderais têm o menor valor antes do maior', () => {
    for (const r of regrasPed) {
      for (const p of r.prescricoes) {
        const v = p.dosePonderal?.valor
        if (!Array.isArray(v)) continue
        expect(v[0], `${r.id}/${p.drugId}: faixa invertida`).toBeLessThan(v[1])
      }
    }
  })

  /**
   * Cada foco é exercitado NA SEÇÃO EM QUE ELE EXISTE — a 6.3 é comunitária e
   * a 6.6 é de UTI, e elas não cobrem os mesmos focos. Testar todo foco contra
   * uma única seção acusaria falha onde o protocolo simplesmente não prevê a
   * combinação.
   */
  it('calcula em 10 kg e em 30 kg sem quebrar, em cada foco na sua seção', () => {
    const rota: Record<string, { origem: 'comunitaria' | 'iras'; setor: 'ps' | 'enfermaria' | 'uti' }> = {
      '6.3': { origem: 'comunitaria', setor: 'ps' },
      '6.4': { origem: 'iras', setor: 'enfermaria' },
      '6.6': { origem: 'iras', setor: 'uti' },
    }
    let exercitados = 0
    for (const peso of [10, 30]) {
      for (const regra of regrasPed) {
        const r = rota[regra.secao]
        if (!r) continue
        const entrada: ClinicalInput = {
          populacao: 'pediatrico',
          origem: r.origem,
          setor: r.setor,
          focoId: regra.focoId,
          pesoKg: peso,
          modificadores: {},
        }
        const saida = executarProtocolo(entrada)
        expect(saida.recomendacao, `${regra.id} @ ${peso}kg`).toBeDefined()
        expect(
          saida.recomendacao.prescricoes.length,
          `${regra.id} @ ${peso}kg sem prescrição`,
        ).toBeGreaterThan(0)
        exercitados++
      }
    }
    expect(exercitados).toBeGreaterThan(40)
  })

  /**
   * Salvaguarda pediátrica: a dose por peso nunca deve ultrapassar em silêncio
   * a maior dose adulta. O app avisa — nunca trunca sozinho.
   */
  it('num adolescente de 60 kg o app AVISA quando a dose supera a adulta', () => {
    const r = executarProtocolo({
      populacao: 'pediatrico',
      origem: 'comunitaria',
      setor: 'ps',
      focoId: 'itu',
      pesoKg: 60,
      modificadores: {},
    })
    expect(r.recomendacao.alertas.some((a) => a.titulo.includes('acima da dose adulta'))).toBe(
      true,
    )
  })

  it('metronidazol e clindamicina ficam na faixa de 30 a 40 mg/kg/dia', () => {
    for (const r of regrasPed) {
      for (const p of r.prescricoes) {
        if (!['metronidazol', 'clindamicina'].includes(p.drugId)) continue
        if (!p.dosePonderal || p.dosePonderal.base !== 'dose') continue
        const v = p.dosePonderal.valor
        const [min, max] = Array.isArray(v) ? v : [v as number, v as number]
        const diaMin = min * dosesDia(p.intervalo)
        const diaMax = max * dosesDia(p.intervalo)
        expect(diaMin, `${r.id}/${p.drugId}: ${diaMin} mg/kg/dia é baixo`).toBeGreaterThanOrEqual(
          30,
        )
        expect(diaMax, `${r.id}/${p.drugId}: ${diaMax} mg/kg/dia é alto`).toBeLessThanOrEqual(45)
      }
    }
  })
})

// ---------------------------------------------------------------------------
describe('ALERGIA — alternativa para toda situação, nas duas populações', () => {
  it('todo foco do catálogo tem alternativa sem betalactâmico', () => {
    const cobertos = new Set(ALTERNATIVAS_ALERGIA.map((a) => a.focoId))
    const faltando = Object.keys(FOCOS).filter((f) => !cobertos.has(f))
    expect(faltando, `focos sem alternativa: ${faltando.join(', ')}`).toEqual([])
  })

  /**
   * O ponto do modo alergia é NÃO oferecer outro betalactâmico. Aztreonam é
   * monobactâmico e é a exceção aceita — não tem reatividade cruzada relevante.
   */
  it('nenhuma alternativa proposta oferece um betalactâmico', () => {
    const proibidos = [...BETALACTAMICOS]
      .map((id) => DRUGS[id]?.nome)
      .filter((n): n is string => Boolean(n))
    for (const alt of ALTERNATIVAS_ALERGIA) {
      const texto = `${alt.esquema} ${alt.ressalva ?? ''}`.toLowerCase()
      for (const nome of proibidos) {
        // A menção pode existir para DESACONSELHAR; o que não pode é ser a
        // droga proposta em destaque (__negrito__).
        const propostoEmDestaque = new RegExp(`__[^_]*${nome.toLowerCase()}[^_]*__`).test(texto)
        expect(
          propostoEmDestaque,
          `${alt.focoId} propõe ${nome}, que é betalactâmico`,
        ).toBe(false)
      }
    }
  })

  it('toda regra com betalactâmico tem alternativa para o seu foco', () => {
    const cobertos = new Set(ALTERNATIVAS_ALERGIA.map((a) => a.focoId))
    for (const r of TODAS_AS_REGRAS) {
      const temBeta = r.prescricoes.some((p) => BETALACTAMICOS.has(p.drugId))
      if (!temBeta) continue
      expect(cobertos.has(r.focoId), `${r.id} (foco ${r.focoId}) sem alternativa`).toBe(true)
    }
  })

  it('os focos sem bom substituto estão marcados como incertos', () => {
    const incertos = new Set(
      ALTERNATIVAS_ALERGIA.filter((a) => a.incerto).map((a) => a.focoId),
    )
    // Meningite e PAV são os dois em que a troca não betalactâmica é frágil.
    expect(incertos.has('meningite')).toBe(true)
    expect(incertos.has('pnm_vm')).toBe(true)
  })
})

// ---------------------------------------------------------------------------
describe('NEONATO — divergências de dose precisam estar sinalizadas na linha', () => {
  const regras66 = TODAS_AS_REGRAS.filter((r) => r.secao === '6.6')

  /**
   * REGRESSÃO REAL: o aviso da divergência do cefepime neonatal vivia apenas
   * dentro das duas regras "Se ISC". Quando elas foram removidas, o aviso saiu
   * junto e a seção de UTI neonatal passou a exibir 150 mg/kg/dia sem ressalva,
   * contra os 60 mg/kg/dia do quadro institucional. Este teste existe para que
   * isso não volte a acontecer em silêncio.
   */
  it('toda prescrição de cefepime na 6.6 avisa sobre a dose neonatal', () => {
    const cefepimes = regras66.flatMap((r) =>
      r.prescricoes.filter((p) => p.drugId === 'cefepime').map((p) => ({ regra: r.id, p })),
    )
    expect(cefepimes.length).toBeGreaterThan(0)
    for (const { regra, p } of cefepimes) {
      const texto = (p.observacoes ?? []).join(' ')
      expect(texto, `${regra}: cefepime sem ressalva neonatal`).toMatch(/NEONATO/i)
      expect(texto, `${regra}: ressalva sem a dose do quadro`).toContain('30 mg/kg')
    }
  })

  /**
   * A bula da piperacilina começa aos 2 meses. Como as linhas de 6.6 não
   * filtram idade, o recém-nascido alcança 300–400 mg/kg/dia justificados por
   * uma referência que não o cobre.
   */
  it('toda piperacilina da 6.6 avisa que a bula não cobre o neonato', () => {
    const pipes = regras66.flatMap((r) =>
      r.prescricoes
        .filter((p) => p.drugId === 'piperacilina_tazobactam')
        .map((p) => ({ regra: r.id, p })),
    )
    expect(pipes.length).toBeGreaterThan(0)
    for (const { regra, p } of pipes) {
      const texto = (p.observacoes ?? []).join(' ')
      expect(texto, `${regra}: piperacilina sem ressalva neonatal`).toMatch(/NEONATO/i)
    }
  })

  /** As regras condicionadas a "ISC" foram removidas por definição do SCIH. */
  it('nenhuma regra de sepse neonatal depende mais de ISC', () => {
    for (const r of regras66) {
      expect(r.id, 'regra -isc deveria ter sido removida').not.toMatch(/-isc$/)
      expect(r.condicaoLabel, `${r.id} ainda cita ISC`).not.toMatch(/\bISC\b/)
    }
  })
})

// ---------------------------------------------------------------------------
describe('consolidação das fichas e dose única da piperacilina', () => {
  it('a piperacilina pediátrica tem UMA única dose em todas as seções', () => {
    const doses = new Set<string>()
    for (const r of TODAS_AS_REGRAS) {
      if (!(SECOES_PEDIATRICAS as readonly string[]).includes(r.secao)) continue
      for (const p of r.prescricoes) {
        if (p.drugId !== 'piperacilina_tazobactam' || !p.dosePonderal) continue
        doses.add(`${String(p.dosePonderal.valor)} mg/kg/${p.dosePonderal.base} ${p.intervalo}`)
      }
    }
    expect([...doses]).toEqual(['75 mg/kg/dose q6h'])
  })

  it('todo betalactâmico do protocolo tem substituto direto para alergia', () => {
    const usados = new Set(
      TODAS_AS_REGRAS.flatMap((r) =>
        r.prescricoes.map((p) => p.drugId).filter((id) => BETALACTAMICOS.has(id)),
      ),
    )
    const semSubstituto = [...usados].filter((id) => !substitutoDe(id))
    expect(semSubstituto, `sem substituto: ${semSubstituto.join(', ')}`).toEqual([])
  })

  it('nenhum substituto direto propõe outro betalactâmico', () => {
    const nomesBeta = [...BETALACTAMICOS]
      .map((id) => DRUGS[id]?.nome?.toLowerCase())
      .filter((n): n is string => Boolean(n))
    for (const s of SUBSTITUTOS_BETALACTAMICO) {
      for (const nome of nomesBeta) {
        const emDestaque = new RegExp(`__[^_]*${nome}[^_]*__`).test(s.substituto.toLowerCase())
        expect(emDestaque, `${s.drugId} propõe ${nome}`).toBe(false)
      }
    }
  })
})
