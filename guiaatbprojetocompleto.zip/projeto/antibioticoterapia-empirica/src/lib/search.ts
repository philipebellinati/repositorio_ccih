import type { GrupoId, GuideCard } from '@/data/cards'
import { CARDS } from '@/data/cards'
import {
  REGRAS_POR_SECAO,
  FOCOS,
  DRUGS,
  DOSES_PEDIATRICAS,
  RESTRITOS,
  ALTERNATIVAS_ALERGIA,
} from '@/data'
import { AJUSTE_RENAL } from '@/data/ajuste-renal'
import { VANCO_ADULTO, VANCO_NEOPED } from '@/data/vancomicina'
import type { ProtocolRule } from '@/domain/types'
import { normalizar } from './utils'

/**
 * Busca do guia — "buscar pela cirurgia ou pelo antibiótico e cair direto na dose".
 *
 * Aqui o análogo de "cirurgia" é o FOCO de infecção (pneumonia, ITU, IPCS…) e o
 * de "antibiótico" é o princípio ativo ou o nome comercial (Tazocin). A busca
 * casa em três níveis e devolve, além das fichas, QUAIS linhas do protocolo
 * casaram — para que a tabela já abra filtrada na dose procurada.
 */

/** Texto indexável de uma linha do protocolo. */
function textoDaRegra(regra: ProtocolRule): string {
  const foco = FOCOS[regra.focoId]
  const farmacos = regra.prescricoes.flatMap((p) => {
    const d = DRUGS[p.drugId]
    return d ? [d.nome, ...(d.sinonimos ?? []), d.classe] : [p.drugId]
  })
  return normalizar(
    [foco?.nome, foco?.descricao, regra.condicaoLabel, regra.textoOriginal, regra.secao, ...farmacos]
      .filter(Boolean)
      .join(' '),
  )
}

/** Índice pré-computado: id da regra → texto normalizado. */
const INDICE_REGRAS: Map<string, string> = new Map(
  Object.values(REGRAS_POR_SECAO)
    .flat()
    .map((r) => [r.id, textoDaRegra(r)]),
)

/** Texto indexável de uma ficha, exceto suas tabelas. */
function textoDoCard(card: GuideCard): string {
  const blocos = card.blocos.flatMap((b) => {
    switch (b.tipo) {
      case 'regras':
        return [b.titulo, ...b.itens.flatMap((i) => [i.titulo, i.texto])]
      case 'lista':
        return [b.titulo ?? '', ...b.itens]
      case 'definicoes':
        return [b.titulo, ...b.itens.flatMap((i) => [i.termo, i.def])]
      case 'alerta':
        return [b.titulo, b.texto]
      case 'tabela':
        return [b.titulo]

      /*
       * Blocos de componente: o conteúdo clínico vive no DADO, não no card.
       * Sem indexar aqui, fármacos como polimixina, teicoplanina, voriconazol
       * ou ceftolozana ficavam invisíveis à busca — só apareciam para quem já
       * soubesse navegar até a ficha. Era a queixa "só acho depois de usar o
       * clearance".
       */
      case 'doses-pediatricas':
        return DOSES_PEDIATRICAS.flatMap((d) => [
          d.nome,
          d.classe ?? '',
          ...(d.sinonimos ?? []),
          ...d.clearance.map((c) => c.dose),
        ])

      case 'renal':
        return AJUSTE_RENAL.flatMap((a) => [
          a.nome,
          a.classe,
          a.doseHabitual ?? '',
          a.doseMaxima ?? '',
        ])

      case 'restritos':
        return RESTRITOS.flatMap((r) => [
          r.nome,
          r.classe,
          ...(r.sinonimos ?? []),
          r.alvo,
          r.doseAdulto ?? '',
          r.dosePediatrica ?? '',
        ])

      case 'alergia-focos':
        return ALTERNATIVAS_ALERGIA.flatMap((a) => [a.foco, a.esquema, a.ressalva ?? ''])

      case 'vancomicina':
        return [
          'vancomicina',
          'vancocinemia',
          'nível de vale',
          'dose de ataque',
          VANCO_ADULTO.ataque.dose,
          VANCO_NEOPED.semAtaque,
        ]

      case 'amicacina-neonatal':
        return ['amicacina', 'neonatal', 'idade gestacional', 'idade pós-natal']

      case 'peso-aminoglicosideo':
        return ['peso ajustado', 'peso ideal', 'devine', 'amicacina', 'gentamicina']

      case 'calculadora':
        return ['dose por peso', 'mg/kg', 'dose fixa adulto', 'teto de dose']

      default:
        return []
    }
  })
  return normalizar([card.titulo, card.subtitulo, ...(card.keywords ?? []), ...blocos].join(' '))
}

const INDICE_CARDS: Map<string, string> = new Map(CARDS.map((c) => [c.id, textoDoCard(c)]))

export interface ResultadoBusca {
  card: GuideCard
  /** Ids das linhas do protocolo que casaram — vazio quando o casamento foi no texto da ficha. */
  regrasCasadas: Set<string>
  /** A ficha deve abrir automaticamente (houve casamento explícito na busca). */
  autoExpandir: boolean
}

/**
 * Filtra o guia por texto livre e por grupo (chip).
 *
 * @param query  termo digitado; string vazia devolve tudo
 * @param grupo  chip selecionado; `null` = todos
 */
export function buscarNoGuia(query: string, grupo: GrupoId | null): ResultadoBusca[] {
  const termos = normalizar(query).split(/\s+/).filter(Boolean)

  return CARDS.filter((card) => grupo === null || card.grupo === grupo)
    .map((card): ResultadoBusca => {
      if (termos.length === 0) {
        return { card, regrasCasadas: new Set(), autoExpandir: false }
      }

      const textoCard = INDICE_CARDS.get(card.id) ?? ''
      const casouNoCard = termos.every((t) => textoCard.includes(t))

      // Casamento dentro das tabelas: percorre as regras da seção referenciada.
      const regrasCasadas = new Set<string>()
      for (const bloco of card.blocos) {
        if (bloco.tipo !== 'tabela') continue
        for (const regra of REGRAS_POR_SECAO[bloco.secaoId] ?? []) {
          const texto = INDICE_REGRAS.get(regra.id) ?? ''
          if (termos.every((t) => texto.includes(t))) regrasCasadas.add(regra.id)
        }
      }

      return {
        card,
        regrasCasadas,
        autoExpandir: regrasCasadas.size > 0 || casouNoCard,
      }
    })
    .filter((r) => {
      const termos2 = normalizar(query).split(/\s+/).filter(Boolean)
      if (termos2.length === 0) return true
      return r.autoExpandir
    })
}

/**
 * Sugestões rápidas exibidas sob a busca vazia — atalhos para os termos que o
 * plantonista mais digita.
 */
export const SUGESTOES: readonly string[] = [
  'pneumonia',
  'PAV',
  'ITU',
  'IPCS',
  'meningite',
  'sepse',
  'cefepime',
  'meropenem',
  'vancomicina',
  'piperacilina',
]
