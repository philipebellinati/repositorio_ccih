/**
 * Antimicrobianos de uso RESTRITO — não liberados como terapia empírica.
 *
 * Diferente do meropenem (que é restrito mas PODE entrar empiricamente com
 * formulário), estes só devem ser prescritos COM identificação microbiológica:
 * são a última linha de reserva do hospital. Liberá-los no empírico acelera a
 * seleção de resistência e queima a reserva terapêutica.
 *
 * A lista foi definida pelo SCIH. Os nomes comerciais entram só como sinônimo
 * de busca — a exibição usa sempre o princípio ativo.
 */

export interface Restrito {
  id: string
  nome: string
  sinonimos?: readonly string[]
  classe: string
  /** Alvo microbiológico que justifica o uso — o "só com cultura para...". */
  alvo: string
  /** Observação clínica adicional, quando útil. */
  observacao?: string
  /** Dose adulta usual, com a via e o tempo de infusão. */
  doseAdulto?: string
  /** Ajuste por função renal, resumido por faixa de ClCr. */
  doseRenal?: readonly string[]
  /** Dose pediátrica, quando estabelecida. */
  dosePediatrica?: string
  /**
   * De onde veio a dose. Estes agentes NÃO constam do protocolo institucional;
   * a dose vem de bula/literatura e por isso é sempre rotulada — para ninguém
   * ler como se fosse padronização do SCIH.
   */
  fonteDose?: string
}

export const RESTRITOS: readonly Restrito[] = [
  {
    id: 'ceftazidima_avibactam',
    nome: 'Ceftazidima/avibactam',
    sinonimos: ['Torgena'],
    classe: 'Cefalosporina + inibidor de betalactamase (diazabiciclooctano)',
    alvo: 'Enterobactérias produtoras de KPC e de ESBL/AmpC documentadas.',
    observacao:
      'É um betalactâmico — contraindicado na alergia grave a betalactâmicos. ' +
      'Sem ação contra metalo-betalactamases (NDM/IMP); nesses casos, associar aztreonam.',
    doseAdulto: '2,5 g (2 g ceftazidima + 0,5 g avibactam) EV 8/8h, em infusão de 2 h',
    doseRenal: [
      'ClCr > 50: 2,5 g 8/8h',
      'ClCr 31–50: 1,25 g 8/8h',
      'ClCr 16–30: 0,94 g 12/12h',
      'ClCr 6–15: 0,94 g 24/24h',
      'ClCr ≤ 5: 0,94 g 48/48h',
    ],
    dosePediatrica:
      '≥ 3 meses: 50 mg/kg/dose do componente ceftazidima, 8/8h (máximo 2 g por dose)',
    fonteDose: 'Bula do produto — o protocolo institucional não padroniza este agente.',
  },
  {
    id: 'ceftolozana_tazobactam',
    nome: 'Ceftolozana/tazobactam',
    sinonimos: ['Zerbaxa'],
    classe: 'Cefalosporina + inibidor de betalactamase',
    alvo: 'Pseudomonas aeruginosa multirresistente documentada.',
    observacao:
      'É um betalactâmico. Para cobrir anaeróbios em foco abdominal, associar metronidazol.',
    doseAdulto:
      '1,5 g (1 g ceftolozana + 0,5 g tazobactam) EV 8/8h em ITU complicada e ' +
      'infecção intra-abdominal; 3 g EV 8/8h na PNEUMONIA NOSOCOMIAL. Infusão de 1 h.',
    doseRenal: [
      'ClCr > 50: dose plena',
      'ClCr 30–50: 750 mg 8/8h (1,5 g 8/8h na pneumonia)',
      'ClCr 15–29: 375 mg 8/8h (750 mg 8/8h na pneumonia)',
      'Hemodiálise: ataque de 750 mg, depois 150 mg 8/8h',
    ],
    dosePediatrica: '20 mg/kg/dose do componente ceftolozana, 8/8h — 30 mg/kg na pneumonia',
    fonteDose: 'Bula do produto — o protocolo institucional não padroniza este agente.',
  },
  {
    id: 'linezolida',
    nome: 'Linezolida',
    classe: 'Oxazolidinona',
    alvo: 'Enterococo resistente à vancomicina (VRE); MRSA selecionado.',
    observacao:
      'Bacteriostática; risco de mielossupressão em uso prolongado e de síndrome ' +
      'serotoninérgica com ISRS.',
    doseAdulto: '600 mg EV ou VO 12/12h, em infusão de 30 a 120 min',
    doseRenal: ['Não requer ajuste por função renal, em nenhuma faixa de ClCr.'],
    dosePediatrica: '10 mg/kg/dose 8/8h (máximo 600 mg por dose)',
    fonteDose: 'Bula e quadro de doses pediátricas do HU.',
  },
  {
    id: 'anfotericina_lipossomal',
    nome: 'Anfotericina B lipossomal',
    classe: 'Antifúngico poliênico (formulação lipídica)',
    alvo:
      'Fungo documentado com toxicidade renal, refratariedade ou contraindicação à ' +
      'formulação convencional.',
    observacao: 'A anfotericina B desoxicolato permanece de acesso mais amplo.',
    doseAdulto: '3 a 5 mg/kg EV 24/24h, em infusão de 120 min',
    doseRenal: [
      'ClCr > 10: 3–5 mg/kg 24/24h (a formulação lipossomal é menos nefrotóxica)',
      'ClCr < 10: 3–5 mg/kg 48/48h',
    ],
    dosePediatrica: '3 a 5 mg/kg 24/24h; neonato 5 mg/kg 24/24h',
    fonteDose: 'Quadro de doses pediátricas do HU (base Sanford).',
  },
  {
    id: 'voriconazol',
    nome: 'Voriconazol',
    classe: 'Antifúngico triazólico',
    alvo: 'Aspergilose e fungos filamentosos documentados.',
    observacao: 'Requer monitoramento de nível sérico e vigilância de interações (CYP).',
    doseAdulto:
      'Ataque 6 mg/kg EV 12/12h nas primeiras 24 h; manutenção 4 mg/kg EV 12/12h',
    doseRenal: [
      'ClCr ≥ 50: sem ajuste',
      'ClCr < 50: NÃO usar a forma EV — o veículo (ciclodextrina) se acumula. Trocar para VO.',
    ],
    dosePediatrica: '6 mg/kg/dose 12/12h nas primeiras 48 h, depois 4 mg/kg/dose 12/12h',
    fonteDose: 'Quadro de doses pediátricas do HU (base Sanford) e bula.',
  },
  {
    id: 'ampicilina_sulbactam',
    nome: 'Ampicilina/sulbactam',
    sinonimos: ['Unasyn'],
    classe: 'Aminopenicilina + inibidor de betalactamase',
    alvo: 'Acinetobacter baumannii — o componente ativo contra o Acinetobacter é o sulbactam.',
    observacao:
      'A restrição vale para a indicação anti-Acinetobacter, em dose alta e com ' +
      'identificação. É um betalactâmico.',
    doseAdulto:
      'Infecção usual: 3 g (2 g ampicilina + 1 g sulbactam) EV 6/6h. Contra ' +
      'Acinetobacter, a literatura usa sulbactam em DOSE ALTA — até 9 g de ' +
      'sulbactam/dia — sempre com a Infectologia.',
    doseRenal: [
      'ClCr > 50: 75 mg/kg 6/6h',
      'ClCr 10–50: 75 mg/kg 12/12h',
      'ClCr < 10: 75 mg/kg 24/24h',
    ],
    dosePediatrica: '75 mg/kg/dose 6/6h; neonato conforme idade e peso',
    fonteDose: 'Quadro de doses pediátricas do HU (base Sanford).',
  },
]
