/**
 * Conversão das doses ponderais das tabelas de ajuste em miligramas.
 *
 * As tabelas institucionais expressam várias condutas em mg/kg — "7,5 mg/kg a
 * cada 6 h", "5 a 12,5 mg/kg a cada 8 h", "5–20 mg/kg/dia". Deixar o cálculo a
 * cargo do plantonista à beira-leito é justamente onde nasce erro de dose,
 * ainda mais quando o peso de referência não é o peso real (aminoglicosídeos
 * usam peso ajustado).
 *
 * Este módulo lê a dose como está escrita na tabela e devolve o valor em mg,
 * preservando faixas e distinguindo dose POR ADMINISTRAÇÃO de dose DIÁRIA.
 */

import { formatarNumero } from './dosing'

export interface DosePonderalConvertida {
  /** Menor valor em mg. Igual a `max` quando a dose é escalar. */
  min: number
  /** Maior valor em mg. */
  max: number
  /** A tabela grafou "/dia": o valor é a dose diária, não a de cada tomada. */
  porDia: boolean
  /** Texto pronto, ex.: "= 638 mg por dose" ou "= 360 – 1.440 mg por dia". */
  texto: string
}

/**
 * Captura o valor em mg/kg no início da conduta.
 *
 * Aceita escalar ("7,5 mg/kg") e faixa em qualquer das grafias que a tabela
 * usa: "5 a 12,5 mg/kg", "5–20 mg/kg", "2,5 - 6,25 mg/kg". A vírgula decimal do
 * português é convertida antes do parse.
 */
const PADRAO_MG_KG = /(\d+(?:[.,]\d+)?)\s*(?:(?:a|–|-|até)\s*(\d+(?:[.,]\d+)?)\s*)?mg\s*\/\s*kg/i

function paraNumero(bruto: string): number {
  return Number(bruto.replace(',', '.'))
}

/**
 * Converte a conduta de uma faixa da tabela em miligramas para o paciente.
 *
 * @param dose    texto da conduta, como consta na tabela
 * @param pesoKg  peso de referência já escolhido pelo chamador (real, ideal ou
 *                ajustado — a decisão é do fármaco, não desta função)
 * @returns `undefined` quando a conduta não é ponderal (dose fixa, "sem ajuste",
 *          "contraindicada"), caso em que não há nada a calcular
 */
export function converterDosePonderal(
  dose: string,
  pesoKg: number,
): DosePonderalConvertida | undefined {
  if (!Number.isFinite(pesoKg) || pesoKg <= 0) return undefined

  const m = PADRAO_MG_KG.exec(dose)
  if (!m || m[1] === undefined) return undefined

  const inferior = paraNumero(m[1])
  const superior = m[2] !== undefined ? paraNumero(m[2]) : inferior
  if (!Number.isFinite(inferior) || !Number.isFinite(superior)) return undefined

  // "mg/kg/dia" e "mg/kg/dose" são grafias distintas na mesma tabela; só a
  // primeira precisa ser rotulada como total do dia.
  const porDia = /mg\s*\/\s*kg\s*\/\s*dia/i.test(dose)

  const arredondar = (v: number) => (v < 10 ? Math.round(v * 10) / 10 : Math.round(v))
  const min = arredondar(inferior * pesoKg)
  const max = arredondar(superior * pesoKg)

  const valor = min === max ? formatarNumero(min) : `${formatarNumero(min)} – ${formatarNumero(max)}`
  const sufixo = porDia ? 'por dia' : 'por dose'

  return { min, max, porDia, texto: `= ${valor} mg ${sufixo}` }
}

/**
 * Piperacilina/tazobactam: converte a dose do componente PIPERACILINA no total
 * da apresentação, na proporção 8:1.
 *
 * A prescrição pediátrica é calculada apenas sobre a piperacilina, mas o frasco
 * dispensado contém os dois componentes — quem prepara precisa do total.
 *
 * @param mgPiperacilina dose de piperacilina, em mg
 */
export function totalPipTazo(mgPiperacilina: number): {
  piperacilina: number
  tazobactam: number
  total: number
} {
  const tazobactam = mgPiperacilina / 8
  return {
    piperacilina: mgPiperacilina,
    tazobactam: Math.round(tazobactam * 10) / 10,
    total: Math.round((mgPiperacilina + tazobactam) * 10) / 10,
  }
}
