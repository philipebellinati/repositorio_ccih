import type { ProtocolRule, SecaoId } from '@/domain/types'
import { SECAO_6_1 } from './tables/secao-6-1'
import { SECAO_6_2 } from './tables/secao-6-2'
import { SECAO_6_3 } from './tables/secao-6-3'
import { SECAO_6_4 } from './tables/secao-6-4'
import { SECAO_6_5 } from './tables/secao-6-5'
import { SECAO_6_6 } from './tables/secao-6-6'

/** Registro central das regras, indexado pela seção do protocolo. */
export const REGRAS_POR_SECAO: Record<SecaoId, readonly ProtocolRule[]> = {
  '6.1': SECAO_6_1,
  '6.2': SECAO_6_2,
  '6.3': SECAO_6_3,
  '6.4': SECAO_6_4,
  '6.5': SECAO_6_5,
  '6.6': SECAO_6_6,
}

/** Todas as regras em lista única — usado pela busca da Consulta Rápida. */
export const TODAS_AS_REGRAS: readonly ProtocolRule[] = Object.values(REGRAS_POR_SECAO).flat()

export * from './drugs'
export * from './protocol.meta'
export * from './doses-pediatricas'
export * from './restritos'
export * from './alergia'
export * from './criterios'
