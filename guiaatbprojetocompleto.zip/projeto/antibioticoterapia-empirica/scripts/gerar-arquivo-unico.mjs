/**
 * Empacota o build de produção num único arquivo HTML self-contained.
 *
 * Serve para distribuir o guia onde não há um servidor estático próprio
 * (Artifact, anexo de e-mail, pendrive, intranet sem deploy). Como o app não
 * faz nenhuma requisição de rede — todo o conteúdo clínico vive no bundle —
 * o arquivo resultante abre e funciona offline por construção.
 *
 * Uso:  npm run build && node scripts/gerar-arquivo-unico.mjs
 * Saída: dist-single/guia-antibioticoterapia-empirica.html
 */
import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const raiz = path.dirname(path.dirname(fileURLToPath(import.meta.url)))
const dist = path.join(raiz, 'dist')
const assets = path.join(dist, 'assets')

const arquivos = readdirSync(assets)
const nomeCss = arquivos.find((f) => f.endsWith('.css'))
const nomeJs = arquivos.find((f) => f.endsWith('.js'))
if (!nomeCss || !nomeJs) {
  throw new Error('Build não encontrado em dist/assets — rode `npm run build` antes.')
}

const css = readFileSync(path.join(assets, nomeCss), 'utf8')
let js = readFileSync(path.join(assets, nomeJs), 'utf8')

// Uma ocorrência literal de "</script" dentro de uma string JS encerraria a tag
// prematuramente. O escape abaixo é inerte para o parser JS e neutro para o HTML.
js = js.replace(/<\/script/gi, '<\\/script')

const ocorrencias = (js.match(/<\\\/script/gi) ?? []).length
if (ocorrencias > 0) {
  console.log(`${ocorrencias} ocorrência(s) de "</script" escapada(s) no bundle`)
}

// O documento é montado à mão em vez de reaproveitar dist/index.html: aquele
// arquivo referencia manifest, service worker e ícones por caminho absoluto,
// que não existem quando o guia é servido como arquivo solto.
const html = `<title>Antibioticoterapia Empírica — Guia de consulta rápida | SCIH</title>
<style>
/* Reset mínimo: o host pode injetar um tema próprio, e o guia é
   deliberadamente monotema (navy institucional, espelhando o guia impresso).
   Fixar html/body impede que um tema claro do hospedeiro vaze pelas bordas. */
html, body {
  margin: 0;
  padding: 0;
  background-color: #0a1626;
  min-height: 100%;
}
</style>
<style>${css}</style>
<div id="root"></div>
<script type="module">${js}</script>
`

const saida = path.join(raiz, 'dist-single')
mkdirSync(saida, { recursive: true })
const destino = path.join(saida, 'guia-antibioticoterapia-empirica.html')
writeFileSync(destino, html, 'utf8')

const kb = (Buffer.byteLength(html, 'utf8') / 1024).toFixed(0)
console.log(`gerado: ${destino} (${kb} KB, self-contained)`)
