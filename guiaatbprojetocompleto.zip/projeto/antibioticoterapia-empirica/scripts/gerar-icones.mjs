/**
 * Gera os PNGs do PWA a partir de public/icon.svg.
 *
 * Rodar apenas quando o ícone mudar:  node scripts/gerar-icones.mjs
 * Requer Chromium via Playwright (já presente no ambiente de build).
 */
import { chromium } from 'playwright'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const raiz = path.dirname(path.dirname(fileURLToPath(import.meta.url)))
const svg = readFileSync(path.join(raiz, 'public', 'icon.svg'), 'utf8')
const TAMANHOS = [180, 192, 512]

const navegador = await chromium.launch()
try {
  for (const tamanho of TAMANHOS) {
    const pagina = await navegador.newPage({
      viewport: { width: tamanho, height: tamanho },
      deviceScaleFactor: 1,
    })
    await pagina.setContent(
      `<style>html,body{margin:0;padding:0;background:#0a1626}svg{display:block;width:${tamanho}px;height:${tamanho}px}</style>${svg}`,
    )
    await pagina.screenshot({ path: path.join(raiz, 'public', `icon-${tamanho}.png`) })
    await pagina.close()
    console.log(`icon-${tamanho}.png gerado`)
  }
} finally {
  await navegador.close()
}
