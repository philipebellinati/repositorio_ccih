import { Fragment, type ReactNode } from 'react'

/**
 * Renderiza a marcação leve usada no conteúdo das fichas:
 * `**texto**` → negrito; `__texto__` → destaque azul; `*texto*` → itálico.
 *
 * O itálico existe para os nomes científicos, que por convenção editorial vão
 * em itálico — *S. pneumoniae*, *Pseudomonas aeruginosa*.
 *
 * Optou-se por um formatador próprio de dez linhas em vez de um parser de
 * Markdown: o conteúdo é curto, controlado por nós e não deve permitir HTML
 * arbitrário — inserir `dangerouslySetInnerHTML` num app clínico seria trocar
 * segurança por conveniência sem necessidade.
 */
export function MarkedText({ texto }: { texto: string }): ReactNode {
  // A alternativa de negrito vem ANTES da de itálico: sem isso, `**x**` seria
  // consumido como itálico vazio seguido de itálico.
  const partes = texto.split(/(\*\*[^*]+\*\*|__[^_]+__|\*[^*]+\*)/g)
  return (
    <>
      {partes.map((parte, i) => {
        if (parte.startsWith('**') && parte.endsWith('**')) {
          return (
            <strong key={i} className="font-semibold text-foreground">
              {parte.slice(2, -2)}
            </strong>
          )
        }
        if (parte.startsWith('__') && parte.endsWith('__')) {
          return (
            <span key={i} className="font-semibold text-primary">
              {parte.slice(2, -2)}
            </span>
          )
        }
        if (parte.length > 2 && parte.startsWith('*') && parte.endsWith('*')) {
          return (
            <em key={i} className="italic">
              {parte.slice(1, -1)}
            </em>
          )
        }
        return <Fragment key={i}>{parte}</Fragment>
      })}
    </>
  )
}
