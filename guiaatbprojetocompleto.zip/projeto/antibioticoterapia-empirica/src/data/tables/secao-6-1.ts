import type { ProtocolRule } from '@/domain/types'
import { CRITERIO_MACROLIDEO_ADULTO } from '../criterios'

/**
 * 6.1 — INFECÇÕES COMUNITÁRIAS, ADULTO.
 *
 * Transcrição literal da tabela da página 2 do protocolo. Doses fixas (não
 * ponderais), exceto Gentamicina na endocardite.
 *
 * Convenção de prioridade: linhas condicionais recebem prioridade > 0 e a linha
 * "1ª opção" recebe 0, funcionando como fallback quando nenhuma condição
 * clínica específica está presente.
 */
export const SECAO_6_1: readonly ProtocolRule[] = [
  // --- Pneumonia -----------------------------------------------------------
  {
    id: '6.1.pneumonia.aspirativa',
    secao: '6.1',
    focoId: 'pneumonia',
    condicaoLabel: 'Aspirativa',
    // Pneumonia aspirativa exige cobertura de anaeróbios de via aérea superior;
    // no protocolo ela prevalece sobre a linha de "uso de ATB prévio".
    prioridade: 20,
    match: (m) => m.aspirativa === true,
    prescricoes: [
      { drugId: 'clindamicina', doseFixa: { valor: 600, unidade: 'mg' }, via: 'EV', intervalo: 'q6h' },
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q24h' },
    ],
    textoOriginal: 'Clindamicina 600mg EV 6/6h + Ceftriaxona 2g EV 24/24h',
  },
  {
    id: '6.1.pneumonia.atb-previo',
    secao: '6.1',
    focoId: 'pneumonia',
    condicaoLabel: 'Uso de ATB prévio',
    // Exposição prévia seleciona flora menos sensível → escalona para cefepime.
    prioridade: 10,
    match: (m) => m.atbPrevio === true,
    prescricoes: [
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
    ],
    textoOriginal: 'Cefepime 1-2g EV 8/8h',
  },
  {
    id: '6.1.pneumonia.1a',
    secao: '6.1',
    focoId: 'pneumonia',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q24h' },
      {
        drugId: 'azitromicina',
        doseFixa: { valor: 500, unidade: 'mg' },
        via: 'EV',
        intervalo: 'q24h',
        facultativo: true, // "+/-" no protocolo
        criterioFacultativo: CRITERIO_MACROLIDEO_ADULTO,
      },
    ],
    textoOriginal: 'Ceftriaxona 2g EV 24/24h +/- Azitromicina 500mg EV 1x/dia',
  },

  // --- ITU -----------------------------------------------------------------
  {
    id: '6.1.itu.complicada',
    secao: '6.1',
    focoId: 'itu',
    condicaoLabel: 'Uso de ATB prévio / Litíase renal / ITU recorrente',
    // Qualquer um dos três fatores basta — o protocolo os agrupa numa só célula.
    prioridade: 10,
    match: (m) => m.atbPrevio === true || m.litiaseRenal === true || m.ituRecorrente === true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam 4,5g 8/8h',
  },
  {
    id: '6.1.itu.1a',
    secao: '6.1',
    focoId: 'itu',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q24h' },
    ],
    textoOriginal: 'Ceftriaxona 2g EV 1x/dia',
  },

  // --- Infecção abdominal --------------------------------------------------
  {
    id: '6.1.abdominal.2a',
    secao: '6.1',
    focoId: 'abdominal',
    condicaoLabel: '2ª opção',
    prioridade: 10,
    match: (m) => m.segundaOpcao === true,
    prescricoes: [
      { drugId: 'ciprofloxacino', doseFixa: { valor: 400, unidade: 'mg' }, via: 'EV', intervalo: 'q12h' },
      { drugId: 'metronidazol', doseFixa: { valor: 500, unidade: 'mg' }, via: 'EV', intervalo: 'q8h' },
    ],
    textoOriginal: 'Ciprofloxacino 400mg EV 12/12h + Metronidazol 500mg EV 8/8h',
  },
  {
    id: '6.1.abdominal.1a',
    secao: '6.1',
    focoId: 'abdominal',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q24h' },
      { drugId: 'metronidazol', doseFixa: { valor: 500, unidade: 'mg' }, via: 'EV', intervalo: 'q8h' },
    ],
    textoOriginal: 'Ceftriaxona 2g EV 1x/dia + Metronidazol 500mg EV 8/8h',
  },

  // --- Pele e partes moles -------------------------------------------------
  {
    id: '6.1.pele.necrose',
    secao: '6.1',
    focoId: 'pele_partes_moles',
    condicaoLabel: 'Com sinais de necrose',
    // Necrose amplia o espectro para gram-negativos e anaeróbios/toxinas.
    prioridade: 10,
    match: (m) => m.necrose === true,
    prescricoes: [
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q24h' },
      { drugId: 'clindamicina', doseFixa: { valor: 600, unidade: 'mg' }, via: 'EV', intervalo: 'q6h' },
    ],
    textoOriginal: 'Ceftriaxona 2g EV 24/24h + Clindamicina 600mg EV 6/6h',
  },
  {
    id: '6.1.pele.sem-necrose',
    secao: '6.1',
    focoId: 'pele_partes_moles',
    condicaoLabel: 'Sem necrose',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'oxacilina', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q4h' },
    ],
    textoOriginal: 'Oxacilina 2g EV 4/4h',
  },

  // --- Sepse sem foco ------------------------------------------------------
  {
    id: '6.1.sepse.1a',
    secao: '6.1',
    focoId: 'sepse_sem_foco',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q12h' },
    ],
    textoOriginal: 'Ceftriaxona 2g EV 12/12h',
  },

  // --- Meningite bacteriana ------------------------------------------------
  {
    id: '6.1.meningite.1a',
    secao: '6.1',
    focoId: 'meningite',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'vancomicina',
        via: 'EV',
        intervalo: 'q12h',
        facultativo: true, // "+/-" governado pela nota ²
        criterioFacultativo:
          'Nota ²: associar na suspeita de meningite pneumocócica se quadro ' +
          'grave, uso prévio de betalactâmicos nos últimos 3 meses ou ' +
          'resistência local documentada.',
      },
      {
        // Adjuvante, não antimicrobiano — mas entra no esquema empírico porque
        // o momento da primeira dose depende do início do antibiótico.
        drugId: 'dexametasona',
        doseFixa: { valor: 10, unidade: 'mg' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'Duração de 4 dias.',
          'Administrar 10 a 20 min ANTES da primeira dose do antibiótico, ou junto.',
        ],
      },
    ],
    notas: ['n1', 'n2'],
    textoOriginal: 'Ceftriaxona 2g 12/12h +/- Vancomicina¹ + Dexametasona 10mg EV 6/6h por 4 dias',
  },

  // --- Endocardite aguda ---------------------------------------------------
  {
    id: '6.1.endocardite.1a',
    secao: '6.1',
    focoId: 'endocardite',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'ceftriaxona', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q24h' },
      { drugId: 'oxacilina', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q4h' },
      {
        // Na endocardite a gentamicina entra como SINERGISMO, não como
        // tratamento do Gram-negativo: 1 mg/kg a cada 8 h, e não a dose plena
        // de 5–7 mg/kg/dia. Correção do SCIH sobre a tabela original, alinhada
        // à tabela institucional de ajuste de antimicrobianos.
        drugId: 'gentamicina',
        dosePonderal: { valor: 1, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Dose de sinergismo para endocardite. Usar PESO AJUSTADO — ver a ' +
            'calculadora de peso na ficha 12.',
        ],
      },
    ],
    textoOriginal:
      'Ceftriaxona 2g EV 24/24h + Oxacilina 2g EV 4/4h + Gentamicina 1mg/kg 8/8h (sinergismo)',
  },

  // --- Infecção óssea / articular ------------------------------------------
  {
    id: '6.1.osteoarticular.1a',
    secao: '6.1',
    focoId: 'osteoarticular',
    condicaoLabel: '1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'ciprofloxacino', doseFixa: { valor: 400, unidade: 'mg' }, via: 'EV', intervalo: 'q12h' },
      { drugId: 'clindamicina', doseFixa: { valor: 600, unidade: 'mg' }, via: 'EV', intervalo: 'q8h' },
    ],
    textoOriginal: 'Ciprofloxacino 400mg EV 12/12h + Clindamicina 600mg EV 8/8h',
  },
]
