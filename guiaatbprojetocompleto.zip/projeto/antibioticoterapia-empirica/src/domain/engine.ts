import type {
  Alerta,
  ClinicalInput,
  DrugPrescription,
  EngineResult,
  Foco,
  ProtocolRule,
  Recomendacao,
  ResolvedPrescription,
  Secao,
  SecaoId,
} from './types'
import { ProtocolError, ORIENTACAO_SCIH } from './errors'
import { calcularDose, INTERVALO_LABEL, PESO_MAX_KG, PESO_MIN_KG } from './dosing'
import { DRUGS, FOCOS, NOTAS_RODAPE, REGRAS_POR_SECAO, SECOES } from '@/data'

// ---------------------------------------------------------------------------
// 1. ROTEAMENTO — qual tabela do protocolo se aplica
// ---------------------------------------------------------------------------

/**
 * Traduz população + origem + setor na seção aplicável do protocolo.
 *
 * A lógica reproduz a organização do item 6 do documento:
 * - infecção COMUNITÁRIA depende apenas da população (6.1 adulto, 6.3 pediatria),
 *   pois o protocolo não segmenta essas tabelas por setor;
 * - infecção IRAS depende de população E setor (6.2/6.5 adulto; 6.4/6.6 pediatria).
 *
 * A UCO e a Unidade Neurológica seguem a tabela de UTI adulto (6.5), por
 * definição do SCIH — o documento não lhes dá tabela própria.
 *
 * @throws {ProtocolError} SECAO_NAO_APLICAVEL quando a combinação não existe no
 *         protocolo — notadamente infecção comunitária em neonato, que o
 *         documento não cobre (ambiguidade A-12).
 */
export function resolverSecao(input: ClinicalInput): Secao {
  const { populacao, origem, setor } = input

  if (origem === 'comunitaria') {
    if (populacao === 'adulto') return SECOES['6.1'] as Secao
    if (populacao === 'pediatrico') return SECOES['6.3'] as Secao
    throw new ProtocolError(
      'SECAO_NAO_APLICAVEL',
      'O protocolo não possui tabela de infecções comunitárias para neonatos.',
      'Acionar a Infectologia Pediátrica para definição do esquema. ' +
        'O protocolo cobre o recém-nascido apenas no item 6.6 (IRAS — UTI ' +
        'Neonatal e Pediátrica).',
    )
  }

  // origem === 'iras'
  // UCO e Unidade Neurológica entram aqui: por decisão do SCIH, seguem a
  // tabela de UTI adulto.
  const emUti =
    setor === 'uti' || setor === 'uci_neonatal' || setor === 'uco' || setor === 'neuro'
  if (populacao === 'adulto') return (emUti ? SECOES['6.5'] : SECOES['6.2']) as Secao
  if (populacao === 'pediatrico') return (emUti ? SECOES['6.6'] : SECOES['6.4']) as Secao

  // Neonatal: o protocolo só descreve o cenário de UTI/UCI neonatal.
  if (emUti) return SECOES['6.6'] as Secao
  throw new ProtocolError(
    'SECAO_NAO_APLICAVEL',
    'O protocolo trata IRAS neonatal apenas no contexto de UTI/UCI neonatal.',
    'Selecione UTI ou UCI neonatal, ou acione a Infectologia Pediátrica.',
  )
}

/** Focos efetivamente cobertos por uma seção — alimenta a tela de seleção. */
export function focosDaSecao(secaoId: SecaoId): Foco[] {
  const regras = REGRAS_POR_SECAO[secaoId] ?? []
  const ids = [...new Set(regras.map((r) => r.focoId))]
  return ids.map((id) => FOCOS[id]).filter((f): f is Foco => f !== undefined)
}

// ---------------------------------------------------------------------------
// 2. VALIDAÇÃO DE ENTRADA
// ---------------------------------------------------------------------------

/**
 * Valida a entrada antes de qualquer cálculo.
 * @throws {ProtocolError} INPUT_INVALIDO | PESO_OBRIGATORIO | PESO_FORA_DA_FAIXA
 */
export function validarInput(input: ClinicalInput): void {
  if (!input.focoId || !FOCOS[input.focoId]) {
    throw new ProtocolError(
      'INPUT_INVALIDO',
      `Foco de infecção desconhecido: "${input.focoId}".`,
      'Selecione um foco de infecção válido.',
    )
  }

  const exigePeso = input.populacao === 'pediatrico' || input.populacao === 'neonatal'
  if (exigePeso) {
    if (input.pesoKg === undefined || Number.isNaN(input.pesoKg)) {
      throw new ProtocolError(
        'PESO_OBRIGATORIO',
        'Peso não informado para paciente pediátrico/neonatal.',
        'As doses pediátricas do protocolo são ponderais (mg/kg/dose). Informe o peso.',
      )
    }
    if (input.pesoKg < PESO_MIN_KG || input.pesoKg > PESO_MAX_KG) {
      throw new ProtocolError(
        'PESO_FORA_DA_FAIXA',
        `Peso ${input.pesoKg} kg fora da faixa aceita (${PESO_MIN_KG}–${PESO_MAX_KG} kg).`,
        'Confira o peso informado.',
      )
    }
  }
}

// ---------------------------------------------------------------------------
// 3. SELEÇÃO DA REGRA
// ---------------------------------------------------------------------------

/**
 * Escolhe a regra vencedora dentro de um foco.
 *
 * As regras são ordenadas por prioridade decrescente e a PRIMEIRA que casar
 * vence — as linhas condicionais do protocolo ("Aspirativa", "assoc. a cateter",
 * "Se ISC") têm prioridade maior que a linha de base, garantindo que o
 * modificador clínico sempre prevaleça sobre o esquema padrão.
 */
export function selecionarRegra(
  regras: readonly ProtocolRule[],
  input: ClinicalInput,
): ProtocolRule {
  const candidatas = regras
    .filter((r) => r.focoId === input.focoId)
    .slice()
    .sort((a, b) => b.prioridade - a.prioridade)

  if (candidatas.length === 0) {
    const foco = FOCOS[input.focoId]
    throw new ProtocolError(
      'FOCO_NAO_COBERTO',
      `A seção selecionada não cobre o foco "${foco?.nome ?? input.focoId}".`,
      `O protocolo não prevê conduta empírica para esse foco neste cenário. ${ORIENTACAO_SCIH}`,
    )
  }

  const vencedora = candidatas.find((r) => r.match(input.modificadores, input))
  if (!vencedora) {
    throw new ProtocolError(
      'REGRA_NAO_ENCONTRADA',
      'Nenhuma linha do protocolo casou com as condições informadas.',
      ORIENTACAO_SCIH,
    )
  }
  return vencedora
}

// ---------------------------------------------------------------------------
// 4. RESOLUÇÃO DE PRESCRIÇÕES
// ---------------------------------------------------------------------------

function resolverPrescricao(
  p: DrugPrescription,
  input: ClinicalInput,
  regraSecao: string,
): ResolvedPrescription {
  const drug = DRUGS[p.drugId]
  if (!drug) {
    throw new ProtocolError(
      'FARMACO_DESCONHECIDO',
      `Fármaco "${p.drugId}" ausente do catálogo.`,
      'Falha interna do aplicativo. Consulte o protocolo impresso e informe o SCIH.',
    )
  }

  const alertas: Alerta[] = []
  const dose = calcularDose(p, drug, input.pesoKg)
  const intervaloTexto = INTERVALO_LABEL[p.intervalo]

  // Vancomicina e afins: posologia definida em documento à parte.
  if (drug.protocoloExterno) {
    alertas.push({
      severidade: 'critico',
      titulo: `Dose não definida neste protocolo`,
      detalhe:
        `A posologia de ${drug.nome} não está nas tabelas empíricas: ataque, ` +
        `manutenção por clearance e correção por nível sérico estão na ficha ` +
        `própria de Vancomicina deste guia.`,
      fonte: 'Nota ¹ do protocolo',
    })
  }

  // Dose definida em tabela dedicada (amicacina neonatal): o motor não devolve
  // número, porque as variáveis que o determinam não estão na linha do protocolo.
  if (p.tabelaDose) {
    alertas.push({
      severidade: 'critico',
      titulo: 'Dose depende de tabela específica',
      detalhe:
        `A posologia de ${drug.nome} neste cenário é definida por idade ` +
        `gestacional e pós-natal. Consultar a "${p.tabelaDose}" — os valores ` +
        `substituem a posologia grafada na tabela do protocolo.`,
      fonte: 'Definição do SCIH',
    })
  }

  // Posologia ponderal sem peso informado — ocorre no adulto (Gentamicina na
  // endocardite). O esquema é exibido como está no protocolo, com o aviso.
  if (dose?.pendentePeso) {
    alertas.push({
      severidade: 'atencao',
      titulo: 'Dose depende do peso',
      detalhe:
        `${drug.nome} é prescrito em mg/kg. Informe o peso do paciente para que a ` +
        `dose seja calculada; até lá, vale a posologia como consta no protocolo.`,
      fonte: `Item ${regraSecao} do protocolo`,
    })
  }

  if (dose?.excedeTetoAdulto && drug.tetoAdultoPorDose) {
    alertas.push({
      severidade: 'atencao',
      titulo: 'Dose calculada acima da dose adulta',
      detalhe:
        `A dose ponderal calculada supera ${drug.tetoAdultoPorDose.valor} mg por ` +
        `administração, que é a maior dose adulta prevista no próprio protocolo para ` +
        `${drug.nome}. O protocolo não define teto pediátrico — confira o peso e ` +
        `considere limitar à dose adulta.`,
      fonte: 'Salvaguarda do aplicativo (ambiguidade A-09)',
    })
  }

  if (dose?.excedeTetoDiario && drug.tetoDiarioMg) {
    alertas.push({
      severidade: 'critico',
      titulo: 'Dose diária acima do teto',
      detalhe:
        `O total em 24 h ultrapassa ${drug.tetoDiarioMg / 1000} g, teto diário de ` +
        `${drug.nome}. Confira o peso e o intervalo; acima de 40 kg vale a dose de adulto.`,
      fonte: 'Bula do fabricante',
    })
  }

  for (const aviso of drug.avisos ?? []) {
    alertas.push({ severidade: 'info', titulo: drug.nome, detalhe: aviso })
  }

  const doseTexto = dose ? dose.texto : 'conforme protocolo específico'
  const linha = [
    drug.nome,
    doseTexto,
    p.via,
    intervaloTexto,
    p.facultativo ? '(associação facultativa)' : '',
  ]
    .filter(Boolean)
    .join(' ')

  return {
    drug,
    linha,
    doseTexto,
    intervaloTexto,
    via: p.via,
    facultativo: p.facultativo === true,
    ...(p.criterioFacultativo ? { criterioFacultativo: p.criterioFacultativo } : {}),
    ...(dose?.porDose !== undefined ? { doseCalculadaMg: dose.porDose } : {}),
    ...(dose?.porDia !== undefined ? { doseDiariaMg: dose.porDia } : {}),
    observacoes: [...(p.observacoes ?? []), ...(dose?.memoria ? [`Cálculo: ${dose.memoria}`] : [])],
    alertas,
  }
}

// ---------------------------------------------------------------------------
// 5. ALERTAS TRANSVERSAIS
// ---------------------------------------------------------------------------

/**
 * Alertas que não decorrem de um fármaco isolado, mas do cenário clínico.
 * Incluem as notas ² e ⁴, que condicionam a associação de Vancomicina.
 */
function alertasDoCenario(input: ClinicalInput, regra: ProtocolRule): Alerta[] {
  const alertas: Alerta[] = []
  const m = input.modificadores

  // Etapa 2 do fluxo institucional — vale para toda prescrição empírica.
  alertas.push({
    severidade: 'info',
    titulo: 'Coletar culturas antes da primeira dose',
    detalhe:
      'Hemoculturas (2 pares) e culturas do sítio suspeito devem ser colhidas ' +
      'ANTES do início do antimicrobiano, sem retardar a primeira dose além de 1–3 horas.',
    fonte: 'Item 5 — Fluxo do procedimento',
  })

  alertas.push({
    severidade: 'info',
    titulo: 'Reavaliar em 48–72 horas',
    detalhe:
      'Reavaliar resposta clínica e resultados de cultura em 48–72 h para ' +
      'descalonamento — adequação para antimicrobiano de menor espectro.',
    fonte: 'Item 5 — Fluxo do procedimento / Item 3 — Descalonamento',
  })

  // Nota ² — meningite no adulto.
  if (regra.focoId === 'meningite' && input.populacao === 'adulto') {
    const criterios = [
      m.meningiteQuadroGrave ? 'quadro grave' : null,
      m.betalactamico3Meses ? 'uso de betalactâmico nos últimos 3 meses' : null,
      m.resistenciaLocalPneumococo ? 'resistência local documentada' : null,
    ].filter((c): c is string => c !== null)

    if (criterios.length > 0) {
      alertas.push({
        severidade: 'critico',
        titulo: 'Associar Vancomicina — critério da nota ² atendido',
        detalhe:
          `Critério(s) presente(s): ${criterios.join('; ')}. Na suspeita de ` +
          'meningite pneumocócica, associar Vancomicina à Ceftriaxona.',
        fonte: 'Nota ² do protocolo',
      })
    } else {
      alertas.push({
        severidade: 'atencao',
        titulo: 'Vancomicina facultativa — reavaliar critérios da nota ²',
        detalhe:
          'Nenhum dos critérios da nota ² foi assinalado (quadro grave, uso de ' +
          'betalactâmico nos últimos 3 meses, resistência local). A associação ' +
          'permanece a critério clínico.',
        fonte: 'Nota ² do protocolo',
      })
    }
  }

  // Dexametasona na meningite: o benefício depende do momento da primeira dose.
  if (regra.prescricoes.some((p) => p.drugId === 'dexametasona')) {
    alertas.push({
      severidade: 'critico',
      titulo: 'Dexametasona: administrar antes ou junto do antibiótico',
      detalhe:
        'De 10 a 20 minutos ANTES da primeira dose do antimicrobiano, ou junto ' +
        'com ela. Iniciada depois, perde o benefício. Manter por 4 dias. O ' +
        'corticoide não pode atrasar a primeira dose do antibiótico.',
      fonte: 'Definição do SCIH',
    })
  }

  // Nota ⁴ — meningite pediátrica: a nota é imperativa, não facultativa.
  if (regra.focoId === 'meningite' && input.populacao !== 'adulto') {
    alertas.push({
      severidade: 'critico',
      titulo: 'Associar Vancomicina ao esquema inicial',
      detalhe: NOTAS_RODAPE.n4 ?? '',
      fonte: 'Nota ⁴ do protocolo',
    })
  }

  // Coerência entre a população declarada e a idade informada.
  if (input.idadeDias !== undefined) {
    if (input.populacao === 'neonatal' && input.idadeDias > 28) {
      alertas.push({
        severidade: 'atencao',
        titulo: 'Idade incompatível com a via neonatal',
        detalhe:
          `Foram informados ${input.idadeDias} dias de vida. As linhas "(neonatal)" ` +
          'do item 6.6 destinam-se a ≤ 28 dias; acima disso aplicam-se as linhas ' +
          '"(> 28 dias)".',
        fonte: 'Item 6.6 do protocolo (ambiguidade A-02)',
      })
    }
    if (input.populacao === 'pediatrico' && input.idadeDias <= 28) {
      alertas.push({
        severidade: 'atencao',
        titulo: 'Idade sugere via neonatal',
        detalhe:
          `Foram informados ${input.idadeDias} dias de vida. Considere a via ` +
          'neonatal, que possui linhas próprias no item 6.6.',
        fonte: 'Item 6.6 do protocolo (ambiguidade A-02)',
      })
    }
  }

  // Antimicrobiano restrito → notificação obrigatória ao SCIH.
  if (regra.prescricoes.some((p) => p.drugId === 'meropenem')) {
    alertas.push({
      severidade: 'atencao',
      titulo: 'Antimicrobiano de uso restrito',
      detalhe:
        'Preencher o formulário de solicitação de antimicrobianos restritos e ' +
        'notificar o SCIH.',
      fonte: 'Item 4 — Materiais necessários',
    })
  }

  return alertas
}

// ---------------------------------------------------------------------------
// 6. MONTAGEM DA RECOMENDAÇÃO
// ---------------------------------------------------------------------------

function montarRecomendacao(
  regra: ProtocolRule,
  secao: Secao,
  input: ClinicalInput,
): Recomendacao {
  const foco = FOCOS[regra.focoId]
  if (!foco) {
    throw new ProtocolError(
      'INPUT_INVALIDO',
      `Foco "${regra.focoId}" ausente do catálogo.`,
      'Falha interna do aplicativo. Consulte o protocolo impresso.',
    )
  }

  const resolvidas = regra.prescricoes.map((p) => resolverPrescricao(p, input, regra.secao))

  // Nota ⁴: em meningite pediátrica a Vancomicina deixa de ser "+/-" e passa a
  // ser parte do esquema inicial. Esta é a única promoção automática do motor,
  // e é sempre acompanhada do alerta crítico correspondente.
  const meningitePediatrica = regra.focoId === 'meningite' && input.populacao !== 'adulto'

  const obrigatorias = resolvidas.filter(
    (r) => !r.facultativo || (meningitePediatrica && r.drug.id === 'vancomicina'),
  )
  const facultativas = resolvidas.filter(
    (r) => r.facultativo && !(meningitePediatrica && r.drug.id === 'vancomicina'),
  )

  const notas = [...new Set([...(secao.notas ?? []), ...(regra.notas ?? [])])]
    .map((k) => NOTAS_RODAPE[k])
    .filter((n): n is string => n !== undefined)

  return {
    rule: regra,
    secao,
    foco,
    prescricoes: obrigatorias,
    facultativos: facultativas,
    alertas: [
      ...alertasDoCenario(input, regra),
      ...resolvidas.flatMap((r) => r.alertas),
    ],
    notas,
  }
}

// ---------------------------------------------------------------------------
// 7. PONTO DE ENTRADA DO MOTOR
// ---------------------------------------------------------------------------

/**
 * Executa o protocolo para uma entrada clínica.
 *
 * Sequência: validar → rotear a seção → selecionar a regra → resolver doses →
 * anexar alertas → listar alternativas previstas para o mesmo foco.
 *
 * @throws {ProtocolError} sempre que o cenário não estiver previsto no protocolo.
 *         O chamador deve renderizar `error.orientacao`, nunca um regime inferido.
 */
export function executarProtocolo(input: ClinicalInput): EngineResult {
  validarInput(input)

  const secao = resolverSecao(input)
  const regras = REGRAS_POR_SECAO[secao.id] ?? []
  const vencedora = selecionarRegra(regras, input)

  // Alternativas: demais linhas do mesmo foco, para consulta lado a lado.
  const alternativas = regras
    .filter((r) => r.focoId === input.focoId && r.id !== vencedora.id)
    .sort((a, b) => b.prioridade - a.prioridade)
    .map((r) => montarRecomendacao(r, secao, input))

  return {
    recomendacao: montarRecomendacao(vencedora, secao, input),
    alternativas,
    input,
  }
}

/** Versão que não lança: devolve `{ ok }` para uso direto na interface. */
export function executarProtocoloSeguro(
  input: ClinicalInput,
): { ok: true; result: EngineResult } | { ok: false; error: ProtocolError } {
  try {
    return { ok: true, result: executarProtocolo(input) }
  } catch (e) {
    if (e instanceof ProtocolError) return { ok: false, error: e }
    return {
      ok: false,
      error: new ProtocolError(
        'INPUT_INVALIDO',
        e instanceof Error ? e.message : 'Erro desconhecido.',
        'Não foi possível processar a avaliação. Revise os dados informados.',
      ),
    }
  }
}
