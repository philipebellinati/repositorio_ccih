import { useMemo } from 'react'
import { Baby, User } from 'lucide-react'
import { DRUGS } from '@/data'
import { TODAS_AS_REGRAS } from '@/data'
import {
  calcularDose,
  DOSES_POR_DIA,
  formatarMg,
  formatarNumero,
  INTERVALO_LABEL,
  PESO_MAX_KG,
  PESO_MIN_KG,
  posologiaLiteral,
} from '@/domain/dosing'
import type { DrugPrescription } from '@/domain/types'
import { totalPipTazo } from '@/domain/dose-ponderal'
import { Callout } from './ui/primitives'
import { cn } from '@/lib/utils'

/**
 * Critério institucional de adulto, definido pelo SCIH: idade ≥ 12 anos OU
 * peso > 40 kg. Basta um dos dois.
 */
export const PESO_CORTE_PEDIATRICO_KG = 40
export const IDADE_CORTE_ADULTO_ANOS = 12

/** Aplica o critério do SCIH a peso e/ou idade, quando informados. */
export function ehAdultoPorCriterio(pesoKg?: number, idadeAnos?: number): boolean {
  if (idadeAnos !== undefined && idadeAnos >= IDADE_CORTE_ADULTO_ANOS) return true
  if (pesoKg !== undefined && pesoKg > PESO_CORTE_PEDIATRICO_KG) return true
  return false
}

/** Seções de adulto e de pediatria, para separar o que é dose fixa do que é mg/kg. */
const SECOES_ADULTO = new Set(['6.1', '6.2', '6.5'])

/**
 * Toda prescrição PONDERAL do protocolo, deduplicada por fármaco + posologia.
 *
 * No adulto o protocolo é quase todo dose FIXA: a única prescrição adulta em
 * mg/kg é a gentamicina de sinergismo na endocardite. Por isso a tabela de
 * cálculo por peso é essencialmente pediátrica — e o adulto ganha um quadro
 * próprio, de dose fixa, que não depende de calculadora.
 */
function prescricoesPonderais(): { chave: string; p: DrugPrescription; adulto: boolean }[] {
  const vistos = new Map<string, { chave: string; p: DrugPrescription; adulto: boolean }>()
  for (const regra of TODAS_AS_REGRAS) {
    for (const p of regra.prescricoes) {
      if (!p.dosePonderal) continue
      const { valor, base } = p.dosePonderal
      const chave = `${p.drugId}|${String(valor)}|${base}|${p.intervalo}`
      if (!vistos.has(chave)) {
        vistos.set(chave, { chave, p, adulto: SECOES_ADULTO.has(regra.secao) })
      }
    }
  }
  return [...vistos.values()].sort((a, b) => {
    const na = DRUGS[a.p.drugId]?.nome ?? ''
    const nb = DRUGS[b.p.drugId]?.nome ?? ''
    return na.localeCompare(nb, 'pt-BR')
  })
}

/** Doses FIXAS do adulto (6.1, 6.2, 6.5), deduplicadas. Não dependem de peso. */
function dosesFixasAdulto(): { chave: string; nome: string; dose: string; intervalo: string }[] {
  const vistos = new Map<string, { chave: string; nome: string; dose: string; intervalo: string }>()
  for (const regra of TODAS_AS_REGRAS) {
    if (!SECOES_ADULTO.has(regra.secao)) continue
    for (const p of regra.prescricoes) {
      if (!p.doseFixa) continue
      const nome = DRUGS[p.drugId]?.nome ?? p.drugId
      const dose = posologiaLiteral(p)
      const chave = `${p.drugId}|${dose}|${p.intervalo}`
      if (!vistos.has(chave)) {
        vistos.set(chave, { chave, nome, dose, intervalo: INTERVALO_LABEL[p.intervalo] })
      }
    }
  }
  return [...vistos.values()].sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'))
}

/**
 * Calculadora de dose por peso.
 *
 * O peso converte as posologias em mg/kg — que no protocolo são de PEDIATRIA.
 * O esquema adulto é de dose fixa e aparece num quadro separado, que não pede
 * peso nenhum: pedir peso para prescrever ceftriaxona 2 g no adulto só cria
 * chance de erro.
 */
export function Calculadora({
  pesoKg,
  onPesoChange,
}: {
  pesoKg: number | undefined
  onPesoChange: (peso: number | undefined) => void
}) {
  const ponderais = useMemo(prescricoesPonderais, [])
  const fixasAdulto = useMemo(dosesFixasAdulto, [])
  const pediatrico = pesoKg !== undefined && pesoKg < PESO_CORTE_PEDIATRICO_KG
  const pesoValido = pesoKg !== undefined && pesoKg >= PESO_MIN_KG && pesoKg <= PESO_MAX_KG

  return (
    <div className="space-y-4 px-4 py-4">
      <div className="flex flex-wrap items-end gap-3">
        <label className="flex-1">
          <span className="kicker">Peso do paciente</span>
          <div className="mt-1.5 flex items-center gap-2">
            <input
              type="number"
              inputMode="decimal"
              step="0.1"
              min={PESO_MIN_KG}
              max={PESO_MAX_KG}
              value={pesoKg ?? ''}
              onChange={(e) => {
                const v = e.target.value
                onPesoChange(v === '' ? undefined : Number(v))
              }}
              placeholder="0,0"
              aria-label="Peso do paciente em quilogramas"
              className="w-32 rounded-md border border-border bg-input px-3 py-2.5 text-lg font-semibold text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-ring"
            />
            <span className="text-lg font-semibold text-muted-foreground">kg</span>
            {pesoKg !== undefined && (
              <button
                type="button"
                onClick={() => onPesoChange(undefined)}
                className="ml-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground underline-offset-2 hover:underline"
              >
                Limpar
              </button>
            )}
          </div>
        </label>

        <div
          className={cn(
            'flex items-center gap-2 rounded-md border px-3 py-2.5 text-xs font-bold uppercase tracking-wider',
            pediatrico
              ? 'border-primary/50 bg-primary/15 text-primary'
              : 'border-border bg-secondary/60 text-muted-foreground',
          )}
        >
          {pediatrico ? <Baby className="h-4 w-4" aria-hidden /> : <User className="h-4 w-4" aria-hidden />}
          {pediatrico ? 'Esquema pediátrico' : 'Esquema adulto'}
        </div>
      </div>

      {pesoKg !== undefined && !pesoValido && (
        <Callout severidade="critico" titulo="Peso fora da faixa aceita">
          Informe um peso entre {PESO_MIN_KG} kg e {PESO_MAX_KG} kg. Fora dessa faixa o guia
          não calcula doses automaticamente, por segurança.
        </Callout>
      )}

      {/* ---- ADULTO: dose fixa, sem calculadora ---- */}
      <section>
        <Callout severidade="info" titulo="No adulto a dose é FIXA">
          O protocolo adulto não usa mg/kg — a dose não muda com o peso. A única exceção
          é o <strong>aminoglicosídeo</strong> (e a vancomicina, que tem ficha própria),
          onde o cálculo usa <strong>peso ajustado</strong>, não o peso real.
        </Callout>

        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[380px] border-collapse text-sm">
            <caption className="sr-only">Doses fixas do esquema adulto</caption>
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="kicker pb-2 pr-3">Fármaco</th>
                <th scope="col" className="kicker pb-2 pr-3">Dose</th>
                <th scope="col" className="kicker pb-2">Intervalo</th>
              </tr>
            </thead>
            <tbody>
              {fixasAdulto.map((f) => (
                <tr key={f.chave} className="border-b border-border/60">
                  <td className="py-2 pr-3 font-semibold text-foreground">{f.nome}</td>
                  <td className="py-2 pr-3 font-semibold text-primary">{f.dose}</td>
                  <td className="py-2 text-muted-foreground">{f.intervalo}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ---- PONDERAL: pediatria + os poucos fármacos por peso ---- */}
      <section>
        <p className="kicker mb-1">Doses por peso — pediatria e aminoglicosídeos</p>
        {!pesoValido && (
          <p className="text-sm text-muted-foreground">
            Informe o peso para converter as posologias em mg/kg deste protocolo em
            miligramas por administração. O peso também passa a ser aplicado às tabelas
            das fichas de pediatria.
          </p>
        )}

        {pesoValido && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] border-collapse text-sm">
              <caption className="sr-only">
                Doses ponderais do protocolo calculadas para {pesoKg} quilogramas
              </caption>
              <thead>
                <tr className="border-b border-border text-left">
                  <th scope="col" className="kicker pb-2 pr-3">Fármaco</th>
                  <th scope="col" className="kicker pb-2 pr-3">Posologia</th>
                  <th scope="col" className="kicker pb-2 pr-3">Por dose</th>
                  <th scope="col" className="kicker pb-2">Total 24 h</th>
                </tr>
              </thead>
              <tbody>
                {ponderais.map(({ chave, p, adulto }) => {
                  const drug = DRUGS[p.drugId]
                  if (!drug || !p.dosePonderal) return null
                  let calc
                  try {
                    calc = calcularDose(p, drug, pesoKg)
                  } catch {
                    return null
                  }
                  if (!calc || calc.pendentePeso || calc.porDia === undefined) return null
                  const { valor, base } = p.dosePonderal
                  const literal = Array.isArray(valor) ? `${valor[0]}–${valor[1]}` : String(valor)

                  return (
                    <tr key={chave} className="border-b border-border/60 align-top">
                      <td className="py-2 pr-3 font-semibold text-foreground">
                        {drug.nome}
                        <span className="block text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                          {adulto ? 'adulto' : 'pediatria'}
                        </span>
                      </td>
                      <td className="py-2 pr-3 text-muted-foreground">
                        {literal} mg/kg/{base} · {INTERVALO_LABEL[p.intervalo]}
                        <span className="block text-[11px]">
                          {DOSES_POR_DIA[p.intervalo]}× ao dia
                        </span>
                      </td>
                      <td
                        className={cn(
                          'py-2 pr-3 font-semibold',
                          calc.excedeTetoAdulto ? 'text-warning' : 'text-primary',
                        )}
                      >
                        {calc.texto}
                        {drug.tetoAdultoPorDose && (
                          <span className="block text-[11px] font-normal text-muted-foreground">
                            máx {formatarMg(drug.tetoAdultoPorDose.valor)}/dose
                          </span>
                        )}
                        {calc.excedeTetoAdulto && (
                          <span className="block text-[11px] font-normal">
                            acima da dose adulta do protocolo
                          </span>
                        )}
                        {/* O mg/kg da piperacilina é só do componente ativo; quem
                            prepara o frasco precisa do total da apresentação. */}
                        {p.drugId === 'piperacilina_tazobactam' &&
                          calc.porDose !== undefined &&
                          (() => {
                            const menor = Array.isArray(calc.porDose)
                              ? calc.porDose[0]
                              : calc.porDose
                            const maior = Array.isArray(calc.porDose)
                              ? calc.porDose[1]
                              : calc.porDose
                            const a = totalPipTazo(menor)
                            const b = totalPipTazo(maior)
                            const faixa =
                              a.total === b.total
                                ? formatarNumero(a.total)
                                : `${formatarNumero(a.total)} – ${formatarNumero(b.total)}`
                            return (
                              <span className="block text-[11px] font-normal text-muted-foreground">
                                piperacilina · total da apresentação (8:1) = {faixa} mg
                              </span>
                            )
                          })()}
                      </td>
                      <td
                        className={cn(
                          'py-2',
                          calc.excedeTetoDiario
                            ? 'font-semibold text-warning'
                            : 'text-muted-foreground',
                        )}
                      >
                        {formatarMg(calc.porDia)}
                        {drug.tetoDiarioMg !== undefined && (
                          <span className="block text-[11px] font-normal text-muted-foreground">
                            máx {formatarMg(drug.tetoDiarioMg)}/dia
                          </span>
                        )}
                        {calc.excedeTetoDiario && (
                          <span className="block text-[11px] font-normal">
                            acima do teto diário — conferir
                          </span>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  )
}
