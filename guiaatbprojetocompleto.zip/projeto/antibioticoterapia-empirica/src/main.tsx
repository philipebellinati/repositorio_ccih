import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'

const container = document.getElementById('root')
if (!container) {
  throw new Error('Elemento #root não encontrado no documento.')
}

createRoot(container).render(
  <StrictMode>
    <App />
  </StrictMode>,
)

// Service worker: garante o funcionamento offline após a primeira visita,
// requisito para "adicionar à tela de início" e usar sem internet.
//
// O try/catch envolve o register() porque em contextos restritos (iframe com
// sandbox, `file://`, ou o guia distribuído como arquivo HTML único) a chamada
// lança de forma SÍNCRONA — e aí um `.catch()` sozinho não seguraria o erro.
// O guia funciona sem service worker; apenas deixa de abrir sem rede.
//
// O caminho sai de `import.meta.env.BASE_URL`, nunca de "/" fixo: no GitHub
// Pages o site vive em /<repositório>/, e um caminho absoluto buscaria o
// service worker na raiz do domínio — 404 silencioso, guia sem offline.
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    try {
      const base = import.meta.env.BASE_URL
      navigator.serviceWorker.register(`${base}sw.js`, { scope: base }).catch(() => {})
    } catch {
      /* contexto não permite service worker */
    }
  })
}
