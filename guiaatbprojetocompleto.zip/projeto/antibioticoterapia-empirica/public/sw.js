/**
 * Service worker do guia.
 *
 * Estratégia: cache-first para o app shell e os assets versionados do build.
 * Todo o conteúdo clínico é estático e vive no bundle, então após a primeira
 * visita o guia abre integralmente sem rede — requisito de um guia de plantão.
 *
 * O nome do cache carrega a versão do protocolo: publicar uma revisão nova
 * invalida o cache antigo e força o download do conteúdo atualizado, evitando
 * que alguém consulte uma revisão vencida por causa de cache.
 */
const CACHE = 'guia-atb-empirico-v1'

/**
 * Raiz efetiva do site, derivada do escopo do PRÓPRIO service worker.
 *
 * Não pode ser "/" fixo: no GitHub Pages o guia vive em /<repositório>/, e
 * caminhos absolutos apontariam para fora do site — o `cache.addAll` falharia
 * inteiro e a instalação do worker seria abortada, deixando o guia sem offline
 * justamente onde ele mais importa. `registration.scope` já traz o prefixo
 * correto em qualquer hospedagem.
 */
const RAIZ = new URL('./', self.registration.scope).pathname

const SHELL = [RAIZ, `${RAIZ}index.html`, `${RAIZ}manifest.webmanifest`, `${RAIZ}icon.svg`]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(SHELL))
      .then(() => self.skipWaiting()),
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((chaves) => Promise.all(chaves.filter((c) => c !== CACHE).map((c) => caches.delete(c))))
      .then(() => self.clients.claim()),
  )
})

self.addEventListener('fetch', (event) => {
  const { request } = event
  if (request.method !== 'GET') return

  const url = new URL(request.url)
  if (url.origin !== self.location.origin) return

  // Navegações: rede primeiro, para pegar uma revisão nova quando houver rede;
  // cai no cache quando offline.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((resposta) => {
          const copia = resposta.clone()
          caches.open(CACHE).then((cache) => cache.put(`${RAIZ}index.html`, copia))
          return resposta
        })
        .catch(() => caches.match(`${RAIZ}index.html`).then((r) => r ?? Response.error())),
    )
    return
  }

  // Demais assets: cache primeiro, preenchendo o cache no primeiro acesso.
  event.respondWith(
    caches.match(request).then(
      (emCache) =>
        emCache ??
        fetch(request).then((resposta) => {
          if (resposta.ok) {
            const copia = resposta.clone()
            caches.open(CACHE).then((cache) => cache.put(request, copia))
          }
          return resposta
        }),
    ),
  )
})
