/**
 * Modelo de domínio do Protocolo de Antibioticoterapia Empírica do SCIH do
 * Hospital Evangélico de Londrina.
 *
 * Princípio de projeto: o protocolo é DADO, não código. Todo o conteúdo clínico
 * vive em `src/data/**` como estruturas tipadas por este arquivo; o motor
 * (`src/domain/engine.ts`) apenas navega esses dados. Uma revisão do protocolo
 * (rev. 001, 002 …) deve ser absorvida editando os dados, sem tocar no motor
 * nem na interface.
 */

// ---------------------------------------------------------------------------
// 1. VARIÁVEIS CLÍNICAS DE ENTRADA (o que o prescritor informa)
// ---------------------------------------------------------------------------

/**
 * Faixa etária/populacional. Determina qual bloco do protocolo se aplica
 * (6.1/6.2/6.5 = adulto; 6.3/6.4/6.6 = pediátrico e neonatal) e se as doses são
 * fixas (adulto) ou ponderais em mg/kg/DOSE (pediatria — nota ³ do protocolo).
 *
 * AMBIGUIDADE DOCUMENTADA (A-01): o protocolo não define o ponto de corte etário
 * entre "Adulto" e "Pediatria". O app trata a escolha como declaração explícita
 * do prescritor e não infere a partir da idade.
 *
 * AMBIGUIDADE DOCUMENTADA (A-02): "neonatal" é usado nas linhas do item 6.6 em
 * oposição a "> 28 dias"; adotamos ≤ 28 dias de vida como definição operacional
 * porque é a única leitura compatível com o par de linhas do próprio protocolo.
 */
export type Populacao = 'adulto' | 'pediatrico' | 'neonatal'

/**
 * Origem da infecção — passo 3 do fluxo do procedimento (item 5 do protocolo:
 * "Classificar a infecção como comunitária ou IRAS e definir o setor").
 */
export type Origem = 'comunitaria' | 'iras'

/**
 * Setor assistencial, conforme o item 2 (APLICAÇÃO) do protocolo. Só altera a
 * conduta quando a infecção é IRAS: as tabelas de IRAS são segmentadas em
 * enfermaria (6.2/6.4) e UTI (6.5/6.6).
 */
export type Setor =
  | 'ps'            // Pronto-Socorro (adulto e pediátrico)
  | 'enfermaria'    // Enfermarias adulto (clínicas/cirúrgicas) e pediátrica
  | 'uco'           // Unidade Coronariana — segue a tabela de UTI adulto
  | 'neuro'         // Unidade Neurológica — segue a tabela de UTI adulto
  | 'uti'           // UTI adulto / UTI neonatal e pediátrica
  | 'uci_neonatal'  // Unidade de Cuidados Intermediários neonatal

/**
 * Modificadores clínicos ("CONDIÇÃO" na coluna central das tabelas do
 * protocolo). São booleanos porque cada linha do protocolo é ativada pela
 * presença — nunca pela ausência — de uma condição.
 */
export interface Modificadores {
  /** "Uso de ATB prévio" (6.1 Pneumonia, 6.1 ITU, 6.3 ITU). */
  atbPrevio?: boolean
  /** "Aspirativa" / "Se aspirativa" (6.1, 6.2, 6.3, 6.5). */
  aspirativa?: boolean
  /** "Litíase renal" (6.1 ITU). */
  litiaseRenal?: boolean
  /** "ITU recorrente" / "ITU de repetição" (6.1 e 6.3). */
  ituRecorrente?: boolean
  /** "Com sinais de necrose" (6.1 e 6.3, pele e partes moles). */
  necrose?: boolean
  /** Preferência explícita pela 2ª opção, onde o protocolo oferece duas linhas. */
  segundaOpcao?: boolean
  /** Presença de dispositivo invasivo: CVC (IPCS) ou cateter vesical de demora (ITU). */
  dispositivoInvasivo?: boolean
  /** PAV: tempo de ventilação mecânica. Discrimina 6.5 "precoce (<5d)" x "tardia (>5d)". */
  diasVentilacaoMecanica?: number
  /** "Se Enterococcus / anaeróbio" (6.5, sepse sem foco). */
  suspeitaEnterococcusAnaerobio?: boolean
  /** Sepse neonatal: precoce x tardia (6.6). */
  sepseNeonatal?: 'precoce' | 'tardia'
  /** Meningite adulto, nota ²: quadro grave. */
  meningiteQuadroGrave?: boolean
  /** Meningite adulto, nota ²: uso de betalactâmico nos últimos 3 meses. */
  betalactamico3Meses?: boolean
  /** Meningite adulto, nota ²: vigilância local demonstra resistência. */
  resistenciaLocalPneumococo?: boolean
  /** Pneumonia: suspeita de germe atípico — critério para o "+/- Azitromicina". */
  suspeitaAtipico?: boolean
}

/** Entrada completa de uma avaliação. */
export interface ClinicalInput {
  populacao: Populacao
  origem: Origem
  setor: Setor
  /** Identificador do foco (ver `FOCOS` em `src/data/focos.ts`). */
  focoId: string
  /** Peso em kg — obrigatório em pediatria/neonatologia para o cálculo ponderal. */
  pesoKg?: number
  /** Idade em dias — usada apenas para sinalizar coerência com a população escolhida. */
  idadeDias?: number
  modificadores: Modificadores
}

// ---------------------------------------------------------------------------
// 2. CATÁLOGO DE FÁRMACOS
// ---------------------------------------------------------------------------

export type Via = 'EV' | 'VO' | 'EV/VO'

/** Intervalos posológicos usados pelo protocolo. */
export type Intervalo = 'q4h' | 'q6h' | 'q8h' | 'q12h' | 'q24h'

/** Valor escalar ou faixa "min–max" (ex.: Cefepime "1-2g", Clindamicina "5-10mg/kg"). */
export type Quantidade = number | readonly [number, number]

export interface Drug {
  id: string
  /** Nome como deve aparecer na prescrição. */
  nome: string
  /** Sinônimos/nome comercial citados no protocolo (ex.: "Tazocin"). */
  sinonimos?: readonly string[]
  classe: string
  /**
   * Teto por administração derivado da MAIOR dose adulta prevista no próprio
   * protocolo para o fármaco. O protocolo NÃO define teto pediátrico
   * (ambiguidade A-09); esta trava é uma salvaguarda do app, sempre exibida
   * como aviso — nunca aplicada silenciosamente.
   */
  tetoAdultoPorDose?: { valor: number; unidade: 'mg' }
  /**
   * Teto de dose DIÁRIA, em mg. Diferente do teto por administração: um esquema
   * pode ter cada dose dentro do limite e ainda assim estourar o total do dia
   * por causa do intervalo.
   */
  tetoDiarioMg?: number
  /** Fármaco cuja posologia é remetida a outro documento (Vancomicina). */
  protocoloExterno?: string
  /** Advertências fixas exibidas sempre que o fármaco é prescrito. */
  avisos?: readonly string[]
}

// ---------------------------------------------------------------------------
// 3. PRESCRIÇÃO (uma linha da coluna "TERAPIA EMPÍRICA")
// ---------------------------------------------------------------------------

export interface DrugPrescription {
  drugId: string
  /** Dose fixa do adulto: `{ valor: 2, unidade: 'g' }` ou `{ valor: [1,2], unidade: 'g' }`. */
  doseFixa?: { valor: Quantidade; unidade: 'g' | 'mg' }
  /**
   * Dose ponderal. `base: 'dose'` = mg/kg POR ADMINISTRAÇÃO (padrão em pediatria,
   * nota ³ do protocolo). `base: 'dia'` = mg/kg/DIA (ex.: Azitromicina
   * "10mg/kg/dia", Gentamicina "5-7mg/kg/dia").
   */
  dosePonderal?: { valor: Quantidade; unidade: 'mg/kg'; base: 'dose' | 'dia' }
  via: Via
  intervalo: Intervalo
  /**
   * Marca o "+/-" do protocolo: fármaco de associação FACULTATIVA, sujeito a
   * julgamento clínico. Nunca é somado automaticamente ao regime.
   */
  facultativo?: boolean
  /** Critério que orienta a decisão sobre um item facultativo. */
  criterioFacultativo?: string
  /**
   * A dose depende de variáveis que a linha do protocolo não carrega e vive em
   * tabela dedicada — caso da amicacina neonatal, cujo esquema é definido por
   * idade gestacional e pós-natal. O motor exibe alerta em vez de um número.
   */
  tabelaDose?: string
  /** Observações específicas desta prescrição. */
  observacoes?: readonly string[]
}

// ---------------------------------------------------------------------------
// 4. REGRAS DO PROTOCOLO
// ---------------------------------------------------------------------------

/**
 * Uma linha da tabela do protocolo.
 *
 * `match` é o predicado que traduz a coluna "CONDIÇÃO" em lógica. As regras de
 * um mesmo foco são avaliadas por `prioridade` DECRESCENTE e a primeira que
 * casar vence — assim as linhas condicionais ("Aspirativa", "Uso de ATB prévio")
 * sempre precedem a linha "1ª opção", que é o fallback com prioridade 0.
 */
export interface ProtocolRule {
  /** Identificador estável, no formato `<secao>.<foco>.<condicao>`. */
  id: string
  /** Seção do PDF de origem — exibida na interface para rastreabilidade. */
  secao: SecaoId
  focoId: string
  /** Texto da coluna "CONDIÇÃO", reproduzido literalmente. */
  condicaoLabel: string
  prioridade: number
  match: (m: Modificadores, input: ClinicalInput) => boolean
  /** Fármacos que compõem o esquema. */
  prescricoes: readonly DrugPrescription[]
  /** Notas de rodapé aplicáveis (ver `NOTAS_RODAPE`). */
  notas?: readonly string[]
  /** Texto original da célula "TERAPIA EMPÍRICA", para conferência lado a lado. */
  textoOriginal: string
}

export type SecaoId = '6.1' | '6.2' | '6.3' | '6.4' | '6.5' | '6.6'

export interface Secao {
  id: SecaoId
  titulo: string
  populacoes: readonly Populacao[]
  origem: Origem
  /** `undefined` = vale para qualquer setor (caso das tabelas comunitárias). */
  setores?: readonly Setor[]
  /** Notas de rodapé que valem para a seção inteira. */
  notas?: readonly string[]
}

export interface Foco {
  id: string
  nome: string
  /** Descrição curta exibida no cartão de seleção. */
  descricao?: string
  /** Ícone lucide-react, resolvido em `src/components/FocoIcon.tsx`. */
  icone: string
}

// ---------------------------------------------------------------------------
// 5. SAÍDA DO MOTOR
// ---------------------------------------------------------------------------

export type Severidade = 'info' | 'atencao' | 'critico'

export interface Alerta {
  severidade: Severidade
  titulo: string
  detalhe: string
  /** Referência à seção/nota do protocolo que fundamenta o alerta. */
  fonte?: string
}

/** Uma prescrição já resolvida em texto pronto para transcrição. */
export interface ResolvedPrescription {
  drug: Drug
  /** Ex.: "Ceftriaxona 2 g EV 24/24h" ou "Ceftriaxona 750 mg EV 12/12h (50 mg/kg/dose)". */
  linha: string
  doseTexto: string
  intervaloTexto: string
  via: Via
  facultativo: boolean
  criterioFacultativo?: string
  /** Dose calculada por administração, em mg — ausente quando remetida a outro protocolo. */
  doseCalculadaMg?: Quantidade
  /** Dose diária total, em mg. */
  doseDiariaMg?: Quantidade
  observacoes: readonly string[]
  alertas: readonly Alerta[]
}

export interface Recomendacao {
  rule: ProtocolRule
  secao: Secao
  foco: Foco
  prescricoes: readonly ResolvedPrescription[]
  /** Itens "+/-" separados, para não induzir associação automática. */
  facultativos: readonly ResolvedPrescription[]
  alertas: readonly Alerta[]
  notas: readonly string[]
}

export interface EngineResult {
  /** Conduta principal. */
  recomendacao: Recomendacao
  /** Alternativas previstas pelo protocolo para o mesmo foco (ex.: "2ª opção"). */
  alternativas: readonly Recomendacao[]
  input: ClinicalInput
}
