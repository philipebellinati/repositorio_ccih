import { Lock } from 'lucide-react'
import { RESTRITOS } from '@/data'

/**
 * Antimicrobianos de uso restrito — não liberados empiricamente.
 *
 * Renderiza `RESTRITOS`. O objetivo é frear a prescrição empírica destes
 * agentes de reserva: cada card diz o alvo microbiológico que justifica o uso,
 * deixando claro que a liberação depende de identificação, não de suspeita.
 */
export function TabelaRestritos() {
  return (
    <div className="space-y-2.5 px-4 py-4">
      <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3 text-xs leading-relaxed text-foreground/90">
        Estes agentes são a <strong>reserva do hospital</strong>. Só devem ser
        prescritos <strong>com identificação microbiológica</strong> — nunca como terapia
        empírica. Liberá-los na dúvida acelera a resistência e queima a última linha.
      </div>

      {RESTRITOS.map((r) => (
        <div key={r.id} className="rounded-md border border-border bg-secondary/40 p-3">
          <div className="flex items-start gap-2">
            <Lock className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden />
            <div className="min-w-0">
              <h4 className="text-sm font-bold text-foreground">{r.nome}</h4>
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
                {r.classe}
              </p>
            </div>
          </div>

          <p className="mt-1.5 text-sm leading-snug text-foreground/90">
            <span className="font-semibold text-primary">Só com cultura para: </span>
            {r.alvo}
          </p>

          {r.observacao && (
            <p className="mt-1 text-xs leading-snug text-muted-foreground">{r.observacao}</p>
          )}

          {(r.doseAdulto || r.dosePediatrica || r.doseRenal) && (
            <div className="mt-2 space-y-1 rounded-md border border-border bg-secondary/40 p-2.5">
              <p className="kicker">Dose</p>
              {r.doseAdulto && (
                <p className="text-sm leading-snug text-foreground/90">
                  <span className="font-semibold text-primary">Adulto: </span>
                  {r.doseAdulto}
                </p>
              )}
              {r.dosePediatrica && (
                <p className="text-sm leading-snug text-foreground/90">
                  <span className="font-semibold text-primary">Pediatria: </span>
                  {r.dosePediatrica}
                </p>
              )}
              {r.doseRenal && (
                <div className="text-xs leading-snug text-muted-foreground">
                  <span className="font-semibold">Função renal:</span>
                  <ul className="mt-0.5 space-y-0.5">
                    {r.doseRenal.map((f, i) => (
                      <li key={i} className="flex gap-1.5">
                        <span aria-hidden className="mt-[6px] h-1 w-1 shrink-0 rounded-full bg-primary/60" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {r.fonteDose && (
                <p className="text-[11px] italic leading-snug text-muted-foreground">
                  {r.fonteDose}
                </p>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
