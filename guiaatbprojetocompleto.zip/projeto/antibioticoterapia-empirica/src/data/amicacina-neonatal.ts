/**
 * Amicacina no período neonatal.
 *
 * SUBSTITUI a posologia grafada na tabela 6.6 do protocolo empírico
 * ("Amicacina 5-7 mg/kg EV até 8/8h"), que não discrimina maturidade renal.
 * No recém-nascido a depuração depende de idade gestacional e pós-natal, e as
 * doses corretas são 3 a 4 vezes maiores, com intervalos bem mais longos —
 * usar 5–7 mg/kg a cada 8 h subdosaria e exporia a toxicidade sem necessidade.
 *
 * Definição do SCIH.
 */

export interface FaixaAmicacinaNeonatal {
  /** Rótulo da faixa de idade gestacional. */
  ig: string
  /** Limites de idade gestacional em semanas, para a seleção automática. */
  igMin: number | null
  igMax: number | null
  /** Esquema nos primeiros 7 dias de vida. */
  ate7Dias: { mgPorKg: number; intervaloH: number }
  /** Esquema após o 7º dia de vida. */
  apos7Dias: { mgPorKg: number; intervaloH: number }
}

export const AMICACINA_NEONATAL: readonly FaixaAmicacinaNeonatal[] = [
  {
    ig: '< 29 semanas',
    igMin: null,
    igMax: 29,
    ate7Dias: { mgPorKg: 18, intervaloH: 48 },
    apos7Dias: { mgPorKg: 15, intervaloH: 36 },
  },
  {
    ig: '30 a 34 semanas',
    igMin: 29,
    igMax: 35,
    ate7Dias: { mgPorKg: 18, intervaloH: 36 },
    apos7Dias: { mgPorKg: 15, intervaloH: 24 },
  },
  {
    ig: '≥ 35 semanas',
    igMin: 35,
    igMax: null,
    // Nesta faixa o protocolo não distingue idade pós-natal.
    ate7Dias: { mgPorKg: 15, intervaloH: 24 },
    apos7Dias: { mgPorKg: 15, intervaloH: 24 },
  },
]

export interface DoseAmicacinaNeonatal {
  faixa: FaixaAmicacinaNeonatal
  mgPorKg: number
  intervaloH: number
  /** Dose por administração em mg, quando o peso é conhecido. */
  doseMg?: number
  periodo: 'ate7' | 'apos7'
}

/**
 * Seleciona o esquema pela idade gestacional e pós-natal.
 *
 * @param igSemanas   idade gestacional ao nascimento, em semanas
 * @param idadeDias   idade pós-natal, em dias de vida
 * @param pesoKg      peso, opcional — quando informado, devolve a dose em mg
 * @returns `undefined` se a idade gestacional cair fora das faixas descritas
 */
export function doseAmicacinaNeonatal(
  igSemanas: number,
  idadeDias: number,
  pesoKg?: number,
): DoseAmicacinaNeonatal | undefined {
  const faixa = AMICACINA_NEONATAL.find((f) => {
    const acima = f.igMin === null || igSemanas > f.igMin
    const abaixo = f.igMax === null || igSemanas < f.igMax
    return acima && abaixo
  })
  if (!faixa) return undefined

  const periodo = idadeDias <= 7 ? 'ate7' : 'apos7'
  const esquema = periodo === 'ate7' ? faixa.ate7Dias : faixa.apos7Dias

  return {
    faixa,
    mgPorKg: esquema.mgPorKg,
    intervaloH: esquema.intervaloH,
    periodo,
    ...(pesoKg !== undefined && pesoKg > 0
      ? { doseMg: Math.round(esquema.mgPorKg * pesoKg * 10) / 10 }
      : {}),
  }
}
