import type { Foco, Secao } from '@/domain/types'

/**
 * Identificação do guia.
 *
 * O código do POP e os demais signatários do documento original foram
 * deliberadamente omitidos: este é um guia de consulta rápida, não a reprodução
 * do documento controlado. A responsabilidade técnica é registrada em
 * `responsavel`, campo único.
 */
export const PROTOCOLO = {
  titulo: 'Protocolo de Antibioticoterapia Empírica',
  revisao: '20/03/2026',
  validade: '20/03/2028',
  setor: 'SCIH',
  instituicao: 'Hospital Evangélico de Londrina',
  responsavel: 'Dr. Philipe Bellinati — Coordenador do SCIH',
} as const

/**
 * Item 5 do protocolo — "Etapas Iniciais da Gestão de Infecções".
 * Este fluxo de 5 etapas é a espinha dorsal da navegação do app: cada etapa do
 * fluxograma institucional vira uma etapa visível na interface.
 */
export const FLUXO_PROCEDIMENTO = [
  {
    numero: 1,
    rotulo: 'Suspeita Clínica',
    titulo: 'Identificação de Infecção',
    descricao: 'Médico reconhece sinais e sintomas de infecção',
  },
  {
    numero: 2,
    rotulo: 'Coleta de Culturas',
    titulo: 'Coleta de Amostras',
    descricao: 'Coletar culturas e exames laboratoriais antes da primeira dose de ATB',
  },
  {
    numero: 3,
    rotulo: 'Classificação da Infecção',
    titulo: 'Definição do Tipo',
    descricao: 'Classificar a infecção como comunitária ou IRAS e definir o setor',
  },
  {
    numero: 4,
    rotulo: 'Prescrição Empírica',
    titulo: 'Início da Terapia',
    descricao: 'Prescrever e administrar a primeira dose de ATB dentro de 1-3 horas',
  },
  {
    numero: 5,
    rotulo: 'Reavaliação',
    titulo: 'Monitoramento do Progresso',
    descricao: 'Reavaliar o paciente em 48-72 horas para avaliar a resposta ao tratamento',
  },
] as const

/** Notas de rodapé do PDF, referenciadas pelas regras. */
export const NOTAS_RODAPE: Record<string, string> = {
  n1: 'Para Vancomicina, usar Protocolo de Vancomicina.',
  n2:
    'Considerar a adição de Vancomicina ao esquema de Ceftriaxona na suspeita de ' +
    'meningite pneumocócica se: o paciente apresentar quadro grave, uso prévio de ' +
    'betalactâmicos nos últimos 3 meses ou em regiões com vigilância epidemiológica ' +
    'demonstrando resistência local.',
  n3:
    'Os valores na tabela referem-se à dose individual (por administração), e não à ' +
    'dose total diária — isto é, mg/kg/dose.',
  n4:
    'Devido à alta prevalência de resistência do S. pneumoniae à ceftriaxona em ' +
    'menores de 5 anos (especialmente sorotipo 19A, com > 95% de resistência em ' +
    'meningites), associar Vancomicina ao tratamento empírico inicial de meningite ' +
    'bacteriana. A suspensão deve ocorrer apenas após confirmação laboratorial de ' +
    'sensibilidade.',
}

export const SECOES: Record<string, Secao> = {
  '6.1': {
    id: '6.1',
    titulo: 'Infecções Comunitárias — Adulto',
    populacoes: ['adulto'],
    origem: 'comunitaria',
    notas: ['n1'],
  },
  '6.2': {
    id: '6.2',
    titulo: 'IRAS — Enfermaria Adulto',
    populacoes: ['adulto'],
    origem: 'iras',
    setores: ['enfermaria', 'ps'],
    notas: ['n1'],
  },
  '6.3': {
    id: '6.3',
    titulo: 'Infecções Comunitárias — Pediatria',
    populacoes: ['pediatrico', 'neonatal'],
    origem: 'comunitaria',
    notas: ['n1', 'n3'],
  },
  '6.4': {
    id: '6.4',
    titulo: 'IRAS — Enfermaria Pediátrica',
    populacoes: ['pediatrico'],
    origem: 'iras',
    setores: ['enfermaria', 'ps'],
    notas: ['n1', 'n3'],
  },
  '6.5': {
    id: '6.5',
    titulo: 'IRAS — UTI Adulto',
    populacoes: ['adulto'],
    origem: 'iras',
    // UCO e Unidade Neurológica seguem esta tabela por definição do SCIH
    // (ver `resolverSecao`).
    setores: ['uti', 'uco', 'neuro'],
    notas: ['n1'],
  },
  '6.6': {
    id: '6.6',
    titulo: 'IRAS — UTI Neonatal e Pediátrica',
    populacoes: ['pediatrico', 'neonatal'],
    origem: 'iras',
    setores: ['uti', 'uci_neonatal'],
    notas: ['n1', 'n3'],
  },
}

/**
 * Catálogo de focos infecciosos (coluna "FOCO" das tabelas). Os identificadores
 * são compartilhados entre as seções sempre que designam o mesmo sítio, de modo
 * que a interface possa oferecer a mesma lista de focos independentemente da
 * população — filtrando depois pelo que a seção realmente cobre.
 */
export const FOCOS: Record<string, Foco> = {
  pneumonia: {
    id: 'pneumonia',
    nome: 'Pneumonia',
    descricao: 'Foco respiratório comunitário',
    icone: 'lungs',
  },
  pneumonia_hospitalar: {
    id: 'pneumonia_hospitalar',
    nome: 'Pneumonia hospitalar',
    descricao: 'PNM de início hospitalar, não associada a VM',
    icone: 'lungs',
  },
  pnm_vm: {
    id: 'pnm_vm',
    nome: 'Pneumonia em UTI (PNAV/PAV)',
    descricao: 'Associada ou não à ventilação mecânica',
    icone: 'lungs',
  },
  itu: {
    id: 'itu',
    nome: 'Infecção do trato urinário',
    descricao: 'ITU e ITU associada a cateter vesical',
    icone: 'droplet',
  },
  abdominal: {
    id: 'abdominal',
    nome: 'Infecção abdominal',
    descricao: 'Foco intra-abdominal comunitário',
    icone: 'circle-dot',
  },
  tgi: {
    id: 'tgi',
    nome: 'Infecção do TGI',
    descricao: 'Trato gastrointestinal — IRAS',
    icone: 'circle-dot',
  },
  pele_partes_moles: {
    id: 'pele_partes_moles',
    nome: 'Pele e partes moles',
    descricao: 'Com ou sem sinais de necrose',
    icone: 'hand',
  },
  sepse_sem_foco: {
    id: 'sepse_sem_foco',
    nome: 'Sepse sem foco determinado',
    descricao: 'Inclui sepse neonatal precoce e tardia',
    icone: 'activity',
  },
  meningite: {
    id: 'meningite',
    nome: 'Meningite bacteriana',
    descricao: 'Terapia empírica inicial',
    icone: 'brain',
  },
  endocardite: {
    id: 'endocardite',
    nome: 'Endocardite aguda',
    icone: 'heart-pulse',
  },
  osteoarticular: {
    id: 'osteoarticular',
    nome: 'Infecção óssea / articular',
    icone: 'bone',
  },
  ipcs: {
    id: 'ipcs',
    nome: 'IPCS / ICS-CVC',
    descricao: 'Infecção primária de corrente sanguínea',
    icone: 'syringe',
  },
  protese: {
    id: 'protese',
    nome: 'Infecção de prótese',
    icone: 'wrench',
  },
  isc: {
    id: 'isc',
    nome: 'Infecção de sítio cirúrgico',
    icone: 'scissors',
  },
}
