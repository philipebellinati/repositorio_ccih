import { FLUXO_PROCEDIMENTO } from '@/data'

/**
 * Reproduz o fluxograma "Etapas Iniciais da Gestão de Infecções" (item 5 do
 * protocolo) como linha do tempo vertical — a leitura horizontal do PDF não
 * cabe numa tela de celular sem reduzir o texto a um tamanho ilegível.
 */
export function FluxoEtapas() {
  return (
    <ol className="relative space-y-0 px-4 py-4">
      {FLUXO_PROCEDIMENTO.map((etapa, i) => (
        <li key={etapa.numero} className="relative flex gap-4 pb-5 last:pb-0">
          {/* Linha vertical que conecta as etapas */}
          {i < FLUXO_PROCEDIMENTO.length - 1 && (
            <span
              aria-hidden
              className="absolute left-[15px] top-8 h-full w-px bg-border"
            />
          )}

          <span className="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-primary/60 bg-background text-sm font-bold text-primary">
            {etapa.numero}
          </span>

          <div className="pt-0.5">
            <p className="text-sm font-bold uppercase tracking-wide text-primary">
              {etapa.rotulo}
            </p>
            <p className="text-sm font-semibold text-foreground">{etapa.titulo}</p>
            <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">
              {etapa.descricao}
            </p>
          </div>
        </li>
      ))}
    </ol>
  )
}
