import type { ProtocolRule } from '@/domain/types'

/**
 * 6.6 — IRAS, UTI NEONATAL E PEDIÁTRICA (página 5 do protocolo).
 *
 * Única tabela que segrega condutas por idade pós-natal: várias linhas existem
 * em par, "(> 28 dias)" e "(neonatal)". Adotamos ≤ 28 dias de vida como
 * definição operacional de neonatal — ver ambiguidade A-02.
 *
 * As linhas de sepse neonatal precoce/tardia trazem a única regra de SUBSTITUIÇÃO
 * de fármaco do protocolo inteiro ("Se ISC: trocar X por Cefepime"), modelada
 * aqui como regras próprias em vez de mutação do esquema base.
 */
export const SECAO_6_6: readonly ProtocolRule[] = [
  // --- Pneumonia -----------------------------------------------------------
  {
    id: '6.6.pnm.pav',
    secao: '6.6',
    focoId: 'pnm_vm',
    condicaoLabel: 'PAV',
    // Diferente do adulto (6.5), aqui não há distinção precoce/tardia: qualquer
    // PAV vai direto para carbapenêmico + glicopeptídeo.
    prioridade: 20,
    match: (m) => typeof m.diasVentilacaoMecanica === 'number',
    prescricoes: [
      {
        drugId: 'meropenem',
        dosePonderal: { valor: 20, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
      },
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q6h' },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Meropenem 20mg/kg EV 8/8h + Vancomicina¹',
  },
  {
    id: '6.6.pnm.nao-vm',
    secao: '6.6',
    focoId: 'pnm_vm',
    condicaoLabel: 'PNM não assoc. a VM',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'NO NEONATO, CONFERIR: 50 mg/kg 8/8h (150 mg/kg/dia) é a dose pediátrica ' +
            'geral. O quadro institucional traz cefepime neonatal em 30 mg/kg 12/12h ' +
            '(60 mg/kg/dia) — ver a ficha de doses pediátricas. Divergência pendente ' +
            'de definição do SCIH.',
        ],
      },
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q6h' },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Cefepime 50mg/kg EV 8/8h + Vancomicina¹',
  },

  // --- ITU -----------------------------------------------------------------
  {
    id: '6.6.itu.base',
    secao: '6.6',
    focoId: 'itu',
    condicaoLabel: 'ITU',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
          observacoes: [
            'mg/kg calculado APENAS sobre o componente piperacilina (proporção 8:1). ' +
            'Bula: 100 mg/kg/dose de piperacilina a cada 6 ou 8 h em > 9 meses; ' +
            '80 mg/kg/dose a cada 8 h entre 2 e 9 meses. Máximo 24 g/dia. ' +
            'Acima de 40 kg, usar dose de adulto.',
            'NO NEONATO (≤ 28 dias) A BULA NÃO COBRE ESTA POSOLOGIA: ela começa aos ' +
              '2 meses. O quadro institucional traz 100 mg/kg 12/12h até 7 dias de ' +
              'vida e 100 mg/kg 8/8h de 8 a 28 dias (200 a 300 mg/kg/dia) — nunca ' +
              '6/6h. Usar a grade neonatal da ficha de doses pediátricas e discutir ' +
              'com o SCIH antes de aplicar 6/6h no recém-nascido.',
          ],
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Piperacilina/tazobactam 75mg/kg EV 6/6h',
  },

  // --- IPCS: quatro linhas (dispositivo × idade pós-natal) -----------------
  {
    id: '6.6.ipcs.cateter-neonatal',
    secao: '6.6',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS assoc. a cateter (neonatal)',
    prioridade: 30,
    match: (m, input) => m.dispositivoInvasivo === true && input.populacao === 'neonatal',
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'amicacina',
        // A posologia neonatal depende de idade gestacional e pós-natal, que a
        // linha do protocolo não carrega — vem da tabela dedicada do SCIH, que
        // SUBSTITUI o "5-7 mg/kg até 8/8h" do documento original.
        via: 'EV',
        intervalo: 'q24h',
        tabelaDose: 'Tabela de amicacina neonatal',
        observacoes: [
          'Dose e intervalo definidos por idade gestacional e pós-natal — usar a ' +
            'calculadora na ficha 12.',
        ],
      },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Vancomicina¹ + Amicacina conforme idade gestacional e pós-natal',
  },
  {
    id: '6.6.ipcs.cateter-pediatrico',
    secao: '6.6',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS assoc. a cateter (> 28 dias)',
    prioridade: 25,
    match: (m) => m.dispositivoInvasivo === true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q6h' },
      {
        drugId: 'cefepime',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'NO NEONATO, CONFERIR: 50 mg/kg 8/8h (150 mg/kg/dia) é a dose pediátrica ' +
            'geral. O quadro institucional traz cefepime neonatal em 30 mg/kg 12/12h ' +
            '(60 mg/kg/dia) — ver a ficha de doses pediátricas. Divergência pendente ' +
            'de definição do SCIH.',
        ],
      },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Vancomicina¹ + Cefepime 50mg/kg EV 8/8h',
  },
  {
    id: '6.6.ipcs.sem-dispositivo-neonatal',
    secao: '6.6',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS não assoc. a dispositivos (neonatal)',
    prioridade: 10,
    match: (_m, input) => input.populacao === 'neonatal',
    prescricoes: [
      {
        drugId: 'oxacilina',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Oxacilina 50mg/kg EV 6/6h',
  },
  {
    id: '6.6.ipcs.sem-dispositivo-pediatrico',
    secao: '6.6',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS não assoc. a dispositivos (> 28 dias)',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'NO NEONATO, CONFERIR: 50 mg/kg 8/8h (150 mg/kg/dia) é a dose pediátrica ' +
            'geral. O quadro institucional traz cefepime neonatal em 30 mg/kg 12/12h ' +
            '(60 mg/kg/dia) — ver a ficha de doses pediátricas. Divergência pendente ' +
            'de definição do SCIH.',
        ],
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Cefepime 50mg/kg EV 8/8h',
  },

  // --- Infecção do TGI -----------------------------------------------------
  {
    id: '6.6.tgi.base',
    secao: '6.6',
    focoId: 'tgi',
    condicaoLabel: 'Infecção TGI',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
          observacoes: [
            'mg/kg calculado APENAS sobre o componente piperacilina (proporção 8:1). ' +
            'Bula: 100 mg/kg/dose de piperacilina a cada 6 ou 8 h em > 9 meses; ' +
            '80 mg/kg/dose a cada 8 h entre 2 e 9 meses. Máximo 24 g/dia. ' +
            'Acima de 40 kg, usar dose de adulto.',
            'NO NEONATO (≤ 28 dias) A BULA NÃO COBRE ESTA POSOLOGIA: ela começa aos ' +
              '2 meses. O quadro institucional traz 100 mg/kg 12/12h até 7 dias de ' +
              'vida e 100 mg/kg 8/8h de 8 a 28 dias (200 a 300 mg/kg/dia) — nunca ' +
              '6/6h. Usar a grade neonatal da ficha de doses pediátricas e discutir ' +
              'com o SCIH antes de aplicar 6/6h no recém-nascido.',
          ],
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Piperacilina/tazobactam 75mg/kg EV 6/6h',
  },

  // --- Sepse: geral, neonatal precoce e neonatal tardia --------------------
  // As variantes "Se ISC" que o documento trazia foram RETIRADAS por definição
  // do SCIH: a sigla gerava leitura ambígua à beira-leito e a troca que ela
  // determinava não se sustentava como regra automática. A sepse neonatal passa
  // a ter uma linha única por tempo de início (precoce/tardia).
  {
    id: '6.6.sepse.neonatal-precoce',
    secao: '6.6',
    focoId: 'sepse_sem_foco',
    condicaoLabel: 'Sepse neonatal precoce',
    prioridade: 50,
    match: (m, input) => input.populacao === 'neonatal' && m.sepseNeonatal === 'precoce',
    prescricoes: [
      {
        drugId: 'ampicilina',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'No neonato o intervalo da ampicilina varia por idade/peso (12/12h a ' +
            '6/6h) — ver a ficha de doses pediátricas.',
        ],
      },
      {
        drugId: 'gentamicina',
        dosePonderal: { valor: [5, 7], unidade: 'mg/kg', base: 'dia' },
        via: 'EV',
        intervalo: 'q24h',
        observacoes: [
          'No neonato a gentamicina é dosada por idade/peso (quadro pediátrico: ' +
            '5 mg/kg 48/48h se ≤ 2 kg; 4–5 mg/kg 24/24h se > 2 kg) — ver a ficha de ' +
            'doses pediátricas.',
        ],
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Ampicilina 50mg/kg EV 6/6h + Gentamicina 5-7mg/kg/dia',
  },
  {
    id: '6.6.sepse.neonatal-tardia',
    secao: '6.6',
    focoId: 'sepse_sem_foco',
    condicaoLabel: 'Sepse neonatal tardia',
    prioridade: 40,
    match: (m, input) => input.populacao === 'neonatal' && m.sepseNeonatal === 'tardia',
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'amicacina',
        // A posologia neonatal depende de idade gestacional e pós-natal, que a
        // linha do protocolo não carrega — vem da tabela dedicada do SCIH, que
        // SUBSTITUI o "5-7 mg/kg até 8/8h" do documento original.
        via: 'EV',
        intervalo: 'q24h',
        tabelaDose: 'Tabela de amicacina neonatal',
        observacoes: [
          'Dose e intervalo definidos por idade gestacional e pós-natal — usar a ' +
            'calculadora na ficha 12.',
        ],
      },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Vancomicina¹ + Amicacina conforme idade gestacional e pós-natal',
  },
  {
    id: '6.6.sepse.2a',
    secao: '6.6',
    focoId: 'sepse_sem_foco',
    condicaoLabel: 'Sepse s/ foco — 2ª opção',
    prioridade: 10,
    match: (m) => m.segundaOpcao === true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q6h' },
      {
        drugId: 'piperacilina_tazobactam',
        // Dose pediátrica ÚNICA, definida pelo SCIH para todo o guia:
        // 75 mg/kg/dose a cada 6 h (300 mg/kg/dia), igual em 6.3, 6.4 e 6.6.
        dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'mg/kg calculado APENAS sobre o componente piperacilina (proporção 8:1). ' +
            'Bula: 100 mg/kg/dose de piperacilina a cada 6 ou 8 h em > 9 meses; ' +
            '80 mg/kg/dose a cada 8 h entre 2 e 9 meses. Máximo 24 g/dia. ' +
            'Acima de 40 kg, usar dose de adulto.',
            'NO NEONATO (≤ 28 dias) A BULA NÃO COBRE ESTA POSOLOGIA: ela começa aos ' +
              '2 meses. O quadro institucional traz 100 mg/kg 12/12h até 7 dias de ' +
              'vida e 100 mg/kg 8/8h de 8 a 28 dias (200 a 300 mg/kg/dia) — nunca ' +
              '6/6h. Usar a grade neonatal da ficha de doses pediátricas e discutir ' +
              'com o SCIH antes de aplicar 6/6h no recém-nascido.',
        ],
      },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Vancomicina¹ + Piperacilina/tazobactam 75mg/kg 6/6h',
  },
  {
    id: '6.6.sepse.1a',
    secao: '6.6',
    focoId: 'sepse_sem_foco',
    condicaoLabel: 'Sepse s/ foco — 1ª opção',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q6h' },
      {
        drugId: 'cefepime',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'NO NEONATO, CONFERIR: 50 mg/kg 8/8h (150 mg/kg/dia) é a dose pediátrica ' +
            'geral. O quadro institucional traz cefepime neonatal em 30 mg/kg 12/12h ' +
            '(60 mg/kg/dia) — ver a ficha de doses pediátricas. Divergência pendente ' +
            'de definição do SCIH.',
        ],
      },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Vancomicina¹ + Cefepime 50mg/kg EV 8/8h',
  },
]
