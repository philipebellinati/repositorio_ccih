import { useCallback, useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'

/**
 * Barra de rolagem horizontal SEMPRE VISÍVEL.
 *
 * POR QUE NÃO USAR A NATIVA
 * A barra nativa do navegador é "overlay" no Chromium, no iOS e no Android:
 * não reserva espaço no layout e só aparece durante o gesto. Medido neste
 * projeto, `offsetHeight - clientHeight` = 0 mesmo com `::-webkit-scrollbar`
 * estilizado. Resultado prático: em repouso, nada indica que a fila de chips
 * continua para a direita — o último chip aparece cortado e o usuário conclui
 * que aquilo é tudo.
 *
 * Esta barra é desenhada pelo app, então existe em qualquer plataforma. Reflete
 * a posição do scroll e permite arrastar, além de clicar para saltar.
 *
 * Some sozinha quando não há transbordo — barra de rolagem sem o que rolar é
 * ruído visual.
 */
export function BarraRolagem({
  alvoRef,
  className,
  rotulo = 'Rolar seções',
}: {
  /** Elemento com `overflow-x: auto` cuja rolagem esta barra representa. */
  alvoRef: React.RefObject<HTMLElement | null>
  className?: string
  rotulo?: string
}) {
  const [estado, setEstado] = useState({ proporcao: 1, posicao: 0 })
  const trilhoRef = useRef<HTMLDivElement | null>(null)
  const arrastando = useRef(false)

  const medir = useCallback(() => {
    const el = alvoRef.current
    if (!el) return
    const { scrollWidth, clientWidth, scrollLeft } = el
    const proporcao = scrollWidth > 0 ? clientWidth / scrollWidth : 1
    const rolavel = scrollWidth - clientWidth
    const posicao = rolavel > 0 ? scrollLeft / rolavel : 0
    setEstado({ proporcao: Math.min(proporcao, 1), posicao })
  }, [alvoRef])

  useEffect(() => {
    const el = alvoRef.current
    if (!el) return
    medir()
    el.addEventListener('scroll', medir, { passive: true })
    // O transbordo muda quando a fonte carrega ou a janela muda de largura.
    const ro = new ResizeObserver(medir)
    ro.observe(el)
    for (const filho of Array.from(el.children)) ro.observe(filho)
    window.addEventListener('resize', medir)
    return () => {
      el.removeEventListener('scroll', medir)
      ro.disconnect()
      window.removeEventListener('resize', medir)
    }
  }, [alvoRef, medir])

  /** Converte um clique/arraste no trilho em posição de scroll do alvo. */
  const irPara = useCallback(
    (clienteX: number) => {
      const el = alvoRef.current
      const trilho = trilhoRef.current
      if (!el || !trilho) return
      const r = trilho.getBoundingClientRect()
      const larguraPolegar = r.width * estado.proporcao
      // O centro do polegar acompanha o cursor, limitado ao trilho.
      const bruto = (clienteX - r.left - larguraPolegar / 2) / (r.width - larguraPolegar || 1)
      const frac = Math.max(0, Math.min(1, bruto))
      el.scrollLeft = frac * (el.scrollWidth - el.clientWidth)
    },
    [alvoRef, estado.proporcao],
  )

  useEffect(() => {
    const mover = (e: PointerEvent) => {
      if (arrastando.current) irPara(e.clientX)
    }
    const soltar = () => {
      arrastando.current = false
    }
    window.addEventListener('pointermove', mover)
    window.addEventListener('pointerup', soltar)
    return () => {
      window.removeEventListener('pointermove', mover)
      window.removeEventListener('pointerup', soltar)
    }
  }, [irPara])

  // Nada a rolar: a barra não aparece.
  if (estado.proporcao >= 0.999) return null

  const larguraPct = Math.max(estado.proporcao * 100, 12) // piso p/ continuar clicável
  const espaco = 100 - larguraPct
  const esquerdaPct = espaco * estado.posicao

  return (
    <div
      ref={trilhoRef}
      role="scrollbar"
      aria-label={rotulo}
      aria-orientation="horizontal"
      aria-valuenow={Math.round(estado.posicao * 100)}
      aria-valuemin={0}
      aria-valuemax={100}
      onPointerDown={(e) => {
        arrastando.current = true
        irPara(e.clientX)
      }}
      className={cn(
        'relative h-1.5 w-full cursor-pointer touch-none rounded-full bg-secondary',
        className,
      )}
    >
      <div
        className="absolute top-0 h-full rounded-full bg-primary/70 transition-[left] duration-75"
        style={{ width: `${larguraPct}%`, left: `${esquerdaPct}%` }}
      />
    </div>
  )
}
