import { FactCell, Panel } from './ui/primitives'
import { PROTOCOLO } from '@/data'
import { LOGO_HE_DATA_URI } from '@/assets/logo'

/**
 * Cabeçalho do guia: kicker, título em duas linhas e painel 2×2 de fatos-chave.
 *
 * O painel responde à pergunta que o plantonista faz antes de qualquer outra —
 * "quando começo, o que colho, quando reavalio, o que é restrito" — do mesmo
 * modo que o guia de profilaxia responde "momento, dose, repique, duração".
 */
export function HeroHeader() {
  return (
    <header className="px-4 pt-6">
      {/* A marca fica sobre um bloco branco: no tema escuro, preservar as cores
          originais do logotipo vale mais que forçá-lo a combinar com o fundo. */}
      <div className="mb-4 inline-flex rounded-lg bg-white px-3 py-2">
        <img
          src={LOGO_HE_DATA_URI}
          alt="Hospital Evangélico de Londrina"
          width={437}
          height={362}
          className="h-12 w-auto"
        />
      </div>

      <p className="kicker">Guia de consulta rápida</p>
      {/* "Antibioticoterapia" tem 18 caracteres: em telas estreitas o tamanho
          precisa acompanhar a largura, senão a palavra vaza do viewport. */}
      <h1 className="mt-1 font-extrabold uppercase leading-[1.05] tracking-tight text-[clamp(1.75rem,7.2vw,3rem)]">
        Antibioticoterapia
        <span className="block font-light text-muted-foreground">Empírica</span>
      </h1>

      <Panel className="mt-5 grid grid-cols-1 divide-y divide-border sm:grid-cols-2 sm:divide-x">
        <FactCell rotulo="Primeira dose" nota="Não retardar aguardando exames de imagem">
          Dentro de <span className="hl">1–3 horas</span> da suspeita
        </FactCell>

        <FactCell rotulo="Culturas" nota="Hemoculturas: 2 pares">
          <span className="hl">Antes</span> da primeira dose
        </FactCell>

        <FactCell
          rotulo="Reavaliação"
          nota="Descalonar assim que houver identificação do agente"
        >
          <span className="hl">48–72 h</span> após o início
        </FactCell>

        <FactCell rotulo="Vancomicina" nota="Ataque, manutenção e correção na ficha 13">
          Alvo de vale <span className="hl">15–20 mg/L</span>
        </FactCell>
      </Panel>

      <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
        {PROTOCOLO.setor} · {PROTOCOLO.instituicao} · versão {PROTOCOLO.revisao} ·
        válido até {PROTOCOLO.validade}
      </p>
    </header>
  )
}
