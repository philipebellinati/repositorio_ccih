import { AlertTriangle } from 'lucide-react'
import { ALTERNATIVAS_ALERGIA } from '@/data'
import { MarkedText } from './MarkedText'

/**
 * Alternativas sem betalactâmico, foco a foco, para o paciente com alergia
 * verdadeira. Renderiza `ALTERNATIVAS_ALERGIA` — a mesma fonte de dados, para
 * que a lista não divirja do que o restante do guia afirma.
 *
 * Os focos marcados como `incerto` recebem tratamento visual distinto: em vez
 * de uma dose com falsa segurança, um aviso de que ali NÃO há bom substituto —
 * atendendo ao pedido "o que você não encontrar, me avise".
 */
export function AlternativasAlergiaFocos() {
  return (
    <div className="space-y-2.5 px-4 py-4">
      <p className="text-xs leading-relaxed text-muted-foreground">
        Proposta por foco, para <strong>reação grave ou IgE-mediada</strong>. Em reação
        leve/tardia, cefalosporina e carbapenêmico costumam ser seguros — ver a
        estratificação acima. Todo o conteúdo depende de aprovação do SCIH.
      </p>

      {ALTERNATIVAS_ALERGIA.map((alt) => (
        <div
          key={alt.focoId}
          className={
            'rounded-md border p-3 ' +
            (alt.incerto ? 'border-warning/50 bg-warning/5' : 'border-border bg-secondary/40')
          }
        >
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-bold text-foreground">{alt.foco}</h4>
            {alt.incerto && (
              <span className="inline-flex items-center gap-1 rounded-full bg-warning/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-warning">
                <AlertTriangle className="h-3 w-3" aria-hidden />
                Sem bom substituto
              </span>
            )}
          </div>

          <p className="mt-1 text-sm leading-snug text-foreground/90">
            <MarkedText texto={alt.esquema} />
          </p>

          {alt.ressalva && (
            <p className="mt-1 text-xs leading-snug text-muted-foreground">
              <MarkedText texto={alt.ressalva} />
            </p>
          )}
        </div>
      ))}
    </div>
  )
}
