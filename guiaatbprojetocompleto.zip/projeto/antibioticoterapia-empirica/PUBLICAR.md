# Como publicar o guia como site

O app é 100% estático — sem servidor, sem banco, sem back-end. Isso significa
que qualquer hospedagem de arquivos serve, e todas as opções abaixo têm plano
gratuito suficiente para o uso de um serviço hospitalar.

Nenhum dado de paciente sai do aparelho: peso, creatinina e os marcos do
cronômetro ficam só na memória do navegador. Não há coleta, não há telemetria.

---

## Opção A — Netlify Drop (mais rápido, sem instalar nada)

Leva menos de um minuto e não exige conta para o primeiro deploy.

1. Gere a pasta a publicar:
   ```bash
   npm install
   npm run build
   ```
   Isso cria a pasta `dist/`.

2. Abra **https://app.netlify.com/drop**

3. **Arraste a pasta `dist/` inteira** para a área indicada no navegador.

4. Pronto — o site sobe com um endereço tipo
   `https://algum-nome-aleatorio.netlify.app`.

5. Crie uma conta gratuita para: manter o site permanentemente, trocar o
   endereço para algo como `atb-empirico-he.netlify.app` e apontar um domínio
   próprio se o hospital tiver.

**Para atualizar depois:** rode `npm run build` de novo e arraste a nova `dist/`
no painel do site, em *Deploys → Drag and drop*.

---

## Opção B — Vercel (melhor para atualizações contínuas)

Vale a pena se o código estiver no GitHub: cada alteração publica sozinha.

1. Suba o projeto para um repositório no GitHub.

2. Em **https://vercel.com/new**, importe o repositório.

3. Configure:
   - **Framework Preset:** Vite
   - **Root Directory:** `antibioticoterapia-empirica`
     *(passo essencial — o projeto está numa subpasta)*
   - Build Command e Output Directory: deixe o padrão; o `vercel.json` do
     projeto já cuida disso.

4. Clique em **Deploy**.

Daí em diante, todo `git push` publica automaticamente.

**Sem usar o GitHub:** instale a CLI e publique direto da sua máquina.

```bash
npm i -g vercel
cd antibioticoterapia-empirica
vercel --prod
```

---

## Opção C — GitHub Pages (já automatizado neste repositório)

O repositório já tem o workflow `.github/workflows/publicar.yml`. Ele roda os
testes, faz o build e publica sozinho a cada push na branch principal. Não é
preciso mexer em configuração de build: o `BASE_PATH` do subcaminho do Pages já
é injetado pelo workflow.

**Ligar leva dois cliques:**

1. No repositório, vá em **Settings → Pages**.
2. Em *Source*, escolha **GitHub Actions**.

Pronto. O endereço sai em `https://<usuário>.github.io/<repositório>/` e aparece
na aba **Actions** ao fim do primeiro deploy.

Para publicar sem esperar um commit: aba **Actions** → *Publicar guia* → **Run
workflow**.

> **Pré-requisito:** o push precisa estar liberado. Enquanto o aplicativo do
> Claude tiver acesso somente leitura, os commits ficam presos aqui e nada sobe.
> Ver a seção *Liberando o push* no fim deste documento.

---

## Opção D — servidor do próprio hospital

Se a TI preferir hospedar internamente — o que mantém tudo na rede interna:

1. `npm run build`
2. Copie o conteúdo de `dist/` para a pasta pública do servidor web
   (`/var/www/html`, `htdocs`, `wwwroot`…).

**Exige duas configurações no servidor:**

- **HTTPS.** Sem ele o service worker não registra e o app não funciona offline.
- **Fallback para `index.html`** em qualquer rota. No Nginx:
  ```nginx
  location / {
      try_files $uri $uri/ /index.html;
  }
  ```

---

## Opção E — arquivo único, sem hospedagem

Para distribuir por e-mail, WhatsApp ou pasta de rede:

```bash
npm run build:single
```

Gera `dist-single/guia-antibioticoterapia-empirica.html` — **um arquivo só**, com
tudo dentro. Abre com duplo clique, funciona sem internet e sem instalação.

A única perda: não instala como ícone na tela de início, porque isso exige um
endereço web.

---

## Instalar no celular (depois de publicado)

**iPhone (Safari):** abrir o endereço → botão Compartilhar → *Adicionar à Tela
de Início*.

**Android (Chrome):** abrir o endereço → menu ⋮ → *Instalar aplicativo*.

Vira ícone, abre em tela cheia e funciona sem internet a partir da segunda
abertura.

Para o ícone aparecer certo no iPhone, gere os PNGs uma vez antes de publicar:

```bash
npm run icons
```

Depois descomente a linha `apple-touch-icon` no `index.html`.

---

## Sobre "deixar o acesso liberado"

Todas as opções acima geram um endereço **público**: quem tiver o link abre, sem
conta, sem login, sem convite. É o que se quer num guia de plantão — o residente
às três da manhã não pode esbarrar numa tela de senha.

Duas consequências que vale enxergar antes de divulgar:

- **Link público é link indexável.** Se o hospital não quiser o protocolo
  achável no Google, peça à TI o `robots.txt` bloqueando, ou vá para a Opção D
  (servidor interno). Um endereço "secreto" não é proteção.
- **O link do artifact do Claude não serve para isso.** Ele nasce privado e o
  compartilhamento é limitado. Serve para você revisar; para a equipe usar,
  publique por uma das opções acima.

Nenhum dado de paciente sai do aparelho em qualquer das opções — peso,
creatinina e o cronômetro ficam na memória do navegador.

---

## Liberando o push (necessário para as Opções B e C)

O código está commitado na branch `claude/antibiotic-protocol-app-eem49y`, mas o
push é recusado com **403**: o aplicativo do Claude tem acesso *somente leitura*
ao repositório. Não é falha de rede — repetir não resolve.

Para liberar, no GitHub: **Settings → GitHub Apps → Claude → Configure** e
conceda permissão de **leitura e escrita** ao repositório `philipebellinati/teste`.

Feito isso, o push sobe e — com a Opção C ligada — o site publica sozinho.

---

## Recomendação

**Para hoje, sem depender de ninguém: Opção A (Netlify Drop).** Arraste a pasta
`dist/` e em um minuto existe um endereço público para testar com a equipe.
Não precisa de GitHub, não precisa esperar liberação de permissão.

**Para virar rotina: Opção C (GitHub Pages).** Já está automatizada aqui e é
gratuita; falta só liberar o push e ligar o Pages. A partir daí, cada revisão do
protocolo vira um commit e o site se atualiza sozinho, com os 108 testes rodando
antes de cada publicação — se alguém errar uma dose, o build falha e a versão
errada não vai ao ar.

**Vercel (Opção B)** entrega o mesmo que a C e depende igualmente do GitHub.
Escolha uma das duas, não as duas.

Se a política do hospital exigir que nada trafegue fora da rede interna, vá
direto para a **Opção D**.
