/**
 * Doses e diluições pediátricas — transcrição do quadro da UTI Pediátrica do
 * Hospital Universitário de Londrina.
 *
 * POR QUE ESTE MÓDULO EXISTE
 * O protocolo empírico do SCIH diz QUAL antimicrobiano usar em cada foco, mas
 * não padroniza a dose pediátrica por clearance nem a diluição. Este quadro —
 * de base Sanford (45ª ed.), Nelson e Red Book — é a fonte institucional dessas
 * doses. Trazê-lo para dentro do guia é o que o SCIH pediu ao mandar "padronizar
 * as doses em pediatria conforme o PDF".
 *
 * O QUE ESTE MÓDULO NÃO FAZ
 * Não decide terapia empírica: as tabelas 6.3/6.4/6.6 continuam sendo a fonte
 * de QUAL droga. Aqui está a DOSE de cada droga, por faixa de clearance e por
 * idade/peso no neonato. Onde a dose empírica do protocolo e este quadro
 * divergem, o divergente é sinalizado na ficha, não sobrescrito em silêncio.
 *
 * FIDELIDADE
 * As doses estão como no documento, inclusive onde a grafia gera dúvida (ex.:
 * eritromicina "12,5 mg/kg/dia – 6/6h", micafungina neonatal 10 mg/kg). Esses
 * pontos levam `alerta`, para conferência do SCIH — corrigir por conta própria
 * seria inventar dose.
 *
 * UNIDADES: quando a dose-normal é um mg/kg limpo, `pesoCalc` deixa a
 * calculadora converter em mg. Doses por superfície corporal (mg/1,73 m²), por
 * UI/kg ou por mg/kg/dia heterogêneo NÃO recebem `pesoCalc` — exibem só o texto,
 * porque uma conversão automática ali seria fonte de erro.
 */

export interface FaixaClearance {
  /** Rótulo da faixa, como no documento ("Clearance normal", "10-50ml/min"). */
  faixa: string
  /** Posologia naquela faixa. */
  dose: string
}

/** Grade neonatal: 4 células por peso corpóreo e idade pós-natal. */
export interface GradeNeonatal {
  ate2kg: { ate7d: string; d8a28: string }
  acima2kg: { ate7d: string; d8a28: string }
}

export interface DosePediatrica {
  id: string
  nome: string
  /** Sinônimos e nomes comerciais — indexados pela busca, nunca exibidos. */
  sinonimos?: readonly string[]
  classe?: string
  apresentacao: string
  diluicao: string
  infusao: string
  /** Doses por faixa de clearance (a lista "Doses:" do documento). */
  clearance: readonly FaixaClearance[]
  /** Grade neonatal, ou uma nota livre quando o documento foge da grade. */
  neonatal?: GradeNeonatal
  neonatalNota?: string
  observacoes?: readonly string[]
  /**
   * Uso RESTRITO: liberado só com identificação microbiológica, não como
   * terapia empírica. O texto diz o alvo que justifica o uso.
   */
  restrito?: string
  /** Ponto que precisa de conferência do SCIH (grafia ambígua no documento). */
  alerta?: string
  /**
   * Dose-normal em mg/kg, quando limpa, para a calculadora converter em mg.
   * Ausente de propósito em doses por superfície, UI ou mg/kg/dia heterogêneo.
   */
  pesoCalc?: { valor: number | readonly [number, number]; base: 'dose' | 'dia'; intervaloHoras: number }
}

// Atalhos para manter a transcrição legível sem repetir "Clearance".
const cl = (faixa: string, dose: string): FaixaClearance => ({ faixa, dose })

export const DOSES_PEDIATRICAS: readonly DosePediatrica[] = [
  {
    id: 'aciclovir',
    nome: 'Aciclovir',
    classe: 'Antiviral',
    apresentacao: 'Frasco 250 mg',
    diluicao: '100 mg de aciclovir por 4 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '5–10 mg/kg 8/8h'),
      cl('> 50 mL/min', '5–10 mg/kg 8/8h'),
      cl('25–50 mL/min', '5–10 mg/kg 12/12h'),
      cl('< 25 mL/min', '5–10 mg/kg 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '500 mg/m² 8/8h', d8a28: '500 mg/m² 8/8h' },
      acima2kg: { ate7d: '500 mg/m² 8/8h', d8a28: '500 mg/m² 8/8h' },
    },
    observacoes: ['Dose neonatal por superfície corporal — não converter por peso.'],
  },
  {
    id: 'amicacina',
    nome: 'Amicacina',
    classe: 'Aminoglicosídeo',
    apresentacao: 'Frasco 250 mg / 2 mL',
    diluicao: '5 mg de amicacina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '15–20 mg/kg 24/24h'),
      cl('> 50 mL/min', '15–20 mg/kg 24/24h'),
      cl('10–50 mL/min', '7,5 mg/kg 24/24h'),
      cl('< 10 mL/min', '7,5 mg/kg 48/48h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '15 mg/kg 48/48h', d8a28: '15 mg/kg 48/48h' },
      acima2kg: { ate7d: '15 mg/kg 24/24h', d8a28: '15 mg/kg 24/24h' },
    },
    observacoes: [
      'Usar peso ajustado nos aminoglicosídeos — calculadora na ficha 12.',
      'Monitorar função renal e níveis séricos.',
    ],
    alerta:
      'A grade neonatal deste quadro difere da tabela de amicacina neonatal por ' +
      'idade gestacional/pós-natal usada na ficha 12. Confirmar com o SCIH qual ' +
      'prevalece antes de padronizar.',
    pesoCalc: { valor: [15, 20], base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'amoxicilina_clavulanato',
    nome: 'Amoxicilina/clavulanato',
    classe: 'Aminopenicilina + inibidor de betalactamase',
    apresentacao: 'Frasco 500 mg amoxicilina + 100 mg clavulanato',
    diluicao: '10 mg de clavulanato por 1 mL de SF 0,9%',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '40–60 mg/kg/dia, 8/8h ou 12/12h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Sem ajuste'),
      cl('< 10 mL/min', 'Sem ajuste'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '15 mg/kg 12/12h', d8a28: '15 mg/kg 12/12h' },
    },
    observacoes: ['mg/kg referido ao componente amoxicilina.'],
    pesoCalc: { valor: [40, 60], base: 'dia', intervaloHoras: 8 },
  },
  {
    id: 'ampicilina',
    nome: 'Ampicilina',
    classe: 'Aminopenicilina',
    apresentacao: 'Frasco 1 g / 5 mL',
    diluicao: '30 mg de ampicilina por 1 mL de SF 0,9%',
    infusao: '30–60 min',
    clearance: [
      cl('Clearance normal', '25–50 mg/kg/dose 6/6h · enterococo 100 mg/kg/dose 6/6h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Sem ajuste'),
      cl('< 10 mL/min', 'Sem ajuste'),
    ],
    neonatal: {
      ate2kg: { ate7d: '50 mg/kg 12/12h', d8a28: '50 mg/kg 8/8h' },
      acima2kg: { ate7d: '50 mg/kg 8/8h', d8a28: '50 mg/kg 6/6h' },
    },
    pesoCalc: { valor: [25, 50], base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'ampicilina_sulbactam',
    nome: 'Ampicilina/sulbactam',
    sinonimos: ['Unasyn'],
    classe: 'Aminopenicilina + inibidor de betalactamase',
    apresentacao: 'Frasco 1 g ampicilina + 0,5 g sulbactam',
    diluicao: '45 mg por 1 mL de SF 0,9%',
    infusao: '30–60 min',
    clearance: [
      cl('Clearance normal', '75 mg/kg 6/6h'),
      cl('> 50 mL/min', '75 mg/kg 6/6h'),
      cl('10–50 mL/min', '75 mg/kg 12/12h'),
      cl('< 10 mL/min', '75 mg/kg 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '50 mg/kg (ampi) 12/12h', d8a28: '50 mg/kg (ampi) 8/8h' },
      acima2kg: { ate7d: '50 mg/kg (ampi) 8/8h', d8a28: '50 mg/kg (ampi) 6/6h' },
    },
    restrito:
      'Reservado para Acinetobacter (pelo sulbactam). Não liberar empiricamente — ' +
      'só com identificação microbiológica.',
    pesoCalc: { valor: 75, base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'anfotericina_b',
    nome: 'Anfotericina B (desoxicolato)',
    classe: 'Antifúngico poliênico',
    apresentacao: 'Frasco 50 mg / 10 mL',
    diluicao: '0,1 mg/mL em acesso periférico; 0,2 mg/mL em acesso central (SG 5%)',
    infusao: '120 min',
    clearance: [
      cl('Clearance normal', '0,5–1,5 mg/kg 24/24h'),
      cl('> 50 mL/min', '0,5–1,5 mg/kg 24/24h'),
      cl('10–50 mL/min', '0,5–1,5 mg/kg 24/24h'),
      cl('< 10 mL/min', '0,5–1,5 mg/kg 48/48h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '1 mg/kg 24/24h', d8a28: '1 mg/kg 24/24h' },
      acima2kg: { ate7d: '1 mg/kg 24/24h', d8a28: '1 mg/kg 24/24h' },
    },
    pesoCalc: { valor: [0.5, 1.5], base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'anfotericina_lipossomal',
    nome: 'Anfotericina B lipossomal',
    classe: 'Antifúngico poliênico (formulação lipídica)',
    apresentacao: 'Frasco 50 mg',
    diluicao: '2 mg por 1 mL de SG 5%',
    infusao: '120 min',
    clearance: [
      cl('Clearance normal', '3–5 mg/kg 24/24h'),
      cl('> 50 mL/min', '3–5 mg/kg 24/24h'),
      cl('10–50 mL/min', '3–5 mg/kg 24/24h'),
      cl('< 10 mL/min', '3–5 mg/kg 48/48h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '5 mg/kg 24/24h', d8a28: '5 mg/kg 24/24h' },
      acima2kg: { ate7d: '5 mg/kg 24/24h', d8a28: '5 mg/kg 24/24h' },
    },
    restrito:
      'Formulação lipossomal de uso restrito — reservada a toxicidade renal, ' +
      'refratariedade ou fungo documentado. Não liberar empiricamente.',
    pesoCalc: { valor: [3, 5], base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'anidulafungina',
    nome: 'Anidulafungina',
    classe: 'Antifúngico equinocandina',
    apresentacao: 'Frasco 100 mg / 30 mL',
    diluicao: 'Infusão a 1 mg/min',
    infusao: 'Limitada a 1 mg/min',
    clearance: [
      cl('Clearance normal', 'Ataque 200 mg/1,73 m²; manutenção 100 mg/1,73 m² 24/24h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Sem ajuste'),
      cl('< 10 mL/min', 'Sem ajuste'),
    ],
    neonatal: {
      ate2kg: { ate7d: '1,5 mg/kg 24/24h', d8a28: '1,5 mg/kg 24/24h' },
      acima2kg: { ate7d: '1,5 mg/kg 24/24h', d8a28: '1,5 mg/kg 24/24h' },
    },
    observacoes: ['Dose por superfície corporal — não converter por peso.'],
  },
  {
    id: 'aztreonam',
    nome: 'Aztreonam',
    classe: 'Monobactâmico',
    apresentacao: 'Frasco 1 g',
    diluicao: '20 mg de aztreonam por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '30 mg/kg 6/6h'),
      cl('> 50 mL/min', '30 mg/kg 6/6h'),
      cl('10–50 mL/min', '15–22,5 mg/kg 6/6h'),
      cl('< 10 mL/min', '15–22,5 mg/kg 6/6h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '15–30 mg/kg 12/12h', d8a28: '30 mg/kg 8/8h' },
      acima2kg: { ate7d: '15–30 mg/kg 8/8h', d8a28: '30 mg/kg 6/6h' },
    },
    observacoes: [
      'Monobactâmico: sem reatividade cruzada relevante com penicilinas — opção ' +
        'na alergia a betalactâmicos (exceto reação prévia a ceftazidima).',
    ],
    pesoCalc: { valor: 30, base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'azitromicina',
    nome: 'Azitromicina',
    classe: 'Macrolídeo',
    apresentacao: 'Frasco 500 mg',
    diluicao: '1 mg de azitromicina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '10 mg/kg 24/24h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Não recomendado'),
      cl('< 10 mL/min', 'Não recomendado'),
    ],
    neonatal: {
      ate2kg: { ate7d: '10 mg/kg 24/24h', d8a28: '10 mg/kg 24/24h' },
      acima2kg: { ate7d: '10 mg/kg 24/24h', d8a28: '10 mg/kg 24/24h' },
    },
    observacoes: ['Eliminação biliar: não requer ajuste por função renal.'],
    pesoCalc: { valor: 10, base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'sulfametoxazol_trimetoprima',
    nome: 'Sulfametoxazol/trimetoprima',
    sinonimos: ['Bactrim', 'cotrimoxazol', 'SMX-TMP'],
    classe: 'Sulfonamida + diaminopirimidina',
    apresentacao: 'Ampola 5 mL (400/80 mg)',
    diluicao: '1 mL por 5 mL de SF 0,9%',
    infusao: '60–90 min',
    clearance: [
      cl('Clearance normal', '60 mg/kg/dia 8/8h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Não recomendado'),
      cl('< 10 mL/min', 'Não recomendado'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '—', d8a28: '—' },
    },
    observacoes: ['mg/kg/dia referido à soma dos dois componentes.'],
  },
  {
    id: 'cefepime',
    nome: 'Cefepime',
    classe: 'Cefalosporina de 4ª geração',
    apresentacao: 'Frasco 1 g / 10 mL',
    diluicao: '40 mg de cefepime por 1 mL de SF 0,9%',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '50 mg/kg/dose 8/8h'),
      cl('> 50 mL/min', '50 mg/kg/dose 8/8h'),
      cl('10–50 mL/min', '50 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '50 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '30 mg/kg 12/12h', d8a28: '30 mg/kg 12/12h' },
      acima2kg: { ate7d: '30 mg/kg 12/12h', d8a28: '30 mg/kg 12/12h' },
    },
    pesoCalc: { valor: 50, base: 'dose', intervaloHoras: 8 },
  },
  {
    id: 'cefotaxima',
    nome: 'Cefotaxima',
    classe: 'Cefalosporina de 3ª geração',
    apresentacao: 'Frasco 1 g',
    diluicao: '40 mg de cefotaxima por 1 mL de SF 0,9%',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '50–75 mg/kg/dose 6/6h'),
      cl('> 50 mL/min', '50–75 mg/kg/dose 8/8h'),
      cl('10–50 mL/min', '50–75 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '50–75 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '50 mg/kg 12/12h', d8a28: '50 mg/kg 8/8h' },
      acima2kg: { ate7d: '50 mg/kg 12/12h', d8a28: '50 mg/kg 8/8h' },
    },
    pesoCalc: { valor: [50, 75], base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'cefuroxima',
    nome: 'Cefuroxima',
    classe: 'Cefalosporina de 2ª geração',
    apresentacao: 'Frasco 750 mg',
    diluicao: '30 mg de cefuroxima por 1 mL de SF 0,9%',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '50 mg/kg/dose 8/8h'),
      cl('> 20 mL/min', '50 mg/kg/dose 8/8h'),
      cl('10–20 mL/min', '50 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '50 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '50 mg/kg 12/12h', d8a28: '50 mg/kg 8/8h' },
      acima2kg: { ate7d: '50 mg/kg 12/12h', d8a28: '50 mg/kg 8/8h' },
    },
    pesoCalc: { valor: 50, base: 'dose', intervaloHoras: 8 },
  },
  {
    id: 'ceftazidima',
    nome: 'Ceftazidima',
    classe: 'Cefalosporina de 3ª geração (antipseudomonas)',
    apresentacao: 'Frasco 1 g / 10 mL',
    diluicao: '40 mg de ceftazidima por 1 mL de SF 0,9%',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '30–50 mg/kg/dose 8/8h'),
      cl('> 50 mL/min', '30–50 mg/kg/dose 8/8h'),
      cl('10–50 mL/min', '30–50 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '30–50 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '50 mg/kg 12/12h', d8a28: '50 mg/kg 8/8h' },
      acima2kg: { ate7d: '50 mg/kg 12/12h', d8a28: '50 mg/kg 8/8h' },
    },
    pesoCalc: { valor: [30, 50], base: 'dose', intervaloHoras: 8 },
  },
  {
    id: 'ceftriaxona',
    nome: 'Ceftriaxona',
    classe: 'Cefalosporina de 3ª geração',
    apresentacao: 'Frasco 1 g / 10 mL',
    diluicao: '40 mg de ceftriaxona por 1 mL de SF 0,9%',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '50 mg/kg/dose 12/12h'),
      cl('> 50 mL/min', '50 mg/kg/dose 12/12h'),
      cl('10–50 mL/min', '50 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '50 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '50 mg/kg 24/24h', d8a28: '50 mg/kg 24/24h' },
    },
    observacoes: [
      'Evitar no neonato ≤ 2 kg e no uso concomitante com soluções de cálcio ' +
        '(risco de precipitação) — daí as células neonatais em branco.',
    ],
    pesoCalc: { valor: 50, base: 'dose', intervaloHoras: 12 },
  },
  {
    id: 'ciprofloxacino',
    nome: 'Ciprofloxacino',
    classe: 'Fluoroquinolona',
    apresentacao: 'Bolsa 2 mg/mL',
    diluicao: 'Não necessita diluição',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '20 mg/kg/dose 12/12h ou 30–40 mg/kg/dia 8/8h'),
      cl('> 50 mL/min', '20 mg/kg/dose 12/12h'),
      cl('10–50 mL/min', '10–15 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '10 mg/kg/dose 12/12h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '—', d8a28: '—' },
    },
    pesoCalc: { valor: 20, base: 'dose', intervaloHoras: 12 },
  },
  {
    id: 'claritromicina',
    nome: 'Claritromicina',
    classe: 'Macrolídeo',
    apresentacao: 'Frasco 500 mg',
    diluicao: '2 a 10 mg de claritromicina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '7,5 mg/kg/dose 12/12h'),
      cl('> 60 mL/min', '7,5 mg/kg/dose 12/12h'),
      cl('30–60 mL/min', '3,75 mg/kg/dose 12/12h'),
      cl('< 30 mL/min', '1,85 mg/kg/dose 12/12h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '—', d8a28: '—' },
    },
    pesoCalc: { valor: 7.5, base: 'dose', intervaloHoras: 12 },
  },
  {
    id: 'clindamicina',
    nome: 'Clindamicina',
    classe: 'Lincosamida',
    apresentacao: 'Ampola 150 mg/mL',
    diluicao: '18 mg de clindamicina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '10 mg/kg/dose 6/6h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Sem ajuste'),
      cl('< 10 mL/min', 'Sem ajuste'),
    ],
    neonatal: {
      ate2kg: { ate7d: '5 mg/kg 12/12h', d8a28: '5 mg/kg 8/8h' },
      acima2kg: { ate7d: '5 mg/kg 8/8h', d8a28: '5 mg/kg 6/6h' },
    },
    observacoes: [
      'O protocolo empírico grafa 5–10 mg/kg/dose 6/6h. O extremo inferior ' +
        '(5 mg/kg/dose = 20 mg/kg/dia) fica abaixo da faixa usual de 25–40 mg/kg/dia; ' +
        'este quadro fixa 10 mg/kg/dose.',
    ],
    pesoCalc: { valor: 10, base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'daptomicina',
    nome: 'Daptomicina',
    classe: 'Lipopeptídeo',
    apresentacao: 'Frasco 500 mg',
    diluicao: '50 mg de daptomicina por 1 mL de SF 0,9%',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '4–8 mg/kg/dose 24/24h'),
      cl('> 50 mL/min', '4–8 mg/kg/dose 24/24h'),
      cl('10–50 mL/min', '4–6 mg/kg/dose 48/48h'),
      cl('< 10 mL/min', 'Não recomendado'),
    ],
    neonatal: {
      ate2kg: { ate7d: '6 mg/kg 12/12h', d8a28: '6 mg/kg 12/12h' },
      acima2kg: { ate7d: '6 mg/kg 12/12h', d8a28: '6 mg/kg 12/12h' },
    },
    observacoes: ['Não usar na pneumonia — inativada pelo surfactante pulmonar.'],
    pesoCalc: { valor: [4, 8], base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'eritromicina',
    nome: 'Eritromicina',
    classe: 'Macrolídeo',
    apresentacao: 'Frasco 1 g',
    diluicao: '5 mg de eritromicina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '12,5 mg/kg/dia 6/6h (conforme documento)'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Não recomendado'),
      cl('< 10 mL/min', 'Não recomendado'),
    ],
    neonatal: {
      ate2kg: { ate7d: '10 mg/kg 12/12h', d8a28: '10 mg/kg 8/8h' },
      acima2kg: { ate7d: '10 mg/kg 12/12h', d8a28: '10 mg/kg 8/8h' },
    },
    alerta:
      'O documento grafa "12,5 mg/kg/dia – 6/6h", incoerente (a dose usual é ' +
      '~10 mg/kg/dose, 40 mg/kg/dia). Provável erro de digitação — conferir com o ' +
      'SCIH antes de usar.',
  },
  {
    id: 'ertapenem',
    nome: 'Ertapenem',
    classe: 'Carbapenêmico',
    apresentacao: 'Frasco 1 g',
    diluicao: '20 mg de ertapenem por 1 mL de SF 0,9%',
    infusao: '60 min — na sepse, se possível, correr em 3 h',
    clearance: [
      cl('Clearance normal', '15 mg/kg/dose 12/12h'),
      cl('> 50 mL/min', '15 mg/kg/dose 12/12h'),
      cl('10–50 mL/min', '7,5 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '7,5 mg/kg/dose 12/12h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '—', d8a28: '—' },
    },
    pesoCalc: { valor: 15, base: 'dose', intervaloHoras: 12 },
  },
  {
    id: 'fluconazol',
    nome: 'Fluconazol',
    classe: 'Antifúngico triazólico',
    apresentacao: 'Bolsa 2 mg/mL',
    diluicao: 'Não necessita diluição',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '12 mg/kg/dose 24/24h'),
      cl('> 50 mL/min', '12 mg/kg/dose 24/24h'),
      cl('10–50 mL/min', '6 mg/kg/dose 24/24h'),
      cl('< 10 mL/min', '6 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '12 mg/kg 24/24h', d8a28: '12 mg/kg 24/24h' },
      acima2kg: { ate7d: '12 mg/kg 24/24h', d8a28: '12 mg/kg 24/24h' },
    },
    pesoCalc: { valor: 12, base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'gentamicina',
    nome: 'Gentamicina',
    classe: 'Aminoglicosídeo',
    apresentacao: 'Ampola 40 mg / 2 mL',
    diluicao: '1 a 10 mg (restrição hídrica) de gentamicina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '5 mg/kg/dose 24/24h'),
      cl('> 50 mL/min', '4 mg/kg/dose 24/24h'),
      cl('10–50 mL/min', '3 mg/kg/dose 24/24h'),
      cl('< 10 mL/min', '2 mg/kg/dose 72/72h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '5 mg/kg 48/48h', d8a28: '5 mg/kg 48/48h' },
      acima2kg: { ate7d: '4–5 mg/kg 24/24h', d8a28: '4–5 mg/kg 24/24h' },
    },
    observacoes: ['Usar peso ajustado. Monitorar função renal e níveis séricos.'],
    pesoCalc: { valor: 5, base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'imipenem',
    nome: 'Imipenem/cilastatina',
    classe: 'Carbapenêmico',
    apresentacao: 'Frasco 500 mg / 100 mL',
    diluicao: '7 mg de imipenem por 1 mL de SF 0,9%',
    infusao: '60 min — na sepse, se possível, correr em 3 h',
    clearance: [
      cl('Clearance normal', '20 mg/kg/dose 6/6h'),
      cl('> 50 mL/min', '12 mg/kg/dose 6/6h'),
      cl('10–50 mL/min', '12 mg/kg/dose 8/8h'),
      cl('< 10 mL/min', '12 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '20 mg 12/12h', d8a28: '25 mg 12/12h' },
      acima2kg: { ate7d: '25 mg 12/12h', d8a28: '25 mg 8/8h' },
    },
    observacoes: ['Grade neonatal em mg absolutos, como no documento — não é mg/kg.'],
    pesoCalc: { valor: 20, base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'levofloxacino',
    nome: 'Levofloxacino',
    classe: 'Fluoroquinolona',
    apresentacao: 'Bolsa 5 mg/mL',
    diluicao: 'Não necessita diluição',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '10 mg/kg/dose 24/24h'),
      cl('> 50 mL/min', '10 mg/kg/dose 24/24h'),
      cl('10–50 mL/min', '10 mg/kg/dose 48/48h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '—', d8a28: '—' },
    },
    pesoCalc: { valor: 10, base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'linezolida',
    nome: 'Linezolida',
    classe: 'Oxazolidinona',
    apresentacao: 'Bolsa 2 mg/mL',
    diluicao: 'Não necessita diluição',
    infusao: '30 min',
    clearance: [
      cl('Clearance normal', '10 mg/kg/dose 8/8h'),
      cl('> 50 mL/min', '10 mg/kg/dose 8/8h'),
      cl('10–50 mL/min', '10 mg/kg/dose 8/8h'),
      cl('< 10 mL/min', '10 mg/kg/dose 8/8h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '10 mg/kg 12/12h', d8a28: '10 mg/kg 8/8h' },
      acima2kg: { ate7d: '10 mg/kg 8/8h', d8a28: '10 mg/kg 8/8h' },
    },
    restrito:
      'Reservada para VRE (enterococo resistente à vancomicina) e casos ' +
      'selecionados de MRSA. Não liberar empiricamente — só com cultura.',
    pesoCalc: { valor: 10, base: 'dose', intervaloHoras: 8 },
  },
  {
    id: 'meropenem',
    nome: 'Meropenem',
    classe: 'Carbapenêmico',
    apresentacao: 'Frasco 500 mg / mL',
    diluicao: '20 mg de meropenem por 1 mL de SF 0,9%',
    infusao: '60 min — na sepse, se possível, correr em 3 h',
    clearance: [
      cl('Clearance normal', '20–40 mg/kg/dose 8/8h'),
      cl('> 50 mL/min', '20 mg/kg/dose 8/8h'),
      cl('26–50 mL/min', '20 mg/kg/dose 12/12h'),
      cl('10–25 mL/min', '10 mg/kg/dose 12/12h'),
      cl('< 10 mL/min', '10 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '20 mg/kg 12/12h', d8a28: '20 mg/kg 8/8h' },
      acima2kg: { ate7d: '20 mg/kg 8/8h', d8a28: '20 mg/kg 8/8h' },
    },
    observacoes: [
      'Antimicrobiano de uso restrito: preencher formulário e notificar o SCIH.',
      'O protocolo empírico prescreve 20 mg/kg/dose (extremo inferior desta faixa). ' +
        'Em meningite, Pseudomonas ou PAV grave, a literatura usa 40 mg/kg/dose — ' +
        'avaliar a gravidade antes de fixar em 20.',
    ],
    pesoCalc: { valor: [20, 40], base: 'dose', intervaloHoras: 8 },
  },
  {
    id: 'metronidazol',
    nome: 'Metronidazol',
    classe: 'Nitroimidazólico',
    apresentacao: 'Bolsa 500 mg / 100 mL',
    diluicao: '8 mg de metronidazol por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '15–30 mg/kg/dose 8/8h'),
      cl('> 50 mL/min', '15 mg/kg/dose 8/8h'),
      cl('10–50 mL/min', '15 mg/kg/dose 8/8h'),
      cl('< 10 mL/min', '7,5 mg/kg/dose 8/8h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '7,5 mg/kg 24/24h', d8a28: '15 mg/kg 24/24h' },
      acima2kg: { ate7d: '15 mg/kg 24/24h', d8a28: '15 mg/kg 12/12h' },
    },
    alerta:
      'DIVERGÊNCIA a resolver com o SCIH. Como está grafado (15–30 mg/kg/DOSE ' +
      '8/8h), a dose diária chega a 45–90 mg/kg/dia — acima da usual. O protocolo ' +
      'empírico prescreve 5–10 mg/kg/dose 6/6h (20–40 mg/kg/dia), que é a faixa ' +
      'consagrada. A leitura provável é que o quadro queira dizer 15–30 mg/kg/DIA ' +
      'dividido 8/8h, o que faria os dois documentos coincidirem. Confirmar antes ' +
      'de usar a dose deste quadro.',
    pesoCalc: { valor: [15, 30], base: 'dose', intervaloHoras: 8 },
  },
  {
    id: 'micafungina',
    nome: 'Micafungina',
    classe: 'Antifúngico equinocandina',
    apresentacao: 'Frasco 50 mg ou 100 mg',
    diluicao: '1 mg de micafungina por 1 mL de SF 0,9%',
    infusao: '120 min',
    clearance: [
      cl('Clearance normal', '2 mg/kg/dose 24/24h'),
      cl('> 50 mL/min', '2 mg/kg/dose 24/24h'),
      cl('10–50 mL/min', '2 mg/kg/dose 24/24h'),
      cl('< 10 mL/min', '2 mg/kg/dose 24/24h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '10 mg/kg 24/24h', d8a28: '10 mg/kg 24/24h' },
      acima2kg: { ate7d: '10 mg/kg 24/24h', d8a28: '10 mg/kg 24/24h' },
    },
    alerta:
      'A dose neonatal (10 mg/kg) é bem maior que a pediátrica (2 mg/kg) — coerente ' +
      'com a farmacocinética do neonato na candidíase do SNC, mas confirmar com o SCIH.',
    pesoCalc: { valor: 2, base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'oxacilina',
    nome: 'Oxacilina',
    classe: 'Penicilina penicilinase-resistente',
    apresentacao: 'Frasco 500 mg / 5 mL',
    diluicao: '10 mg de oxacilina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '12,5–25 mg/kg/dose 6/6h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Sem ajuste'),
      cl('< 10 mL/min', 'Sem ajuste'),
    ],
    neonatal: {
      ate2kg: { ate7d: '25 mg/kg 12/12h', d8a28: '25 mg/kg 8/8h' },
      acima2kg: { ate7d: '25 mg/kg 8/8h', d8a28: '25 mg/kg 6/6h' },
    },
    alerta:
      'Divergência de FAIXA, não erro: este quadro traz 12,5–25 mg/kg/dose 6/6h ' +
      '(50–100 mg/kg/dia), a faixa de infecção leve a moderada. O protocolo ' +
      'empírico prescreve 50 mg/kg/dose 6/6h (200 mg/kg/dia) — a dose de infecção ' +
      'GRAVE, coerente com os focos em que ele indica oxacilina (endocardite, ' +
      'pele com necrose, IPCS). Escolher pela gravidade, não pelo documento.',
    pesoCalc: { valor: [12.5, 25], base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'penicilina_cristalina',
    nome: 'Penicilina cristalina',
    sinonimos: ['Penicilina G', 'benzilpenicilina'],
    classe: 'Penicilina natural',
    apresentacao: 'Frasco 5.000.000 UI',
    diluicao: '50.000 UI de penicilina por 1 mL de SF 0,9%',
    infusao: '30–60 min',
    clearance: [
      cl('Clearance normal', '100.000–300.000 UI/kg/dia, 4/4h ou 6/6h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '50.000 UI 12/12h', d8a28: '50.000 UI 8/8h' },
      acima2kg: { ate7d: '50.000 UI 12/12h', d8a28: '50.000 UI 8/8h' },
    },
    observacoes: ['Dose em UI/kg — não convertida em mg pela calculadora.'],
  },
  {
    id: 'piperacilina_tazobactam',
    nome: 'Piperacilina/tazobactam',
    sinonimos: ['Tazocin'],
    classe: 'Penicilina de espectro estendido + inibidor de betalactamase',
    apresentacao: 'Frasco 4 g piperacilina + 0,5 g tazobactam',
    diluicao: '20 mg por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '75 mg/kg/dose 6/6h'),
      cl('> 50 mL/min', '75 mg/kg/dose 6/6h'),
      cl('10–50 mL/min', '37,5 mg/kg/dose 6/6h'),
      cl('< 10 mL/min', '37,5 mg/kg/dose 8/8h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '100 mg/kg 12/12h', d8a28: '100 mg/kg 8/8h' },
      acima2kg: { ate7d: '100 mg/kg 12/12h', d8a28: '100 mg/kg 8/8h' },
    },
    observacoes: ['mg/kg referido ao componente piperacilina (proporção 8:1).'],
    pesoCalc: { valor: 75, base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'polimixina_e',
    nome: 'Polimixina E (colistina)',
    sinonimos: ['colistina', 'colistimetato'],
    classe: 'Polimixina',
    apresentacao: 'Frasco 150 mg',
    diluicao: '3 mg de polimixina E por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '2,5–5 mg/kg/dia 8/8h'),
      cl('> 50 mL/min', '2,5–5 mg/kg/dia 8/8h'),
      cl('10–50 mL/min', '2,5–5 mg/kg/dia 24/24h'),
      cl('< 10 mL/min', '1,5 mg/kg/dia 48/48h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '2,5 mg/kg/dia 8/8h', d8a28: '5 mg/kg/dia 8/8h' },
      acima2kg: { ate7d: '2,5 mg/kg/dia 8/8h', d8a28: '5 mg/kg/dia 8/8h' },
    },
  },
  {
    id: 'quinupristina_dalfopristina',
    nome: 'Quinupristina/dalfopristina',
    sinonimos: ['Synercid'],
    classe: 'Estreptogramina',
    apresentacao: 'Frasco 150/350 mg',
    diluicao: 'Diluir em SG 5%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '7,5 mg/kg/dose 8/8h'),
      cl('> 50 mL/min', 'Sem ajuste'),
      cl('10–50 mL/min', 'Sem ajuste'),
      cl('< 10 mL/min', 'Sem ajuste'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '—', d8a28: '—' },
    },
    pesoCalc: { valor: 7.5, base: 'dose', intervaloHoras: 8 },
  },
  {
    id: 'teicoplanina',
    nome: 'Teicoplanina',
    classe: 'Glicopeptídeo',
    apresentacao: 'Frasco 400 mg',
    diluicao: '16 mg de teicoplanina por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '6 mg/kg/dose 24/24h'),
      cl('> 50 mL/min', '6 mg/kg/dose 24/24h'),
      cl('10–50 mL/min', '6 mg/kg/dose 48/48h'),
      cl('< 10 mL/min', '6 mg/kg/dose 72/72h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '6 mg/kg 24/24h', d8a28: '6 mg/kg 24/24h' },
      acima2kg: { ate7d: '6 mg/kg 24/24h', d8a28: '6 mg/kg 24/24h' },
    },
    pesoCalc: { valor: 6, base: 'dose', intervaloHoras: 24 },
  },
  {
    id: 'tigeciclina',
    nome: 'Tigeciclina',
    classe: 'Glicilciclina',
    apresentacao: 'Frasco 50 mg',
    diluicao: '50 mg de tigeciclina por 100 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', 'Ataque 100 mg/1,73 m²; manutenção 50 mg/1,73 m² 12/12h'),
      cl('Todas as faixas', 'Ataque 100 mg/1,73 m²; manutenção 50 mg/1,73 m² 12/12h'),
    ],
    neonatal: {
      ate2kg: { ate7d: '—', d8a28: '—' },
      acima2kg: { ate7d: '—', d8a28: '—' },
    },
    observacoes: ['Dose por superfície corporal — não convertida por peso.'],
  },
  {
    id: 'vancomicina',
    nome: 'Vancomicina',
    classe: 'Glicopeptídeo',
    apresentacao: 'Frasco 500 mg / 10 mL',
    diluicao: '5 mg de vancomicina por 1 mL de SF 0,9%',
    infusao: '60 min (manutenção em 2 h)',
    clearance: [
      cl('Clearance normal', '10–15 mg/kg/dose 6/6h'),
      cl('10–50 mL/min', '15 mg/kg/dose 24/24h'),
      cl('< 10 mL/min', '7,5 mg/kg/dose 48/48h ou 72/72h'),
    ],
    neonatalNota:
      'No neonato a dose é definida pela CREATININA sérica, não pelo clearance — ' +
      'ver a tabela completa e a correção por vancocinemia na ficha de Vancomicina.',
    observacoes: [
      'Correção por vancocinemia e relação com albumina: ver a ficha de Vancomicina.',
    ],
    pesoCalc: { valor: [10, 15], base: 'dose', intervaloHoras: 6 },
  },
  {
    id: 'voriconazol',
    nome: 'Voriconazol',
    classe: 'Antifúngico triazólico',
    apresentacao: 'Frasco 200 mg',
    diluicao: '9 mg de voriconazol por 1 mL de SF 0,9%',
    infusao: '60 min',
    clearance: [
      cl('Clearance normal', '6 mg/kg/dose 12/12h nas primeiras 48 h; depois 4 mg/kg/dose 12/12h'),
      cl('> 50 mL/min', '6 mg/kg/dose 12/12h nas primeiras 48 h; depois 4 mg/kg/dose 12/12h'),
      cl('10–50 mL/min', 'Não usar EV (veículo se acumula) — usar VO'),
      cl('< 10 mL/min', 'Não usar EV — usar VO'),
    ],
    neonatal: {
      ate2kg: { ate7d: '8 mg/kg 12/12h', d8a28: '8 mg/kg 12/12h' },
      acima2kg: { ate7d: '8 mg/kg 12/12h', d8a28: '8 mg/kg 12/12h' },
    },
    restrito:
      'Reservado para aspergilose e fungos filamentosos documentados. Não liberar ' +
      'empiricamente — só com identificação.',
  },
]

/** Acesso por id, para as fichas que referenciam uma droga específica. */
export function findDosePediatrica(id: string): DosePediatrica | undefined {
  return DOSES_PEDIATRICAS.find((d) => d.id === id)
}
