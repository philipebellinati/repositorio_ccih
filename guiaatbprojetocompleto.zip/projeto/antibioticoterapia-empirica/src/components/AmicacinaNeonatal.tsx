import { useState } from 'react'
import { AMICACINA_NEONATAL, doseAmicacinaNeonatal } from '@/data/amicacina-neonatal'
import { formatarNumero } from '@/domain/dosing'
import { Callout } from './ui/primitives'
import { cn } from '@/lib/utils'

/**
 * Calculadora de amicacina no período neonatal.
 *
 * A tabela do protocolo empírico traz "5-7 mg/kg até 8/8h" para o recém-nascido,
 * o que não discrimina maturidade renal. O esquema correto depende de idade
 * gestacional e pós-natal, e usa doses maiores em intervalos mais longos — daí
 * a calculadora existir em vez de um número fixo na linha da tabela.
 */
export function AmicacinaNeonatal() {
  const [ig, setIg] = useState<number | undefined>(undefined)
  const [idadeDias, setIdadeDias] = useState<number | undefined>(undefined)
  const [peso, setPeso] = useState<number | undefined>(undefined)

  const completo = ig !== undefined && idadeDias !== undefined
  const resultado = completo ? doseAmicacinaNeonatal(ig, idadeDias, peso) : undefined

  return (
    <div className="space-y-4 px-4 py-4">
      <div className="grid grid-cols-3 gap-3">
        {(
          [
            { rotulo: 'Idade gestacional', valor: ig, set: setIg, sufixo: 'sem', step: '1', ph: '32' },
            { rotulo: 'Idade de vida', valor: idadeDias, set: setIdadeDias, sufixo: 'dias', step: '1', ph: '5' },
            { rotulo: 'Peso', valor: peso, set: setPeso, sufixo: 'kg', step: '0.01', ph: '1,8' },
          ] as const
        ).map((c) => (
          <label key={c.rotulo} className="block">
            <span className="kicker">{c.rotulo}</span>
            <div className="mt-1 flex items-center gap-1.5">
              <input
                type="number"
                inputMode="decimal"
                step={c.step}
                value={c.valor ?? ''}
                placeholder={c.ph}
                onChange={(e) => c.set(e.target.value === '' ? undefined : Number(e.target.value))}
                aria-label={c.rotulo}
                className="w-full rounded-md border border-border bg-input px-2.5 py-2 text-base font-semibold text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-ring"
              />
              <span className="shrink-0 text-xs text-muted-foreground">{c.sufixo}</span>
            </div>
          </label>
        ))}
      </div>

      {completo && !resultado && (
        <Callout severidade="atencao" titulo="Idade gestacional fora das faixas">
          A tabela cobre as faixas abaixo. Confira o valor informado ou acione a
          Infectologia Pediátrica.
        </Callout>
      )}

      {resultado && (
        <div className="rounded-md border border-primary/40 bg-primary/10 p-4">
          <p className="kicker">
            {resultado.faixa.ig} · {resultado.periodo === 'ate7' ? '0 a 7 dias' : '> 7 dias'} de vida
          </p>
          <p className="mt-1 text-2xl font-bold tabular-nums text-primary">
            {formatarNumero(resultado.mgPorKg)} mg/kg/dose{' '}
            <span className="text-base font-normal text-muted-foreground">
              a cada {resultado.intervaloH} h
            </span>
          </p>
          {resultado.doseMg !== undefined && (
            <p className="mt-1 text-lg font-semibold text-foreground">
              = {formatarNumero(resultado.doseMg)} mg por dose
              <span className="ml-2 text-xs font-normal text-muted-foreground">
                {formatarNumero(resultado.mgPorKg)} mg/kg × {formatarNumero(peso!)} kg
              </span>
            </p>
          )}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full min-w-[420px] border-collapse text-sm">
          <caption className="sr-only">Amicacina neonatal por idade gestacional</caption>
          <thead>
            <tr className="border-b border-border text-left">
              <th scope="col" className="kicker pb-2 pr-3">Idade gestacional</th>
              <th scope="col" className="kicker pb-2 pr-3">0 a 7 dias</th>
              <th scope="col" className="kicker pb-2">&gt; 7 dias</th>
            </tr>
          </thead>
          <tbody>
            {AMICACINA_NEONATAL.map((f) => (
              <tr
                key={f.ig}
                className={cn(
                  'border-b border-border/60',
                  resultado?.faixa.ig === f.ig && 'bg-primary/15',
                )}
              >
                <td className="py-2 pr-3 font-semibold text-foreground">{f.ig}</td>
                <td className="py-2 pr-3 text-foreground/85">
                  {f.ate7Dias.mgPorKg} mg/kg · {f.ate7Dias.intervaloH}/{f.ate7Dias.intervaloH}h
                </td>
                <td className="py-2 text-foreground/85">
                  {f.apos7Dias.mgPorKg} mg/kg · {f.apos7Dias.intervaloH}/{f.apos7Dias.intervaloH}h
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Callout severidade="critico" titulo="Estes valores substituem a tabela 6.6">
        A tabela do protocolo empírico grafa “Amicacina 5–7 mg/kg até 8/8h” para o
        recém-nascido. No neonato a depuração depende da maturidade renal: as doses
        corretas são maiores e os intervalos, mais longos. Vale a tabela acima.
      </Callout>
    </div>
  )
}
