import { ChevronDown } from 'lucide-react'
import type { Bloco, GuideCard } from '@/data/cards'
import { BlockHeader, Callout, NumberedRow, Panel } from './ui/primitives'
import { MarkedText } from './MarkedText'
import { TabelaSecao } from './TabelaSecao'
import { Calculadora } from './Calculadora'
import { Cronometro } from './Cronometro'
import { FluxoEtapas } from './FluxoEtapas'
import { CalculadoraRenal } from './CalculadoraRenal'
import { FichaVancomicina } from './FichaVancomicina'
import { AmicacinaNeonatal } from './AmicacinaNeonatal'
import { PesoAminoglicosideo } from './PesoAminoglicosideo'
import { DosesPediatricas } from './DosesPediatricas'
import { TabelaRestritos } from './TabelaRestritos'
import { AlternativasAlergiaFocos } from './AlternativasAlergiaFocos'
import { cn } from '@/lib/utils'

/**
 * Ficha do guia, em acordeão — mesma anatomia da referência: número da ficha em
 * mono discreto à esquerda, título em azul caixa-alta, subtítulo em cinza e
 * chevron de recolher à direita.
 */
export function GuideCardView({
  card,
  aberta,
  onToggle,
  pesoKg,
  onPesoChange,
  regrasCasadas,
  modoAlergia,
  onAbrirFicha,
  vancoPopulacao,
}: {
  card: GuideCard
  aberta: boolean
  onToggle: () => void
  pesoKg: number | undefined
  onPesoChange: (peso: number | undefined) => void
  regrasCasadas: Set<string>
  modoAlergia: boolean
  onAbrirFicha: (id: string, vancoPopulacao?: 'adulto' | 'neoped') => void
  vancoPopulacao?: 'adulto' | 'neoped'
}) {
  const painelId = `card-painel-${card.id}`

  return (
    <Panel id={`ficha-${card.id}`} className="overflow-hidden">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={aberta}
        aria-controls={painelId}
        className="flex w-full items-center gap-3 px-4 py-4 text-left transition-colors hover:bg-secondary/40"
      >
        <span className="shrink-0 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
          Card {String(card.numero).padStart(2, '0')}
        </span>

        <span className="min-w-0 flex-1">
          <span className="block text-base font-bold uppercase leading-tight tracking-wide text-primary">
            {card.titulo}
          </span>
          <span className="mt-0.5 block text-xs leading-snug text-muted-foreground">
            {card.subtitulo}
          </span>
        </span>

        <ChevronDown
          aria-hidden
          className={cn(
            'h-5 w-5 shrink-0 text-muted-foreground transition-transform',
            aberta && 'rotate-180',
          )}
        />
      </button>

      {aberta && (
        <div id={painelId} className="animate-fade-in border-t border-border">
          {card.blocos.map((bloco, i) => (
            <BlocoView
              key={i}
              bloco={bloco}
              pesoKg={pesoKg}
              onPesoChange={onPesoChange}
              regrasCasadas={regrasCasadas}
              modoAlergia={modoAlergia}
              onAbrirFicha={onAbrirFicha}
              vancoPopulacao={vancoPopulacao}
            />
          ))}
        </div>
      )}
    </Panel>
  )
}

function BlocoView({
  bloco,
  pesoKg,
  onPesoChange,
  regrasCasadas,
  modoAlergia,
  onAbrirFicha,
  vancoPopulacao,
}: {
  bloco: Bloco
  pesoKg: number | undefined
  onPesoChange: (peso: number | undefined) => void
  regrasCasadas: Set<string>
  modoAlergia: boolean
  onAbrirFicha: (id: string, vancoPopulacao?: 'adulto' | 'neoped') => void
  vancoPopulacao?: 'adulto' | 'neoped'
}) {
  switch (bloco.tipo) {
    case 'regras':
      return (
        <div className="p-4">
          <div className="overflow-hidden rounded-md border border-border">
            <BlockHeader>{bloco.titulo}</BlockHeader>
            <div className="bg-secondary/30">
              {bloco.itens.map((item) => (
                <NumberedRow key={item.n} numero={item.n} titulo={item.titulo}>
                  <MarkedText texto={item.texto} />
                </NumberedRow>
              ))}
            </div>
          </div>
        </div>
      )

    case 'tabela':
      return (
        <div className="p-4">
          <div className="overflow-hidden rounded-md border border-border">
            <BlockHeader>{bloco.titulo}</BlockHeader>
            <div className="bg-secondary/20">
              <TabelaSecao
                secaoId={bloco.secaoId}
                {...(pesoKg !== undefined ? { pesoKg } : {})}
                regrasCasadas={regrasCasadas}
                modoAlergia={modoAlergia}
                onAbrirFicha={onAbrirFicha}
              />
            </div>
          </div>
        </div>
      )

    case 'lista':
      return (
        <div className="px-4 py-3">
          {bloco.titulo && <p className="kicker mb-2">{bloco.titulo}</p>}
          <ul className="space-y-1.5">
            {bloco.itens.map((item, i) => (
              <li key={i} className="flex gap-2 text-sm leading-relaxed text-foreground/90">
                <span aria-hidden className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-primary" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      )

    case 'definicoes':
      return (
        <div className="px-4 py-3">
          <p className="kicker mb-2">{bloco.titulo}</p>
          <dl className="space-y-2">
            {bloco.itens.map((item) => (
              <div key={item.termo} className="text-sm leading-relaxed">
                <dt className="inline font-bold text-primary">{item.termo}</dt>
                <dd className="inline text-foreground/90"> — {item.def}</dd>
              </div>
            ))}
          </dl>
        </div>
      )

    case 'alerta':
      return (
        <div className="px-4 py-3">
          <Callout
            severidade={bloco.severidade}
            titulo={bloco.titulo}
            {...(bloco.fonte ? { fonte: bloco.fonte } : {})}
          >
            {bloco.texto}
          </Callout>
        </div>
      )

    case 'calculadora':
      return <Calculadora pesoKg={pesoKg} onPesoChange={onPesoChange} />

    case 'cronometro':
      return <Cronometro />

    case 'fluxo':
      return <FluxoEtapas />

    case 'renal':
      return <CalculadoraRenal />

    case 'vancomicina':
      return <FichaVancomicina populacaoInicial={vancoPopulacao} />

    case 'amicacina-neonatal':
      return <AmicacinaNeonatal />

    case 'peso-aminoglicosideo':
      return <PesoAminoglicosideo />

    case 'doses-pediatricas':
      return <DosesPediatricas pesoKg={pesoKg} />

    case 'restritos':
      return <TabelaRestritos />

    case 'alergia-focos':
      return <AlternativasAlergiaFocos />

    default:
      return null
  }
}
