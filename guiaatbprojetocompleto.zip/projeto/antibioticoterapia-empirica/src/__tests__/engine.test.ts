import { describe, expect, it } from 'vitest'
import {
  executarProtocolo,
  executarProtocoloSeguro,
  resolverSecao,
  selecionarRegra,
  focosDaSecao,
} from '@/domain/engine'
import { ProtocolError } from '@/domain/errors'
import { calcularDose, DOSES_POR_DIA } from '@/domain/dosing'
import { DRUGS, REGRAS_POR_SECAO, TODAS_AS_REGRAS, FOCOS } from '@/data'
import { formatarRegime } from '@/domain/format'
import type { ClinicalInput, Modificadores } from '@/domain/types'

/**
 * Suite de verificação do motor.
 *
 * O objetivo não é cobrir linhas de código, e sim provar que cada célula das
 * tabelas 6.1–6.6 do protocolo é alcançável e devolve exatamente o esquema
 * impresso no documento. Um erro aqui é um erro de prescrição.
 */

function entrada(over: Partial<ClinicalInput> = {}): ClinicalInput {
  return {
    populacao: 'adulto',
    origem: 'comunitaria',
    setor: 'ps',
    focoId: 'pneumonia',
    modificadores: {},
    ...over,
  }
}

/** Nomes dos fármacos do esquema principal, em ordem. */
function farmacos(input: ClinicalInput): string[] {
  return executarProtocolo(input).recomendacao.prescricoes.map((p) => p.drug.nome)
}

/** Nomes dos fármacos marcados como associação facultativa. */
function facultativos(input: ClinicalInput): string[] {
  return executarProtocolo(input).recomendacao.facultativos.map((p) => p.drug.nome)
}

// ---------------------------------------------------------------------------
describe('roteamento de seções', () => {
  it('adulto + comunitária → 6.1, independentemente do setor', () => {
    for (const setor of ['ps', 'enfermaria', 'uti', 'uco'] as const) {
      expect(resolverSecao(entrada({ setor })).id).toBe('6.1')
    }
  })

  it('adulto + IRAS separa enfermaria (6.2) de UTI (6.5)', () => {
    expect(resolverSecao(entrada({ origem: 'iras', setor: 'enfermaria' })).id).toBe('6.2')
    // Definição do SCIH: a UCO segue a tabela de UTI adulto.
    expect(resolverSecao(entrada({ origem: 'iras', setor: 'uco' })).id).toBe('6.5')
    expect(resolverSecao(entrada({ origem: 'iras', setor: 'uti' })).id).toBe('6.5')
  })

  it('pediatria roteia para 6.3, 6.4 e 6.6', () => {
    const ped = { populacao: 'pediatrico' as const, pesoKg: 15 }
    expect(resolverSecao(entrada({ ...ped })).id).toBe('6.3')
    expect(resolverSecao(entrada({ ...ped, origem: 'iras', setor: 'enfermaria' })).id).toBe('6.4')
    expect(resolverSecao(entrada({ ...ped, origem: 'iras', setor: 'uti' })).id).toBe('6.6')
  })

  it('neonato em UTI/UCI roteia para 6.6', () => {
    const neo = { populacao: 'neonatal' as const, pesoKg: 3, origem: 'iras' as const }
    expect(resolverSecao(entrada({ ...neo, setor: 'uti' })).id).toBe('6.6')
    expect(resolverSecao(entrada({ ...neo, setor: 'uci_neonatal' })).id).toBe('6.6')
  })

  it('recusa infecção comunitária em neonato — cenário ausente do protocolo', () => {
    const r = executarProtocoloSeguro(
      entrada({ populacao: 'neonatal', pesoKg: 3, origem: 'comunitaria', setor: 'ps' }),
    )
    expect(r.ok).toBe(false)
    if (!r.ok) {
      expect(r.error.code).toBe('SECAO_NAO_APLICAVEL')
      expect(r.error.orientacao).toContain('Infectologia Pediátrica')
    }
  })

  it('recusa IRAS neonatal fora da UTI/UCI', () => {
    const r = executarProtocoloSeguro(
      entrada({ populacao: 'neonatal', pesoKg: 3, origem: 'iras', setor: 'enfermaria' }),
    )
    expect(r.ok).toBe(false)
    if (!r.ok) expect(r.error.code).toBe('SECAO_NAO_APLICAVEL')
  })
})

// ---------------------------------------------------------------------------
describe('6.1 — comunitária, adulto', () => {
  const base = entrada()

  it('pneumonia 1ª opção: Ceftriaxona com Azitromicina facultativa', () => {
    expect(farmacos(base)).toEqual(['Ceftriaxona'])
    expect(facultativos(base)).toEqual(['Azitromicina'])
  })

  it('pneumonia com ATB prévio escalona para Cefepime', () => {
    expect(farmacos(entrada({ modificadores: { atbPrevio: true } }))).toEqual(['Cefepime'])
  })

  it('pneumonia aspirativa prevalece sobre ATB prévio', () => {
    const r = entrada({ modificadores: { aspirativa: true, atbPrevio: true } })
    expect(farmacos(r)).toEqual(['Clindamicina', 'Ceftriaxona'])
  })

  it('ITU: cada um dos três fatores agravantes leva a piperacilina/tazobactam', () => {
    const fatores: (keyof Modificadores)[] = ['atbPrevio', 'litiaseRenal', 'ituRecorrente']
    for (const f of fatores) {
      const r = entrada({ focoId: 'itu', modificadores: { [f]: true } })
      expect(farmacos(r), `fator ${f}`).toEqual(['Piperacilina/tazobactam'])
    }
    expect(farmacos(entrada({ focoId: 'itu' }))).toEqual(['Ceftriaxona'])
  })

  it('abdominal: 1ª e 2ª opção', () => {
    expect(farmacos(entrada({ focoId: 'abdominal' }))).toEqual(['Ceftriaxona', 'Metronidazol'])
    expect(
      farmacos(entrada({ focoId: 'abdominal', modificadores: { segundaOpcao: true } })),
    ).toEqual(['Ciprofloxacino', 'Metronidazol'])
  })

  it('pele e partes moles: necrose troca Oxacilina por Ceftriaxona + Clindamicina', () => {
    expect(farmacos(entrada({ focoId: 'pele_partes_moles' }))).toEqual(['Oxacilina'])
    expect(
      farmacos(entrada({ focoId: 'pele_partes_moles', modificadores: { necrose: true } })),
    ).toEqual(['Ceftriaxona', 'Clindamicina'])
  })

  it('sepse sem foco usa Ceftriaxona 12/12h — dobro da dose diária da ITU', () => {
    const r = executarProtocolo(entrada({ focoId: 'sepse_sem_foco' }))
    const p = r.recomendacao.prescricoes[0]
    expect(p?.drug.nome).toBe('Ceftriaxona')
    expect(p?.intervaloTexto).toBe('12/12h')
    expect(p?.doseDiariaMg).toBe(4000)
  })

  it('endocardite associa três fármacos, um deles ponderal', () => {
    expect(farmacos(entrada({ focoId: 'endocardite' }))).toEqual([
      'Ceftriaxona',
      'Oxacilina',
      'Gentamicina',
    ])
  })

  it('endocardite sem peso: exibe a Gentamicina em mg/kg e avisa, sem recusar o esquema', () => {
    // Regressão: a Gentamicina 5-7 mg/kg torna a endocardite do ADULTO
    // dependente de peso. Faltando o peso, o esquema deve continuar utilizável.
    const r = executarProtocolo(entrada({ focoId: 'endocardite' }))
    const genta = r.recomendacao.prescricoes.find((p) => p.drug.id === 'gentamicina')

    expect(genta?.doseTexto).toBe('1 mg/kg/dose')
    expect(genta?.doseCalculadaMg).toBeUndefined()
    expect(genta?.alertas.some((a) => a.titulo === 'Dose depende do peso')).toBe(true)

    // As demais doses do mesmo esquema permanecem calculadas.
    const ceftriaxona = r.recomendacao.prescricoes.find((p) => p.drug.id === 'ceftriaxona')
    expect(ceftriaxona?.doseCalculadaMg).toBe(2000)
  })

  it('endocardite com peso informado calcula a Gentamicina de sinergismo', () => {
    // 1 mg/kg/dose 8/8h em 70 kg → 70 mg por dose, 210 mg/dia.
    const r = executarProtocolo(entrada({ focoId: 'endocardite', pesoKg: 70 }))
    const genta = r.recomendacao.prescricoes.find((p) => p.drug.id === 'gentamicina')
    expect(genta?.doseCalculadaMg).toBe(70)
    expect(genta?.doseDiariaMg).toBe(210)
    expect(genta?.intervaloTexto).toBe('8/8h')
    expect(genta?.alertas.some((a) => a.titulo === 'Dose depende do peso')).toBe(false)
  })

  it('osteoarticular: Ciprofloxacino + Clindamicina 8/8h', () => {
    const r = executarProtocolo(entrada({ focoId: 'osteoarticular' }))
    expect(r.recomendacao.prescricoes.map((p) => p.intervaloTexto)).toEqual(['12/12h', '8/8h'])
  })
})

// ---------------------------------------------------------------------------
describe('6.1/6.3 — meningite e as notas ² e ⁴', () => {
  it('adulto sem critério: Vancomicina permanece facultativa e o app avisa', () => {
    const input = entrada({ focoId: 'meningite' })
    // A Dexametasona é adjuvante fixo do esquema; a Vancomicina é que é "+/-".
    expect(farmacos(input)).toEqual(['Ceftriaxona', 'Dexametasona'])
    expect(facultativos(input)).toEqual(['Vancomicina'])

    const alertas = executarProtocolo(input).recomendacao.alertas
    expect(alertas.some((a) => a.titulo.includes('nota ²'))).toBe(true)
  })

  it('adulto com critério da nota ² gera alerta crítico', () => {
    const input = entrada({
      focoId: 'meningite',
      modificadores: { betalactamico3Meses: true },
    })
    const alertas = executarProtocolo(input).recomendacao.alertas
    const critico = alertas.find((a) => a.severidade === 'critico' && a.fonte?.includes('²'))
    expect(critico).toBeDefined()
    expect(critico?.detalhe).toContain('betalactâmico')
  })

  it('pediatria: a nota ⁴ promove a Vancomicina a parte do esquema inicial', () => {
    const input = entrada({ populacao: 'pediatrico', pesoKg: 12, focoId: 'meningite' })
    expect(farmacos(input)).toEqual(['Ceftriaxona', 'Vancomicina', 'Dexametasona'])
    expect(facultativos(input)).toEqual([])

    const alertas = executarProtocolo(input).recomendacao.alertas
    expect(alertas.some((a) => a.fonte?.includes('⁴'))).toBe(true)
  })
})

// ---------------------------------------------------------------------------
describe('6.5 — UTI adulto, ramificação por ventilação mecânica', () => {
  const uti = { origem: 'iras' as const, setor: 'uti' as const, focoId: 'pnm_vm' }

  it('sem VM → Cefepime 1-2 g', () => {
    expect(farmacos(entrada({ ...uti }))).toEqual(['Cefepime'])
  })

  it('sem VM + aspirativa → piperacilina/tazobactam 8/8h', () => {
    const r = executarProtocolo(entrada({ ...uti, modificadores: { aspirativa: true } }))
    expect(r.recomendacao.prescricoes[0]?.drug.nome).toBe('Piperacilina/tazobactam')
    expect(r.recomendacao.prescricoes[0]?.intervaloTexto).toBe('8/8h')
  })

  it('PAV precoce (< 5 dias) → Cefepime; tardia (≥ 5) → Meropenem', () => {
    // Definição do SCIH: o 5º dia é TARDIA, não precoce.
    for (const dias of [1, 3, 4]) {
      expect(
        farmacos(entrada({ ...uti, modificadores: { diasVentilacaoMecanica: dias } })),
        `${dias} dias`,
      ).toEqual(['Cefepime'])
    }
    for (const dias of [5, 6, 10]) {
      expect(
        farmacos(entrada({ ...uti, modificadores: { diasVentilacaoMecanica: dias } })),
        `${dias} dias`,
      ).toEqual(['Meropenem'])
    }
  })

  it('PAV precoce aspirativa usa intervalo 6/6h, não 8/8h', () => {
    const r = executarProtocolo(
      entrada({ ...uti, modificadores: { diasVentilacaoMecanica: 2, aspirativa: true } }),
    )
    expect(r.recomendacao.prescricoes[0]?.intervaloTexto).toBe('6/6h')
  })

  it('PAV tardia ignora "aspirativa" — o protocolo não prevê essa combinação', () => {
    expect(
      farmacos(
        entrada({ ...uti, modificadores: { diasVentilacaoMecanica: 9, aspirativa: true } }),
      ),
    ).toEqual(['Meropenem'])
  })

  it('dispositivo invasivo escalona ITU e adiciona Vancomicina à IPCS', () => {
    const comDisp = { dispositivoInvasivo: true }
    expect(
      farmacos(entrada({ origem: 'iras', setor: 'uti', focoId: 'itu', modificadores: comDisp })),
    ).toEqual(['Meropenem'])
    expect(
      farmacos(entrada({ origem: 'iras', setor: 'uti', focoId: 'ipcs', modificadores: comDisp })),
    ).toEqual(['Vancomicina', 'Cefepime'])
    expect(farmacos(entrada({ origem: 'iras', setor: 'uti', focoId: 'ipcs' }))).toEqual([
      'Cefepime',
    ])
  })

  it('sepse com suspeita de Enterococcus troca o esquema inteiro', () => {
    const r = entrada({ origem: 'iras', setor: 'uti', focoId: 'sepse_sem_foco' })
    expect(farmacos(r)).toEqual(['Cefepime', 'Vancomicina'])
    expect(
      farmacos({ ...r, modificadores: { suspeitaEnterococcusAnaerobio: true } }),
    ).toEqual(['Piperacilina/tazobactam'])
  })

  it('Meropenem dispara alerta de antimicrobiano restrito', () => {
    const r = executarProtocolo(
      entrada({ ...uti, modificadores: { diasVentilacaoMecanica: 8 } }),
    )
    expect(r.recomendacao.alertas.some((a) => a.titulo.includes('restrito'))).toBe(true)
  })
})

// ---------------------------------------------------------------------------
describe('6.6 — UTI neonatal e pediátrica', () => {
  const neo = {
    populacao: 'neonatal' as const,
    origem: 'iras' as const,
    setor: 'uti' as const,
    pesoKg: 3,
  }
  const ped = {
    populacao: 'pediatrico' as const,
    origem: 'iras' as const,
    setor: 'uti' as const,
    pesoKg: 18,
  }

  it('IPCS sem dispositivo: Oxacilina no neonato, Cefepime acima de 28 dias', () => {
    expect(farmacos(entrada({ ...neo, focoId: 'ipcs' }))).toEqual(['Oxacilina'])
    expect(farmacos(entrada({ ...ped, focoId: 'ipcs' }))).toEqual(['Cefepime'])
  })

  it('IPCS com cateter: Amicacina no neonato, Cefepime acima de 28 dias', () => {
    const m = { dispositivoInvasivo: true }
    expect(farmacos(entrada({ ...neo, focoId: 'ipcs', modificadores: m }))).toEqual([
      'Vancomicina',
      'Amicacina',
    ])
    expect(farmacos(entrada({ ...ped, focoId: 'ipcs', modificadores: m }))).toEqual([
      'Vancomicina',
      'Cefepime',
    ])
  })

  it('sepse neonatal precoce: Ampicilina + Gentamicina, sem variante de ISC', () => {
    expect(
      farmacos(entrada({ ...neo, focoId: 'sepse_sem_foco', modificadores: { sepseNeonatal: 'precoce' } })),
    ).toEqual(['Ampicilina', 'Gentamicina'])
  })

  it('sepse neonatal tardia: Vancomicina + Amicacina, sem variante de ISC', () => {
    expect(
      farmacos(entrada({ ...neo, focoId: 'sepse_sem_foco', modificadores: { sepseNeonatal: 'tardia' } })),
    ).toEqual(['Vancomicina', 'Amicacina'])
  })

  it('sepse pediátrica: 1ª e 2ª opção', () => {
    expect(farmacos(entrada({ ...ped, focoId: 'sepse_sem_foco' }))).toEqual([
      'Vancomicina',
      'Cefepime',
    ])
    expect(
      farmacos(entrada({ ...ped, focoId: 'sepse_sem_foco', modificadores: { segundaOpcao: true } })),
    ).toEqual(['Vancomicina', 'Piperacilina/tazobactam'])
  })

  it('PAV pediátrica vai direto a Meropenem, sem distinção precoce/tardia', () => {
    for (const dias of [1, 9]) {
      expect(
        farmacos(entrada({ ...ped, focoId: 'pnm_vm', modificadores: { diasVentilacaoMecanica: dias } })),
      ).toEqual(['Meropenem', 'Vancomicina'])
    }
    expect(farmacos(entrada({ ...ped, focoId: 'pnm_vm' }))).toEqual(['Cefepime', 'Vancomicina'])
  })
})

// ---------------------------------------------------------------------------
describe('cálculo de dose', () => {
  it('mg/kg/dose multiplica pelo peso e a dose diária pelo número de tomadas', () => {
    // Ceftriaxona pediátrica: 50 mg/kg/dose 12/12h em 14 kg → 700 mg/dose, 1400 mg/dia.
    const r = executarProtocolo(
      entrada({ populacao: 'pediatrico', pesoKg: 14, focoId: 'itu' }),
    )
    const p = r.recomendacao.prescricoes[0]
    expect(p?.doseCalculadaMg).toBe(700)
    expect(p?.doseDiariaMg).toBe(1400)
  })

  it('mg/kg/dia divide pelo número de tomadas para achar a dose unitária', () => {
    const gentamicina = DRUGS.gentamicina
    expect(gentamicina).toBeDefined()
    const calc = calcularDose(
      {
        drugId: 'gentamicina',
        dosePonderal: { valor: [5, 7], unidade: 'mg/kg', base: 'dia' },
        via: 'EV',
        intervalo: 'q24h',
      },
      gentamicina!,
      10,
    )
    // 5–7 mg/kg/dia × 10 kg = 50–70 mg/dia, em tomada única.
    expect(calc?.porDia).toEqual([50, 70])
    expect(calc?.porDose).toEqual([50, 70])
  })

  it('faixas de dose são preservadas nos dois extremos', () => {
    const r = executarProtocolo(
      entrada({ populacao: 'pediatrico', pesoKg: 20, focoId: 'abdominal' }),
    )
    // Metronidazol 7,5-10 mg/kg/dose × 20 kg → 150–200 mg.
    const metro = r.recomendacao.prescricoes.find((p) => p.drug.id === 'metronidazol')
    expect(metro?.doseCalculadaMg).toEqual([150, 200])
  })

  it('dose fixa em gramas é convertida para miligramas', () => {
    const r = executarProtocolo(entrada({ focoId: 'itu' }))
    expect(r.recomendacao.prescricoes[0]?.doseCalculadaMg).toBe(2000)
  })

  it('alerta quando a dose pediátrica supera a maior dose adulta do protocolo', () => {
    // Ceftriaxona 50 mg/kg/dose em 60 kg → 3000 mg, acima dos 2000 mg do adulto.
    const r = executarProtocolo(
      entrada({ populacao: 'pediatrico', pesoKg: 60, focoId: 'itu' }),
    )
    expect(
      r.recomendacao.alertas.some((a) => a.titulo.includes('acima da dose adulta')),
    ).toBe(true)
  })

  it('não alerta quando a dose pediátrica está dentro da dose adulta', () => {
    const r = executarProtocolo(
      entrada({ populacao: 'pediatrico', pesoKg: 20, focoId: 'itu' }),
    )
    expect(
      r.recomendacao.alertas.some((a) => a.titulo.includes('acima da dose adulta')),
    ).toBe(false)
  })

  it('exige peso em pediatria e recusa peso fora da faixa', () => {
    const semPeso = executarProtocoloSeguro(entrada({ populacao: 'pediatrico', focoId: 'itu' }))
    expect(semPeso.ok).toBe(false)
    if (!semPeso.ok) expect(semPeso.error.code).toBe('PESO_OBRIGATORIO')

    const pesoAbsurdo = executarProtocoloSeguro(
      entrada({ populacao: 'pediatrico', pesoKg: 900, focoId: 'itu' }),
    )
    expect(pesoAbsurdo.ok).toBe(false)
    if (!pesoAbsurdo.ok) expect(pesoAbsurdo.error.code).toBe('PESO_FORA_DA_FAIXA')
  })

  it('Vancomicina nunca recebe dose calculada e sempre alerta', () => {
    const r = executarProtocolo(
      entrada({ origem: 'iras', setor: 'enfermaria', focoId: 'ipcs' }),
    )
    const vanco = r.recomendacao.prescricoes.find((p) => p.drug.id === 'vancomicina')
    expect(vanco?.doseCalculadaMg).toBeUndefined()
    expect(vanco?.doseTexto).toBe('conforme protocolo específico')
    expect(vanco?.alertas.some((a) => a.severidade === 'critico')).toBe(true)
  })

  it('DOSES_POR_DIA é coerente com os intervalos', () => {
    expect(DOSES_POR_DIA.q4h * 4).toBe(24)
    expect(DOSES_POR_DIA.q6h * 6).toBe(24)
    expect(DOSES_POR_DIA.q8h * 8).toBe(24)
    expect(DOSES_POR_DIA.q12h * 12).toBe(24)
    expect(DOSES_POR_DIA.q24h * 24).toBe(24)
  })
})

// ---------------------------------------------------------------------------
describe('integridade do catálogo de regras', () => {
  it('todo fármaco referenciado existe no catálogo', () => {
    for (const regra of TODAS_AS_REGRAS) {
      for (const p of regra.prescricoes) {
        expect(DRUGS[p.drugId], `${regra.id} → ${p.drugId}`).toBeDefined()
      }
    }
  })

  it('todo foco referenciado existe no catálogo', () => {
    for (const regra of TODAS_AS_REGRAS) {
      expect(FOCOS[regra.focoId], regra.id).toBeDefined()
    }
  })

  it('os identificadores de regra são únicos', () => {
    const ids = TODAS_AS_REGRAS.map((r) => r.id)
    expect(new Set(ids).size).toBe(ids.length)
  })

  it('cada foco de cada seção tem exatamente um fallback de prioridade 0', () => {
    for (const [secaoId, regras] of Object.entries(REGRAS_POR_SECAO)) {
      const focos = new Set(regras.map((r) => r.focoId))
      for (const foco of focos) {
        const fallbacks = regras.filter((r) => r.focoId === foco && r.prioridade === 0)
        expect(fallbacks.length, `${secaoId} / ${foco}`).toBe(1)
      }
    }
  })

  it('o fallback de cada foco casa com modificadores vazios', () => {
    for (const regras of Object.values(REGRAS_POR_SECAO)) {
      for (const regra of regras.filter((r) => r.prioridade === 0)) {
        const input = entrada({ focoId: regra.focoId })
        expect(regra.match({}, input), regra.id).toBe(true)
      }
    }
  })

  it('toda regra é alcançável por alguma combinação de entradas', () => {
    // Varredura por força bruta sobre o espaço de modificadores relevantes.
    const combinacoes: Modificadores[] = []
    const flags: (keyof Modificadores)[] = [
      'aspirativa',
      'atbPrevio',
      'litiaseRenal',
      'ituRecorrente',
      'necrose',
      'segundaOpcao',
      'dispositivoInvasivo',
      'suspeitaEnterococcusAnaerobio',
    ]
    for (const f of flags) combinacoes.push({ [f]: true })
    combinacoes.push({})
    for (const dias of [1, 5, 6, 10]) combinacoes.push({ diasVentilacaoMecanica: dias })
    for (const dias of [1, 6]) combinacoes.push({ diasVentilacaoMecanica: dias, aspirativa: true })
    for (const s of ['precoce', 'tardia'] as const) {
      combinacoes.push({ sepseNeonatal: s })
    }

    const cenarios: ClinicalInput[] = []
    const populacoes = [
      { populacao: 'adulto' as const, pesoKg: undefined },
      { populacao: 'pediatrico' as const, pesoKg: 15 },
      { populacao: 'neonatal' as const, pesoKg: 3 },
    ]
    for (const pop of populacoes) {
      for (const origem of ['comunitaria', 'iras'] as const) {
        for (const setor of ['ps', 'enfermaria', 'uti'] as const) {
          for (const focoId of Object.keys(FOCOS)) {
            for (const modificadores of combinacoes) {
              cenarios.push({
                populacao: pop.populacao,
                ...(pop.pesoKg !== undefined ? { pesoKg: pop.pesoKg } : {}),
                origem,
                setor,
                focoId,
                modificadores,
              })
            }
          }
        }
      }
    }

    const alcancadas = new Set<string>()
    for (const c of cenarios) {
      try {
        const secao = resolverSecao(c)
        const regra = selecionarRegra(REGRAS_POR_SECAO[secao.id] ?? [], c)
        alcancadas.add(regra.id)
      } catch {
        // cenário legitimamente não coberto pelo protocolo
      }
    }

    const inalcancaveis = TODAS_AS_REGRAS.filter((r) => !alcancadas.has(r.id)).map((r) => r.id)
    expect(inalcancaveis).toEqual([])
  })

  it('nenhuma regra fica sem prescrição', () => {
    for (const regra of TODAS_AS_REGRAS) {
      expect(regra.prescricoes.length, regra.id).toBeGreaterThan(0)
    }
  })

  it('focosDaSecao devolve apenas focos realmente cobertos', () => {
    expect(focosDaSecao('6.2').map((f) => f.id).sort()).toEqual(
      ['ipcs', 'isc', 'itu', 'pneumonia_hospitalar', 'protese'].sort(),
    )
    expect(focosDaSecao('6.1').some((f) => f.id === 'meningite')).toBe(true)
    expect(focosDaSecao('6.5').some((f) => f.id === 'meningite')).toBe(false)
    // ISC foi acrescentada à UTI adulto por definição do SCIH.
    expect(focosDaSecao('6.5').some((f) => f.id === 'isc')).toBe(true)
  })
})

// ---------------------------------------------------------------------------
describe('formatação para as tabelas do guia', () => {
  it('sem peso, exibe a posologia literal do protocolo', () => {
    const regra = REGRAS_POR_SECAO['6.3'].find((r) => r.id === '6.3.itu.1a')
    expect(regra).toBeDefined()
    const linhas = formatarRegime(regra!)
    expect(linhas[0]?.dose).toBe('50 mg/kg/dose')
    expect(linhas[0]?.memoria).toBeUndefined()
  })

  it('com peso, converte e mostra a memória de cálculo', () => {
    const regra = REGRAS_POR_SECAO['6.3'].find((r) => r.id === '6.3.itu.1a')
    const linhas = formatarRegime(regra!, 12)
    expect(linhas[0]?.dose).toBe('600 mg')
    expect(linhas[0]?.memoria).toContain('12 kg')
  })

  it('peso inválido degrada para a posologia literal, sem lançar', () => {
    const regra = REGRAS_POR_SECAO['6.3'].find((r) => r.id === '6.3.itu.1a')
    expect(() => formatarRegime(regra!, 5000)).not.toThrow()
    expect(formatarRegime(regra!, 5000)[0]?.dose).toBe('50 mg/kg/dose')
  })

  it('identifica corretamente os esquemas com betalactâmico', () => {
    const osteo = REGRAS_POR_SECAO['6.1'].find((r) => r.id === '6.1.osteoarticular.1a')
    expect(formatarRegime(osteo!).some((l) => l.betalactamico)).toBe(false)

    const pneumonia = REGRAS_POR_SECAO['6.1'].find((r) => r.id === '6.1.pneumonia.1a')
    expect(formatarRegime(pneumonia!).some((l) => l.betalactamico)).toBe(true)
  })
})

// ---------------------------------------------------------------------------
describe('alertas transversais e alternativas', () => {
  it('toda recomendação lembra culturas e reavaliação', () => {
    const alertas = executarProtocolo(entrada()).recomendacao.alertas
    expect(alertas.some((a) => a.titulo.includes('culturas'))).toBe(true)
    expect(alertas.some((a) => a.titulo.includes('48–72'))).toBe(true)
  })

  it('idade incoerente com a população gera aviso', () => {
    const r = executarProtocolo(
      entrada({ populacao: 'neonatal', pesoKg: 4, idadeDias: 60, origem: 'iras', setor: 'uti', focoId: 'itu' }),
    )
    expect(r.recomendacao.alertas.some((a) => a.titulo.includes('Idade'))).toBe(true)
  })

  it('as alternativas do mesmo foco são devolvidas sem repetir a principal', () => {
    const r = executarProtocolo(entrada({ focoId: 'abdominal' }))
    expect(r.recomendacao.rule.id).toBe('6.1.abdominal.1a')
    expect(r.alternativas.map((a) => a.rule.id)).toEqual(['6.1.abdominal.2a'])
  })

  it('foco não coberto pela seção falha com orientação para o SCIH', () => {
    const r = executarProtocoloSeguro(
      entrada({ origem: 'iras', setor: 'uti', focoId: 'meningite' }),
    )
    expect(r.ok).toBe(false)
    if (!r.ok) {
      expect(r.error.code).toBe('FOCO_NAO_COBERTO')
      expect(r.error).toBeInstanceOf(ProtocolError)
    }
  })
})


// ---------------------------------------------------------------------------
describe('dexametasona adjuvante na meningite', () => {
  it('adulto recebe 10 mg fixos a cada 6 h', () => {
    const r = executarProtocolo(entrada({ focoId: 'meningite' }))
    const dexa = r.recomendacao.prescricoes.find((p) => p.drug.id === 'dexametasona')
    expect(dexa?.doseCalculadaMg).toBe(10)
    expect(dexa?.intervaloTexto).toBe('6/6h')
  })

  it('pediatria calcula 0,15 mg/kg/dose', () => {
    // 0,15 × 20 kg = 3 mg por dose; 4 tomadas → 12 mg/dia.
    const r = executarProtocolo(
      entrada({ populacao: 'pediatrico', pesoKg: 20, focoId: 'meningite' }),
    )
    const dexa = r.recomendacao.prescricoes.find((p) => p.drug.id === 'dexametasona')
    expect(dexa?.doseCalculadaMg).toBe(3)
    expect(dexa?.doseDiariaMg).toBe(12)
  })

  it('o alerta de timing é crítico e aparece nas duas populações', () => {
    for (const input of [
      entrada({ focoId: 'meningite' }),
      entrada({ populacao: 'pediatrico', pesoKg: 20, focoId: 'meningite' }),
    ]) {
      const alertas = executarProtocolo(input).recomendacao.alertas
      const timing = alertas.find((a) => a.titulo.includes('Dexametasona'))
      expect(timing?.severidade).toBe('critico')
      expect(timing?.detalhe).toContain('ANTES')
    }
  })

  it('não aparece em focos que não sejam meningite', () => {
    const r = executarProtocolo(entrada({ focoId: 'sepse_sem_foco' }))
    expect(r.recomendacao.prescricoes.some((p) => p.drug.id === 'dexametasona')).toBe(false)
  })
})

// ---------------------------------------------------------------------------
describe('amicacina neonatal remete à tabela dedicada', () => {
  const neo = {
    populacao: 'neonatal' as const,
    origem: 'iras' as const,
    setor: 'uti' as const,
    pesoKg: 2,
  }

  it('não devolve dose numérica e emite alerta crítico', () => {
    const r = executarProtocolo(
      entrada({ ...neo, focoId: 'ipcs', modificadores: { dispositivoInvasivo: true } }),
    )
    const ami = r.recomendacao.prescricoes.find((p) => p.drug.id === 'amicacina')
    expect(ami).toBeDefined()
    expect(ami?.doseCalculadaMg).toBeUndefined()
    expect(
      ami?.alertas.some((a) => a.severidade === 'critico' && a.titulo.includes('tabela')),
    ).toBe(true)
  })

  it('vale também para a sepse neonatal tardia', () => {
    const r = executarProtocolo(
      entrada({ ...neo, focoId: 'sepse_sem_foco', modificadores: { sepseNeonatal: 'tardia' } }),
    )
    const ami = r.recomendacao.prescricoes.find((p) => p.drug.id === 'amicacina')
    expect(ami?.doseCalculadaMg).toBeUndefined()
  })
})

// ---------------------------------------------------------------------------
describe('nomenclatura e base de cálculo da piperacilina/tazobactam', () => {
  it('o nome comercial não aparece em nenhum texto exibido', () => {
    for (const regra of TODAS_AS_REGRAS) {
      expect(regra.textoOriginal, regra.id).not.toContain('Tazocin')
      expect(regra.condicaoLabel, regra.id).not.toContain('Tazocin')
    }
  })

  it('mas continua indexado como sinônimo, para a busca', () => {
    expect(DRUGS.piperacilina_tazobactam?.sinonimos).toContain('Tazocin')
  })

  it('toda prescrição pediátrica ponderal declara a base 8:1', () => {
    const ponderais = TODAS_AS_REGRAS.flatMap((r) =>
      r.prescricoes
        .filter((p) => p.drugId === 'piperacilina_tazobactam' && p.dosePonderal)
        .map((p) => ({ regra: r.id, p })),
    )
    expect(ponderais.length).toBeGreaterThan(0)
    for (const { regra, p } of ponderais) {
      expect((p.observacoes ?? []).join(' '), regra).toContain('piperacilina')
    }
  })
})

// ---------------------------------------------------------------------------
describe('associações facultativas: o critério precisa chegar à tela', () => {
  /** Toda prescrição marcada com "+/-" no protocolo, com a regra de origem. */
  const facultativas = TODAS_AS_REGRAS.flatMap((r) =>
    r.prescricoes.filter((p) => p.facultativo === true).map((p) => ({ regra: r.id, p })),
  )

  it('existem associações facultativas nas tabelas', () => {
    expect(facultativas.length).toBeGreaterThan(0)
  })

  /**
   * Um "+/-" sem critério transfere a decisão para o plantonista — exatamente
   * o que um guia de bolso existe para evitar.
   */
  it('nenhuma associação facultativa fica sem critério declarado', () => {
    for (const { regra, p } of facultativas) {
      expect(p.criterioFacultativo, `${regra} / ${p.drugId}`).toBeTruthy()
    }
  })

  /**
   * REGRESSÃO: o critério já existiu nos dados sem nenhum caminho até a
   * interface — a tabela mostrava "(associação facultativa)" e engolia o
   * porquê. `formatarRegime` é o único caminho de exibição das tabelas.
   */
  it('formatarRegime propaga o critério para a linha exibida', () => {
    for (const regra of TODAS_AS_REGRAS) {
      const linhas = formatarRegime(regra)
      regra.prescricoes.forEach((p, i) => {
        if (p.facultativo !== true) return
        expect(linhas[i]?.facultativo, regra.id).toBe(true)
        expect(linhas[i]?.criterioFacultativo, `${regra.id} / ${p.drugId}`).toBe(
          p.criterioFacultativo,
        )
      })
    }
  })

  it('o critério do macrolídeo se identifica como proposta, não como protocolo', () => {
    const macrolideo = facultativas.filter((f) => f.p.drugId === 'azitromicina')
    expect(macrolideo.length).toBe(2) // adulto (6.1) e pediatria (6.3)
    for (const { regra, p } of macrolideo) {
      expect(p.criterioFacultativo, regra).toContain('PROPOSTA')
    }
  })
})
