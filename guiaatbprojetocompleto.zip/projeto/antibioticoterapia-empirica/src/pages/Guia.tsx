import { useEffect, useMemo, useRef, useState } from 'react'
import { Search, X } from 'lucide-react'
import { HeroHeader } from '@/components/HeroHeader'
import { BarraRolagem } from '@/components/BarraRolagem'
import { GuideCardView } from '@/components/GuideCardView'
import { Chip, Callout, TogglePill } from '@/components/ui/primitives'
import { buscarNoGuia, SUGESTOES } from '@/lib/search'
import { CARDS, GRUPOS, type GrupoId } from '@/data/cards'
import { PESO_CORTE_PEDIATRICO_KG } from '@/components/Calculadora'
import { PROTOCOLO } from '@/data'

/**
 * Tela única do guia de bolso.
 *
 * Composição espelhada da referência, de cima para baixo:
 *   herói + fatos-chave → busca + toggle de alergia → chips de seção →
 *   fichas em acordeão → rodapé com a ressalva institucional.
 */
export function Guia() {
  const [query, setQuery] = useState('')
  const [grupo, setGrupo] = useState<GrupoId | null>(null)
  const [modoAlergia, setModoAlergia] = useState(false)
  const [pesoKg, setPesoKg] = useState<number | undefined>(undefined)
  // Qual aba da ficha de Vancomicina o atalho das tabelas deve abrir.
  const [vancoPopulacao, setVancoPopulacao] = useState<'adulto' | 'neoped' | undefined>(
    undefined,
  )
  // Alvo da barra de rolagem própria, logo abaixo do buscador.
  const chipsRef = useRef<HTMLDivElement | null>(null)

  // Fichas abertas por escolha do usuário; a busca abre outras temporariamente.
  const [abertasManual, setAbertasManual] = useState<Set<string>>(
    () => new Set(CARDS.filter((c) => c.aberta).map((c) => c.id)),
  )

  const resultados = useMemo(() => buscarNoGuia(query, grupo), [query, grupo])
  const buscando = query.trim().length > 0

  // Ao digitar, o peso abaixo do corte pediátrico prioriza as fichas de
  // pediatria — é a "troca sozinha para o esquema pediátrico" da referência.
  const pediatricoAtivo = pesoKg !== undefined && pesoKg < PESO_CORTE_PEDIATRICO_KG

  const ordenados = useMemo(() => {
    if (!pediatricoAtivo) return resultados
    const pesoDoGrupo = (g: GrupoId): number =>
      g === 'pediatria' || g === 'uti-neoped' ? 0 : g === 'doses' || g === 'fluxo' ? 1 : 2
    return resultados
      .slice()
      .sort((a, b) => pesoDoGrupo(a.card.grupo) - pesoDoGrupo(b.card.grupo))
  }, [resultados, pediatricoAtivo])

  // Fecha o teclado virtual ao rolar em telas pequenas.
  useEffect(() => {
    if (!buscando) return
    const onScroll = () => (document.activeElement as HTMLElement | null)?.blur?.()
    window.addEventListener('scroll', onScroll, { once: true, passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [buscando])

  const alternar = (id: string) => {
    setAbertasManual((atual) => {
      const proximo = new Set(atual)
      if (proximo.has(id)) proximo.delete(id)
      else proximo.add(id)
      return proximo
    })
  }

  // Abre uma ficha específica e rola até ela — usado pelos atalhos internos
  // (ex.: a citação de Vancomicina nas tabelas leva à ficha de Vancomicina).
  // Limpa a busca antes, senão a ficha-alvo pode não estar na lista filtrada.
  const abrirFicha = (id: string, vancoPop?: 'adulto' | 'neoped') => {
    setQuery('')
    if (vancoPop) setVancoPopulacao(vancoPop)
    setAbertasManual((atual) => new Set(atual).add(id))
    // Espera o próximo paint para o elemento existir já expandido.
    requestAnimationFrame(() => {
      document
        .getElementById(`ficha-${id}`)
        ?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  }

  return (
    <div className="mx-auto min-h-screen w-full max-w-3xl pb-16">
      <HeroHeader />

      {/* ---- Busca + modo alergia ---- */}
      <div className="no-print sticky top-0 z-20 mt-5 bg-background/95 px-4 py-3 backdrop-blur">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search
              aria-hidden
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar foco ou antibiótico"
              aria-label="Buscar foco de infecção ou antibiótico"
              className="w-full rounded-lg border border-border bg-input py-3 pl-9 pr-9 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-ring"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                aria-label="Limpar busca"
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1.5 text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" aria-hidden />
              </button>
            )}
          </div>

          <TogglePill
            ativo={modoAlergia}
            onClick={() => setModoAlergia((v) => !v)}
            title="Sinaliza os esquemas que contêm betalactâmico"
          >
            Alergia
          </TogglePill>
        </div>

        {/* ---- Chips de seção ---- */}
        <div ref={chipsRef} className="scroll-x-visible mt-3">
          <Chip ativo={grupo === null} onClick={() => setGrupo(null)}>
            Tudo
          </Chip>
          {GRUPOS.map((g) => (
            <Chip
              key={g.id}
              ativo={grupo === g.id}
              onClick={() => setGrupo(grupo === g.id ? null : g.id)}
            >
              {g.rotulo}
            </Chip>
          ))}
        </div>

        {/* Barra de rolagem própria: a nativa é overlay e some em repouso,
            deixando o usuário sem pista de que há mais seções à direita. */}
        <BarraRolagem alvoRef={chipsRef} className="mt-1.5" rotulo="Rolar seções do guia" />

        {/* ---- Sugestões, só com a busca vazia ---- */}
        {!buscando && (
          <div className="scroll-x mt-2">
            {SUGESTOES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setQuery(s)}
                className="shrink-0 rounded-full border border-border px-3 py-1 text-xs text-muted-foreground hover:border-primary/50 hover:text-primary"
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ---- Avisos de estado ---- */}
      <div className="space-y-3 px-4">
        {modoAlergia && (
          <Callout
            severidade="critico"
            titulo="Modo alergia ativo"
            fonte="Ficha 17 — alternativas por foco"
          >
            As linhas com betalactâmico ficam marcadas em vermelho. O protocolo{' '}
            <strong>não define esquema substituto</strong>; a ficha 15 traz uma{' '}
            <strong>proposta de alternativa para cada foco</strong>, para discussão e
            aprovação do SCIH. Antes de trocar, estratifique a reação — a maioria dos
            rótulos de alergia não se confirma.
          </Callout>
        )}

        {pediatricoAtivo && (
          <Callout severidade="info" titulo={`Esquema pediátrico ativo — ${pesoKg} kg`}>
            As tabelas exibem as doses já convertidas em miligramas e as fichas de
            pediatria foram trazidas para o topo.
          </Callout>
        )}
      </div>

      {/* ---- Fichas ---- */}
      <main className="mt-3 space-y-3 px-4">
        {ordenados.length === 0 ? (
          <Callout severidade="atencao" titulo="Nada encontrado">
            Nenhuma ficha corresponde a “{query}”. Tente o nome do foco (pneumonia, ITU,
            IPCS, sepse) ou do antimicrobiano (cefepime, meropenem, piperacilina).
          </Callout>
        ) : (
          ordenados.map(({ card, regrasCasadas, autoExpandir }) => (
            <GuideCardView
              key={card.id}
              card={card}
              aberta={buscando ? autoExpandir : abertasManual.has(card.id)}
              onToggle={() => alternar(card.id)}
              pesoKg={pesoKg}
              onPesoChange={setPesoKg}
              regrasCasadas={regrasCasadas}
              modoAlergia={modoAlergia}
              onAbrirFicha={abrirFicha}
              vancoPopulacao={vancoPopulacao}
            />
          ))
        )}
      </main>

      {/* ---- Rodapé institucional ---- */}
      <footer className="mt-8 space-y-2 px-4 text-xs leading-relaxed text-muted-foreground">
        <p>
          {PROTOCOLO.titulo} — {PROTOCOLO.setor} do {PROTOCOLO.instituicao}. Versão{' '}
          {PROTOCOLO.revisao}, válida até {PROTOCOLO.validade}.
        </p>
        <p>
          <strong className="text-foreground">
            Guia de consulta rápida: em qualquer divergência vale o protocolo institucional
            na íntegra.
          </strong>{' '}
          Não substitui julgamento clínico nem dispensa a avaliação do SCIH. Erros ou
          lacunas devem ser comunicados ao Serviço de Controle de Infecção Hospitalar.
        </p>
        <p>{PROTOCOLO.responsavel}.</p>
      </footer>
    </div>
  )
}
