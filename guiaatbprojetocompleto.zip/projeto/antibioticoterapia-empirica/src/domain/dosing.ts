import type { Drug, DrugPrescription, Intervalo, Quantidade } from './types'
import { ProtocolError } from './errors'

/** Nº de administrações em 24 h para cada intervalo posológico. */
export const DOSES_POR_DIA: Record<Intervalo, number> = {
  q4h: 6,
  q6h: 4,
  q8h: 3,
  q12h: 2,
  q24h: 1,
}

export const INTERVALO_LABEL: Record<Intervalo, string> = {
  q4h: '4/4h',
  q6h: '6/6h',
  q8h: '8/8h',
  q12h: '12/12h',
  q24h: '24/24h',
}

/** Faixa de peso aceita. Fora dela, o motor recusa o cálculo. */
export const PESO_MIN_KG = 0.3
export const PESO_MAX_KG = 300

export function isFaixa(q: Quantidade): q is readonly [number, number] {
  return Array.isArray(q)
}

/** Aplica `fn` a um escalar ou aos dois extremos de uma faixa. */
export function mapQuantidade(q: Quantidade, fn: (n: number) => number): Quantidade {
  return isFaixa(q) ? [fn(q[0]), fn(q[1])] : fn(q as number)
}

/**
 * Arredondamento de dose.
 *
 * Doses pediátricas resultam em números quebrados (ex.: 50 mg/kg × 7,4 kg =
 * 370 mg). Arredondar para o miligrama inteiro mantém a dose auditável contra o
 * cálculo manual à beira-leito; abaixo de 10 mg preserva-se uma casa decimal,
 * porque em neonatologia 1 mg pode ser clinicamente relevante.
 */
export function arredondarMg(mg: number): number {
  if (mg < 10) return Math.round(mg * 10) / 10
  return Math.round(mg)
}

/** Formata quantidade em mg, promovendo para gramas a partir de 1000 mg. */
export function formatarMg(q: Quantidade): string {
  const fmt = (mg: number): string => {
    if (mg >= 1000) {
      const g = mg / 1000
      return `${formatarNumero(g)} g`
    }
    return `${formatarNumero(mg)} mg`
  }
  return isFaixa(q) ? `${fmt(q[0])} – ${fmt(q[1])}` : fmt(q as number)
}

/** Formatação numérica pt-BR, sem casas decimais supérfluas. */
export function formatarNumero(n: number): string {
  const arredondado = Math.round(n * 100) / 100
  return arredondado.toLocaleString('pt-BR', { maximumFractionDigits: 2 })
}

/** Converte a dose fixa da prescrição para miligramas. */
export function doseFixaEmMg(p: DrugPrescription): Quantidade | undefined {
  if (!p.doseFixa) return undefined
  const fator = p.doseFixa.unidade === 'g' ? 1000 : 1
  return mapQuantidade(p.doseFixa.valor, (v) => v * fator)
}

export interface DoseCalculada {
  /** Dose por administração, em mg. Ausente enquanto o peso não for informado. */
  porDose?: Quantidade
  /** Dose total em 24 h, em mg. Ausente enquanto o peso não for informado. */
  porDia?: Quantidade
  /** Texto pronto para a prescrição. */
  texto: string
  /** Memória de cálculo, exibida para conferência. */
  memoria?: string
  /** Dose por administração excede a maior dose adulta prevista no protocolo. */
  excedeTetoAdulto: boolean
  /** Dose diária total excede o teto diário do fármaco. */
  excedeTetoDiario?: boolean
  /**
   * A posologia é ponderal e o peso não foi informado: `texto` traz a dose como
   * grafada no protocolo ("5–7 mg/kg/dia") em vez de um valor em miligramas.
   */
  pendentePeso: boolean
}

/** Posologia como grafada no protocolo, independente do peso. */
export function posologiaLiteral(p: DrugPrescription): string {
  if (p.doseFixa) {
    const { valor, unidade } = p.doseFixa
    const v = isFaixa(valor)
      ? `${formatarNumero(valor[0])}–${formatarNumero(valor[1])}`
      : formatarNumero(valor as number)
    return `${v} ${unidade}`
  }
  if (p.dosePonderal) {
    const { valor, base } = p.dosePonderal
    const v = isFaixa(valor)
      ? `${formatarNumero(valor[0])}–${formatarNumero(valor[1])}`
      : formatarNumero(valor as number)
    return `${v} mg/kg/${base}`
  }
  return 'conforme protocolo específico'
}

/**
 * Calcula a dose de uma prescrição.
 *
 * Regras de conversão:
 * - `base: 'dose'` → o valor em mg/kg JÁ é a dose por administração (nota ³).
 *   A dose diária é obtida multiplicando pelo número de administrações.
 * - `base: 'dia'`  → o valor em mg/kg é a dose DIÁRIA; a dose por administração
 *   é obtida dividindo pelo número de administrações.
 *
 * Peso ausente NÃO é erro: a dose ponderal é devolvida como grafada no
 * protocolo, com `pendentePeso: true`. Recusar o esquema inteiro por falta de um
 * campo empurraria o prescritor de volta ao PDF justamente no momento em que ele
 * precisa da conduta — e as demais doses do esquema são plenamente utilizáveis.
 * Peso INVÁLIDO, ao contrário, é erro: calcular sobre um número errado é pior
 * que não calcular.
 *
 * @param p        prescrição a calcular
 * @param drug     fármaco (para a checagem de teto adulto)
 * @param pesoKg   peso do paciente; opcional
 * @throws {ProtocolError} PESO_FORA_DA_FAIXA
 */
export function calcularDose(
  p: DrugPrescription,
  drug: Drug,
  pesoKg?: number,
): DoseCalculada | undefined {
  const dosesDia = DOSES_POR_DIA[p.intervalo]

  // --- Dose fixa (adulto) --------------------------------------------------
  const fixa = doseFixaEmMg(p)
  if (fixa !== undefined) {
    return {
      porDose: fixa,
      porDia: mapQuantidade(fixa, (mg) => mg * dosesDia),
      texto: formatarMg(fixa),
      excedeTetoAdulto: false,
      pendentePeso: false,
    }
  }

  // --- Dose ponderal (pediatria/neonatologia e aminoglicosídeos do adulto) --
  if (p.dosePonderal) {
    if (pesoKg === undefined || Number.isNaN(pesoKg)) {
      return {
        texto: posologiaLiteral(p),
        excedeTetoAdulto: false,
        pendentePeso: true,
      }
    }
    if (pesoKg < PESO_MIN_KG || pesoKg > PESO_MAX_KG) {
      throw new ProtocolError(
        'PESO_FORA_DA_FAIXA',
        `Peso ${pesoKg} kg fora da faixa aceita (${PESO_MIN_KG}–${PESO_MAX_KG} kg).`,
        'Confira o peso informado. Valores fora dessa faixa não são calculados ' +
          'automaticamente por segurança.',
      )
    }

    const { valor, base } = p.dosePonderal
    const porDose: Quantidade =
      base === 'dose'
        ? mapQuantidade(valor, (mgkg) => arredondarMg(mgkg * pesoKg))
        : mapQuantidade(valor, (mgkg) => arredondarMg((mgkg * pesoKg) / dosesDia))
    const porDia: Quantidade =
      base === 'dia'
        ? mapQuantidade(valor, (mgkg) => arredondarMg(mgkg * pesoKg))
        : mapQuantidade(valor, (mgkg) => arredondarMg(mgkg * pesoKg * dosesDia))

    const unidadeOrigem = base === 'dose' ? 'mg/kg/dose' : 'mg/kg/dia'
    const valorTexto = isFaixa(valor)
      ? `${formatarNumero(valor[0])}–${formatarNumero(valor[1])}`
      : formatarNumero(valor as number)

    const maiorPorDose = isFaixa(porDose) ? porDose[1] : (porDose as number)
    const maiorPorDia = isFaixa(porDia) ? porDia[1] : (porDia as number)
    const teto = drug.tetoAdultoPorDose?.valor
    const tetoDia = drug.tetoDiarioMg

    return {
      porDose,
      porDia,
      texto: formatarMg(porDose),
      memoria: `${valorTexto} ${unidadeOrigem} × ${formatarNumero(pesoKg)} kg`,
      excedeTetoAdulto: teto !== undefined && maiorPorDose > teto,
      ...(tetoDia !== undefined && maiorPorDia > tetoDia ? { excedeTetoDiario: true } : {}),
      pendentePeso: false,
    }
  }

  // --- Sem dose (Vancomicina: remetida a protocolo externo) ----------------
  return undefined
}
