/**
 * Critérios clínicos que o protocolo institucional deixa em aberto.
 *
 * O protocolo grafa "+/-" em algumas associações sem dizer QUANDO associar.
 * Um "+/-" sem critério é, na prática, uma decisão jogada para o plantonista —
 * que é exatamente o que um guia de bolso deveria evitar. Este módulo reúne os
 * critérios propostos a partir de diretriz publicada, para que apareçam no app
 * SEMPRE identificados como proposta, nunca como texto do protocolo.
 *
 * Cada constante daqui é referenciada em `criterioFacultativo` nas tabelas de
 * `src/data/tables/**` — mantê-las aqui garante que adulto e pediatria não
 * divirjam ao longo do tempo, e que a revisão do SCIH tenha um só lugar para
 * aprovar ou substituir o texto.
 */

/**
 * Critério para associar macrolídeo (Azitromicina) na pneumonia comunitária
 * do ADULTO — o "+/- Azitromicina" da seção 6.1.
 *
 * Base: ATS/IDSA 2019 (Metlay et al., Am J Respir Crit Care Med), que mantém a
 * terapia combinada betalactâmico + macrolídeo como recomendação forte na
 * pneumonia GRAVE e a torna dispensável na não grave sem comorbidade. O limiar
 * de 25% de resistência local do pneumococo é o mesmo que a diretriz usa para
 * desaconselhar macrolídeo em monoterapia.
 */
export const CRITERIO_MACROLIDEO_ADULTO =
  'PROPOSTA (o protocolo não define o critério): associar na pneumonia ' +
  'GRAVE — critérios de UTI, sepse ou necessidade de vasopressor — e na ' +
  'suspeita de germe atípico (*Mycoplasma*, *Chlamydophila*, *Legionella*). ' +
  'Na pneumonia não grave a associação é dispensável. Macrolídeo em ' +
  'monoterapia só onde a resistência local do pneumococo for < 25%. ' +
  'Referência: ATS/IDSA 2019.'

/**
 * Mesma decisão na PEDIATRIA — o "+/- Azitromicina" da seção 6.3.
 *
 * Muda o peso dos fatores: abaixo dos 5 anos a pneumonia é majoritariamente
 * viral ou pneumocócica e o macrolídeo pouco acrescenta; a partir da idade
 * escolar o *Mycoplasma* passa a ser causa frequente, e é aí que a associação
 * se justifica. Base: PIDS/IDSA, diretriz de pneumonia comunitária pediátrica.
 */
export const CRITERIO_MACROLIDEO_PEDIATRICO =
  'PROPOSTA (o protocolo não define o critério): associar na pneumonia GRAVE ' +
  'e na suspeita de germe atípico — sobretudo *Mycoplasma pneumoniae* no ' +
  'escolar e adolescente (≥ 5 anos), quadro arrastado, tosse seca ' +
  'persistente ou padrão intersticial. Abaixo dos 5 anos o atípico é ' +
  'incomum e a associação costuma ser dispensável. Referência: PIDS/IDSA.'
