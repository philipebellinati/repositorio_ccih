import { Guia } from './pages/Guia'

/**
 * O guia é deliberadamente de tela única, sem roteador: no celular, dentro de um
 * plantão, cada navegação a mais é um toque a mais entre a dúvida e a dose.
 * Busca e chips fazem o papel de navegação.
 */
export default function App() {
  return <Guia />
}
