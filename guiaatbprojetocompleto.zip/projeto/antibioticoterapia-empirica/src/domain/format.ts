import type { ProtocolRule } from './types'
import { DRUGS } from '@/data/drugs'
import { calcularDose, INTERVALO_LABEL, posologiaLiteral } from './dosing'

/**
 * Formatação de esquemas para EXIBIÇÃO no guia (tabelas e busca).
 *
 * Diferente do motor de decisão, que só produz saída para um cenário clínico
 * completo e validado, este módulo formata qualquer linha do protocolo de forma
 * isolada — é o que permite folhear as tabelas sem preencher um assistente.
 * O cálculo ponderal é opcional: sem peso, exibe-se a posologia como está no
 * documento ("50 mg/kg/dose").
 */

export interface LinhaExibicao {
  /** Id do fármaco — permite à interface achar o substituto no modo alergia. */
  drugId: string
  nome: string
  /** Texto da dose — calculado se houver peso, literal caso contrário. */
  dose: string
  via: string
  intervalo: string
  facultativo: boolean
  /**
   * Critério que orienta a decisão de associar ou não um item facultativo.
   * Um "+/-" sem critério transfere a decisão para o plantonista — é a
   * informação mais importante da linha e precisa aparecer na tabela.
   */
  criterioFacultativo?: string
  /** Memória de cálculo, quando a dose foi computada a partir do peso. */
  memoria?: string
  /** Sinaliza dose ponderal acima da maior dose adulta do protocolo. */
  excedeTetoAdulto?: boolean
  /** Fármaco cuja posologia vive em outro documento (Vancomicina). */
  protocoloExterno?: string
  /** Dose definida em tabela dedicada (amicacina neonatal). */
  tabelaDose?: string
  /**
   * Observações da prescrição — base de cálculo, faixas sem critério, duração.
   * Sem elas a tabela do guia esconderia informação que muda a prescrição.
   */
  observacoes: readonly string[]
  /** O fármaco é betalactâmico — usado pelo modo alergia. */
  betalactamico: boolean
}

/** Fármacos betalactâmicos do catálogo, para o modo ALERGIA. */
export const BETALACTAMICOS = new Set([
  'ceftriaxona',
  'cefepime',
  'oxacilina',
  'ampicilina',
  'piperacilina_tazobactam',
  'meropenem',
])

/**
 * Converte uma regra do protocolo em linhas prontas para a tabela.
 *
 * @param regra   linha do protocolo
 * @param pesoKg  peso opcional; quando presente, doses em mg/kg são calculadas
 */
export function formatarRegime(regra: ProtocolRule, pesoKg?: number): LinhaExibicao[] {
  return regra.prescricoes.map((p) => {
    const drug = DRUGS[p.drugId]
    const nome = drug?.nome ?? p.drugId

    let dose = posologiaLiteral(p)
    let memoria: string | undefined
    let excede = false

    // O cálculo só é tentado quando há peso E a dose é ponderal. Qualquer erro
    // (peso fora de faixa) degrada para a posologia literal — folhear a tabela
    // nunca deve quebrar por causa de um campo de peso mal preenchido.
    if (pesoKg !== undefined && p.dosePonderal && drug) {
      try {
        const calc = calcularDose(p, drug, pesoKg)
        if (calc && !calc.pendentePeso) {
          dose = calc.texto
          memoria = calc.memoria
          excede = calc.excedeTetoAdulto
        }
      } catch {
        // mantém a posologia literal
      }
    }

    return {
      drugId: p.drugId,
      nome,
      dose,
      via: p.via,
      intervalo: INTERVALO_LABEL[p.intervalo],
      facultativo: p.facultativo === true,
      ...(p.criterioFacultativo ? { criterioFacultativo: p.criterioFacultativo } : {}),
      ...(memoria ? { memoria } : {}),
      ...(excede ? { excedeTetoAdulto: true } : {}),
      ...(drug?.protocoloExterno ? { protocoloExterno: drug.protocoloExterno } : {}),
      ...(p.tabelaDose ? { tabelaDose: p.tabelaDose } : {}),
      observacoes: p.observacoes ?? [],
      betalactamico: BETALACTAMICOS.has(p.drugId),
    }
  })
}

/** A regra emprega ao menos um betalactâmico? Usado pelo modo ALERGIA. */
export function regraTemBetalactamico(regra: ProtocolRule): boolean {
  return regra.prescricoes.some((p) => BETALACTAMICOS.has(p.drugId))
}
