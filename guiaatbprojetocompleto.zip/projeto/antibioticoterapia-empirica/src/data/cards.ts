import type { SecaoId, Severidade } from '@/domain/types'

/**
 * Conteúdo do guia de bolso, organizado em 16 fichas (cards) — mesma estrutura
 * do guia de antibioticoprofilaxia cirúrgica que serve de referência.
 *
 * As fichas de tabela NÃO duplicam conteúdo clínico: elas apontam para uma
 * seção do protocolo e são renderizadas a partir de `REGRAS_POR_SECAO`, a mesma
 * fonte que alimenta o motor de decisão. Assim, tabela exibida e dose calculada
 * jamais divergem.
 */

export type Bloco =
  | { tipo: 'regras'; titulo: string; itens: readonly ItemRegra[] }
  | { tipo: 'tabela'; titulo: string; secaoId: SecaoId }
  | { tipo: 'lista'; titulo?: string; itens: readonly string[] }
  | { tipo: 'definicoes'; titulo: string; itens: readonly { termo: string; def: string }[] }
  | { tipo: 'alerta'; severidade: Severidade; titulo: string; texto: string; fonte?: string }
  | { tipo: 'calculadora' }
  | { tipo: 'cronometro' }
  | { tipo: 'fluxo' }
  | { tipo: 'renal' }
  | { tipo: 'vancomicina' }
  | { tipo: 'amicacina-neonatal' }
  | { tipo: 'peso-aminoglicosideo' }
  | { tipo: 'doses-pediatricas' }
  | { tipo: 'restritos' }
  | { tipo: 'alergia-focos' }

export interface ItemRegra {
  n: string
  titulo: string
  /** Aceita marcação `**negrito**` e `__destaque azul__`. */
  texto: string
}

export interface GuideCard {
  numero: number
  id: string
  titulo: string
  subtitulo: string
  /** Chip de filtro ao qual a ficha pertence. */
  grupo: GrupoId
  blocos: readonly Bloco[]
  /** Termos extras indexados pela busca (sinônimos, siglas). */
  keywords?: readonly string[]
  /** Ficha aberta por padrão ao carregar o guia. */
  aberta?: boolean
}

export type GrupoId =
  | 'fluxo'
  | 'doses'
  | 'adulto'
  | 'uti-adulto'
  | 'pediatria'
  | 'uti-neoped'
  | 'seguranca'
  | 'referencia'

export const GRUPOS: readonly { id: GrupoId; rotulo: string }[] = [
  { id: 'fluxo', rotulo: 'Fluxo' },
  { id: 'doses', rotulo: 'Doses' },
  { id: 'adulto', rotulo: 'Adulto' },
  { id: 'uti-adulto', rotulo: 'UTI adulto' },
  { id: 'pediatria', rotulo: 'Pediatria' },
  { id: 'uti-neoped', rotulo: 'UTI neo · ped' },
  { id: 'seguranca', rotulo: 'Segurança' },
  { id: 'referencia', rotulo: 'Referência' },
]

export const CARDS: readonly GuideCard[] = [
  // ---------------------------------------------------------------- 01
  {
    numero: 1,
    id: 'fluxo',
    titulo: 'Fluxo em cinco etapas',
    subtitulo: 'Suspeita · culturas · classificação · prescrição · reavaliação',
    grupo: 'fluxo',
    aberta: true,
    keywords: ['fluxograma', 'etapas', 'gestao de infeccoes', 'procedimento'],
    blocos: [{ tipo: 'fluxo' }],
  },

  // ---------------------------------------------------------------- 02
  {
    numero: 2,
    id: 'regras-gerais',
    titulo: 'Quatro regras da terapia empírica',
    subtitulo: 'Timing · culturas · classificação · descalonamento',
    grupo: 'fluxo',
    aberta: true,
    keywords: ['regra', 'timing', 'descalonamento', 'cultura', 'hemocultura'],
    blocos: [
      {
        tipo: 'regras',
        titulo: 'Quatro regras',
        itens: [
          {
            n: '1',
            titulo: 'Culturas antes da primeira dose',
            texto:
              'Colher __hemoculturas (2 pares)__, urocultura e cultura do sítio suspeito ' +
              '**antes** da primeira dose de antimicrobiano. A coleta **não pode** ' +
              'retardar o início da terapia.',
          },
          {
            n: '2',
            titulo: 'Primeira dose em 1–3 horas',
            texto:
              'Prescrever e administrar a primeira dose dentro de __1 a 3 horas__ do ' +
              'reconhecimento da infecção.',
          },
          {
            n: '3',
            titulo: 'Classificar antes de escolher',
            texto:
              'Definir se a infecção é __comunitária ou IRAS__ e identificar o setor. ' +
              'É essa dupla classificação que determina qual tabela do protocolo se aplica — ' +
              'a mesma pneumonia recebe esquemas diferentes na enfermaria e na UTI.',
          },
          {
            n: '4',
            titulo: 'Reavaliar em 48–72 horas',
            texto:
              'Reavaliar resposta clínica e culturas em __48–72 h__ e **descalonar** para ' +
              'o antimicrobiano de menor espectro assim que houver identificação do agente.',
          },
          {
            n: '5',
            titulo: 'Tratar pelo menor tempo possível',
            texto:
              'A duração segue as **melhores práticas** para o sítio e o agente, ajustada ' +
              '**conforme a evolução do paciente**. Tratar sempre pelo __menor tempo ' +
              'possível__: prolongar terapia sem indicação não melhora desfecho e ' +
              'seleciona resistência.',
          },
        ],
      },
    ],
  },

  // ---------------------------------------------------------------- 03
  {
    numero: 3,
    id: 'calculadora',
    titulo: 'Calculadora de dose por peso',
    subtitulo: 'mg/kg/dose · troca sozinha para o esquema pediátrico',
    grupo: 'doses',
    aberta: true,
    keywords: ['peso', 'kg', 'calculo', 'calculadora', 'mg/kg', 'pediatrico', 'dose'],
    blocos: [
      { tipo: 'calculadora' },
      {
        tipo: 'alerta',
        severidade: 'critico',
        titulo: 'Nota ³ — os valores são por administração',
        texto:
          'Nas tabelas pediátricas, mg/kg significa dose POR ADMINISTRAÇÃO (mg/kg/dose), ' +
          'não dose diária. As duas exceções, grafadas "/dia" no protocolo, são ' +
          'Azitromicina 10 mg/kg/dia e Gentamicina 5–7 mg/kg/dia.',
        fonte: 'Nota ³ do protocolo',
      },
    ],
  },

  // ---------------------------------------------------------------- 04
  {
    numero: 4,
    id: 'renal',
    titulo: 'Ajuste por função renal',
    subtitulo: 'CKD-EPI · Cockcroft-Gault · peso ideal e ajustado',
    grupo: 'doses',
    keywords: [
      'renal', 'clearance', 'clcr', 'creatinina', 'ckd-epi', 'ckd epi', 'cockcroft',
      'gault', 'tfg', 'dialise', 'hemodialise', 'hd', 'peso ideal', 'peso ajustado',
      'devine', 'ajuste de dose', 'injuria renal', 'ira',
    ],
    blocos: [
      { tipo: 'renal' },
      {
        tipo: 'alerta',
        severidade: 'info',
        titulo: 'Fonte das faixas',
        texto:
          'As faixas de ajuste vêm da tabela institucional de ajuste de antimicrobianos ' +
          '(SCIH e Farmácia Clínica), restritas aos fármacos que este protocolo prescreve. ' +
          'A Vancomicina tem tabela própria — ver a ficha 13.',
      },
    ],
  },

  // ---------------------------------------------------------------- 05
  {
    numero: 5,
    id: 'dose-ataque',
    titulo: 'Dose de ataque',
    subtitulo: 'Quando fazer, por que e em quais fármacos',
    grupo: 'doses',
    keywords: ['ataque', 'dose de ataque', 'bolus', 'loading', 'da', 'concentracao'],
    blocos: [
      {
        tipo: 'alerta',
        severidade: 'info',
        titulo: 'O que é',
        texto:
          'Estratégia terapêutica para iniciar o tratamento de infecções ou condições ' +
          'agudas com uma dose inicial mais alta, em bolus, geralmente a dose máxima da ' +
          'medicação, mantida por até 24–48 h. O objetivo é alcançar rapidamente uma ' +
          'concentração eficaz do fármaco no organismo, controlando a infecção ou o ' +
          'processo inflamatório de forma mais eficiente.',
      },
      {
        tipo: 'regras',
        titulo: 'Doses de ataque previstas',
        itens: [
          {
            n: '1',
            titulo: 'Vancomicina — adulto',
            texto:
              '__25 a 30 mg/kg de peso real__, máximo **2 g**, independente da função ' +
              'renal. Em neonatologia e pediatria **não se faz** dose de ataque.',
          },
          {
            n: '2',
            titulo: 'Piperacilina/tazobactam',
            texto: '__4,5 g 6/6h por 24 h__; depois ajustar conforme o ClCr.',
          },
          {
            n: '3',
            titulo: 'Meropenem',
            texto:
              '__2 g 8/8h por 24 h__; depois ajustar conforme o ClCr. Infusão em 3 h — ' +
              'mas a **primeira dose** deve ser infundida rapidamente, em 3–5 min.',
          },
          {
            n: '4',
            titulo: 'Aminoglicosídeos',
            texto:
              'Gentamicina __5 mg/kg__ e amicacina __15 mg/kg__, em dose única, com ' +
              '**peso ajustado**; depois ajustar conforme o ClCr.',
          },
          {
            n: '5',
            titulo: 'Metronidazol',
            texto: 'Em infecções graves, __15 mg/kg__ em dose única.',
          },
        ],
      },
      {
        tipo: 'alerta',
        severidade: 'atencao',
        titulo: 'A dose de ataque não é ajustada pela função renal',
        texto:
          'O ataque visa encher o compartimento de distribuição, que depende do peso e ' +
          'não da depuração. O ajuste renal incide sobre a MANUTENÇÃO. Reduzir o ataque ' +
          'no paciente com injúria renal atrasa a concentração eficaz sem reduzir risco.',
      },
    ],
  },

  // ---------------------------------------------------------------- 06
  {
    numero: 6,
    id: 'cronometro',
    titulo: 'Cronômetro de janelas',
    subtitulo: 'Primeira dose em 1–3 h · reavaliação em 48–72 h',
    grupo: 'doses',
    keywords: ['cronometro', 'timer', 'relogio', 'janela', 'reavaliacao', '48h', '72h'],
    blocos: [
      { tipo: 'cronometro' },
      {
        tipo: 'alerta',
        severidade: 'info',
        titulo: 'Como funciona',
        texto:
          'Marque o horário da suspeita clínica para acompanhar a janela de 1–3 h da ' +
          'primeira dose; marque o horário da primeira dose para acompanhar a janela de ' +
          'reavaliação de 48–72 h. Os horários ficam salvos no próprio aparelho e ' +
          'sobrevivem ao fechamento do app.',
      },
    ],
  },

  // ---------------------------------------------------------------- 07
  {
    numero: 7,
    id: 'secao-6-1',
    titulo: '6.1 · Comunitária — Adulto',
    subtitulo: 'Pneumonia · ITU · abdominal · pele · sepse · meningite · endocardite · osso',
    grupo: 'adulto',
    keywords: [
      'comunitaria', 'adulto', 'ceftriaxona', 'azitromicina', 'cefepime', 'clindamicina',
      'piperacilina', 'tazobactam', 'metronidazol', 'ciprofloxacino', 'oxacilina',
      'gentamicina', 'vancomicina', 'pneumonia', 'itu', 'abdominal', 'necrose', 'sepse',
      'meningite', 'endocardite', 'osteoarticular', 'artrite', 'osteomielite',
    ],
    blocos: [{ tipo: 'tabela', titulo: '6.1 Infecções comunitárias — Adulto', secaoId: '6.1' }],
  },

  // ---------------------------------------------------------------- 08
  {
    numero: 8,
    id: 'secao-6-2',
    titulo: '6.2 · IRAS — Enfermaria adulto',
    subtitulo: 'Pneumonia hospitalar · ITU · IPCS · prótese · ISC',
    grupo: 'adulto',
    keywords: [
      'iras', 'enfermaria', 'adulto', 'hospitalar', 'tazocin', 'piperacilina', 'cefepime',
      'vancomicina', 'ipcs', 'protese', 'isc', 'sitio cirurgico', 'aspirativa', 'uco',
    ],
    blocos: [{ tipo: 'tabela', titulo: '6.2 IRAS — Enfermaria adulto', secaoId: '6.2' }],
  },

  // ---------------------------------------------------------------- 09
  {
    numero: 9,
    id: 'secao-6-5',
    titulo: '6.5 · IRAS — UTI adulto',
    subtitulo: 'PNAV · PAV precoce e tardia · ITU · IPCS · TGI · sepse',
    grupo: 'uti-adulto',
    keywords: [
      'uti', 'adulto', 'iras', 'pav', 'pnav', 'ventilacao', 'meropenem', 'cefepime',
      'piperacilina', 'tazobactam', 'vancomicina', 'cvc', 'cateter', 'tgi', 'sepse',
      'enterococcus', 'anaerobio', 'precoce', 'tardia',
    ],
    blocos: [
      { tipo: 'tabela', titulo: '6.5 IRAS — UTI adulto', secaoId: '6.5' },
      {
        tipo: 'alerta',
        severidade: 'info',
        titulo: 'Limiar da PAV',
        texto:
          'PAV precoce: menos de 5 dias de ventilação mecânica. PAV tardia: 5 dias ou ' +
          'mais — o quinto dia já recebe Meropenem.',
      },
    ],
  },

  // ---------------------------------------------------------------- 10
  {
    numero: 10,
    id: 'secao-6-3',
    titulo: '6.3 · Comunitária — Pediatria',
    subtitulo: 'Doses em mg/kg/dose · pneumonia · ITU · abdominal · meningite',
    grupo: 'pediatria',
    keywords: [
      'pediatria', 'crianca', 'comunitaria', 'mg/kg', 'ceftriaxona', 'azitromicina',
      'clindamicina', 'ampicilina', 'gentamicina', 'metronidazol', 'oxacilina',
      'piperacilina', 'meningite', 'pneumonia', 'itu', 'sepse', 'endocardite',
    ],
    blocos: [{ tipo: 'tabela', titulo: '6.3 Infecções comunitárias — Pediatria', secaoId: '6.3' }],
  },

  // ---------------------------------------------------------------- 11
  {
    numero: 11,
    id: 'secao-6-4',
    titulo: '6.4 · IRAS — Enfermaria pediátrica',
    subtitulo: 'Pneumonia · ITU · IPCS com e sem dispositivo · ISC',
    grupo: 'pediatria',
    keywords: [
      'pediatria', 'iras', 'enfermaria', 'cefepime', 'piperacilina', 'tazobactam',
      'vancomicina', 'ipcs', 'cateter', 'isc', 'aspirativa',
    ],
    blocos: [{ tipo: 'tabela', titulo: '6.4 IRAS — Enfermaria pediátrica', secaoId: '6.4' }],
  },

  // ---------------------------------------------------------------- 12
  {
    numero: 12,
    id: 'secao-6-6',
    titulo: '6.6 · IRAS — UTI neonatal e pediátrica',
    subtitulo: 'Linhas neonatal × > 28 dias · amicacina neonatal · peso do aminoglicosídeo',
    grupo: 'uti-neoped',
    keywords: [
      'neonatal', 'neonato', 'rn', 'recem-nascido', 'uti', 'pediatrica', 'meropenem',
      'amicacina', 'ampicilina', 'gentamicina', 'oxacilina', 'cefepime', 'vancomicina',
      'sepse neonatal', 'precoce', 'tardia', 'pav', 'ipcs', 'cateter', 'tgi', '28 dias',
      'idade gestacional', 'ig', 'prematuro', 'semanas', 'idade de vida',
      'peso ajustado', 'peso ideal', 'devine', 'aminoglicosideo', 'aminoglicosídeo',
      'obeso', 'obesidade', 'calcular peso',
    ],
    blocos: [
      { tipo: 'tabela', titulo: '6.6 IRAS — UTI neonatal e pediátrica', secaoId: '6.6' },
      { tipo: 'amicacina-neonatal' },
      // O cálculo do peso de referência vive AQUI, junto do aminoglicosídeo que
      // o exige, em vez de numa ficha própria: quem está prescrevendo amicacina
      // ou gentamicina precisa do peso ajustado na mesma tela, não a dois toques.
      { tipo: 'peso-aminoglicosideo' },
      {
        tipo: 'alerta',
        severidade: 'critico',
        titulo: 'Por que não usar o peso real no aminoglicosídeo',
        texto:
          'Aminoglicosídeo se distribui mal no tecido adiposo. Calcular sobre o peso ' +
          'real no paciente obeso entrega dose acima do necessário e aumenta o risco de ' +
          'nefro e ototoxicidade; calcular sobre o ideal subdosa. O peso ajustado é o ' +
          'meio-termo que a tabela institucional exige.',
      },
      {
        tipo: 'alerta',
        severidade: 'atencao',
        titulo: 'Linha de sepse duplicada no documento',
        texto:
          'A tabela 6.6 do PDF repete integralmente o par "Sepse s/ foco — 1ª opção / ' +
          '2ª opção". O app consolida em um único par. Se a intenção era diferenciar ' +
          'neonatal de > 28 dias, a segunda linha precisa ser corrigida no protocolo.',
        fonte: 'Ambiguidade A-08',
      },
    ],
  },

  // ---------------------------------------------------------------- 13
  {
    numero: 13,
    id: 'vancomicina',
    titulo: 'Vancomicina e vancocinemia',
    subtitulo: 'Ataque · manutenção por clearance · correção por nível sérico',
    grupo: 'seguranca',
    keywords: [
      'vancomicina', 'glicopeptideo', 'nota 1', 'vancocinemia', 'nivel serico', 'vale',
      'ataque', 'mrsa', 'hemodialise', 'hd', 'creatinina', 'neonatal', 'snc',
    ],
    blocos: [
      { tipo: 'vancomicina' },
      {
        tipo: 'lista',
        titulo: 'Esquemas do protocolo empírico que incluem Vancomicina',
        itens: [
          '6.1 Meningite bacteriana (facultativa, conforme nota ²)',
          '6.2 IPCS · Infecção de prótese · ISC',
          '6.3 Meningite bacteriana (associar em < 5 anos, nota ⁴)',
          '6.4 IPCS associada a cateter · ISC',
          '6.5 IPCS associada a CVC · ISC · Sepse sem foco',
          '6.6 PNM não associada a VM · PAV · IPCS associada a cateter · ISC · Sepse',
        ],
      },
    ],
  },

  // ---------------------------------------------------------------- 14
  {
    numero: 14,
    id: 'meningite-notas',
    titulo: 'Meningite — notas ² e ⁴',
    subtitulo: 'Quando a Vancomicina deixa de ser opcional',
    grupo: 'seguranca',
    keywords: ['meningite', 'nota 2', 'nota 4', 'pneumococo', 'pneumoniae', '19a', 'vancomicina'],
    blocos: [
      {
        tipo: 'regras',
        titulo: 'Duas regras distintas',
        itens: [
          {
            n: 'A',
            titulo: 'Adulto — nota ² (facultativa)',
            texto:
              'Considerar **associar Vancomicina** à Ceftriaxona na suspeita de meningite ' +
              'pneumocócica se houver __quadro grave__, __uso de betalactâmico nos últimos ' +
              '3 meses__ ou __resistência local documentada__ pela vigilância epidemiológica.',
          },
          {
            n: 'B',
            titulo: 'Pediatria — nota ⁴ (imperativa)',
            texto:
              'Em menores de 5 anos, **associar Vancomicina** ao tratamento empírico inicial ' +
              'devido à alta prevalência de resistência do S. pneumoniae à ceftriaxona ' +
              '(sorotipo 19A, __> 95% de resistência__ em meningites). Suspender **apenas** ' +
              'após confirmação laboratorial de sensibilidade.',
          },
        ],
      },
      {
        tipo: 'regras',
        titulo: 'Dexametasona adjuvante',
        itens: [
          {
            n: 'C',
            titulo: 'Dose',
            texto:
              'Adulto __10 mg/dose EV a cada 6 h__. Pediatria __0,15 mg/kg/dose EV a ' +
              'cada 6 h__. Duração de **4 dias**.',
          },
          {
            n: 'D',
            titulo: 'Momento — é o que define o benefício',
            texto:
              'Administrar de __10 a 20 minutos ANTES__ da primeira dose do ' +
              'antibiótico, ou **junto com ela**. Iniciada depois, perde o efeito. ' +
              'E o corticoide **não pode atrasar** a primeira dose do antimicrobiano.',
          },
        ],
      },
    ],
  },

  // ---------------------------------------------------------------- 15
  {
    numero: 15,
    id: 'alergia',
    titulo: 'Alergia a betalactâmicos',
    subtitulo: 'Estratificar a reação · substitutos por foco',
    grupo: 'seguranca',
    keywords: [
      'alergia', 'penicilina', 'betalactamico', 'anafilaxia', 'substituicao',
      'substituto', 'alternativa', 'reacao', 'exantema', 'stevens', 'dress',
      'aztreonam', 'levofloxacino', 'linezolida', 'vancomicina',
    ],
    blocos: [
      {
        tipo: 'alerta',
        severidade: 'critico',
        titulo: 'Proposta — depende de aprovação do SCIH',
        texto:
          'O protocolo institucional não descreve esquema substituto. Os quadros ' +
          'abaixo são uma PROPOSTA construída a partir de literatura publicada, para ' +
          'discussão e aprovação. Enquanto não houver aprovação formal, a conduta no ' +
          'paciente alérgico deve ser individualizada com o SCIH ou a Infectologia.',
      },
      {
        tipo: 'regras',
        titulo: 'Primeiro passo — estratificar a reação',
        itens: [
          {
            n: '1',
            titulo: 'A maioria dos rótulos de alergia não se confirma',
            texto:
              'Cerca de **90%** de quem se diz alérgico a penicilina tolera o fármaco ' +
              'quando testado. Rótulo não confirmado leva a espectro mais largo, pior ' +
              'desfecho e mais resistência. **Investigar vale mais que substituir.**',
          },
          {
            n: '2',
            titulo: 'Reação leve e tardia',
            texto:
              'Exantema maculopapular tardio, sem urticária nem sinal sistêmico. ' +
              '__Cefalosporinas e carbapenêmicos podem ser usados__ — a ' +
              'reatividade cruzada clinicamente relevante entre penicilinas e outros ' +
              'betalactâmicos é baixa e depende da cadeia lateral, não do anel.',
          },
          {
            n: '3',
            titulo: 'Reação imediata / IgE-mediada',
            texto:
              'Anafilaxia, urticária, broncoespasmo, hipotensão, em até 1 h. Evitar o ' +
              'fármaco e os que compartilham cadeia lateral. __Aztreonam é seguro__ ' +
              '(exceto se a reação foi a ceftazidima, com quem compartilha cadeia).',
          },
          {
            n: '4',
            titulo: 'Reação grave não IgE',
            texto:
              'Stevens-Johnson, NET, DRESS, AGEP, anemia hemolítica, nefrite. ' +
              '**Evitar TODOS os betalactâmicos** — penicilinas, cefalosporinas e ' +
              'carbapenêmicos. Não dessensibilizar.',
          },
        ],
      },
      {
        tipo: 'regras',
        titulo: 'Como escolher o substituto',
        itens: [
          {
            n: 'A',
            titulo: 'Gram-negativo',
            texto:
              '__Aztreonam__ (monobactâmico, sem reatividade cruzada relevante — exceto ' +
              'reação prévia a ceftazidima) ou __ciprofloxacino/levofloxacino__.',
          },
          {
            n: 'B',
            titulo: 'Gram-positivo',
            texto:
              '__Vancomicina__ para MRSA/MSSA. Alternativas: __linezolida__ ou ' +
              '__daptomicina__ — daptomicina **não em pneumonia** (inativada pelo surfactante).',
          },
          {
            n: 'C',
            titulo: 'Anaeróbios',
            texto: '__Metronidazol__ ou __clindamicina__ — nenhum é betalactâmico.',
          },
        ],
      },
      {
        tipo: 'alerta',
        severidade: 'atencao',
        titulo: 'Proposta de alternativa por foco',
        texto:
          'Abaixo, uma alternativa sem betalactâmico para CADA foco do protocolo. Os ' +
          'focos marcados “sem bom substituto” são aqueles em que a troca fica frágil e ' +
          'a Infectologia deve ser acionada — não há esquema não betalactâmico satisfatório.',
      },
      { tipo: 'alergia-focos' },
      {
        tipo: 'lista',
        titulo: 'Esquemas do protocolo que já são isentos de betalactâmico',
        itens: [
          '6.1 Infecção óssea/articular — Ciprofloxacino + Clindamicina',
          '6.1 Infecção abdominal, 2ª opção — Ciprofloxacino + Metronidazol',
          'Componentes isolados: Clindamicina, Metronidazol, Ciprofloxacino, ' +
            'Azitromicina, Gentamicina, Amicacina e Vancomicina',
        ],
      },
      {
        tipo: 'alerta',
        severidade: 'atencao',
        titulo: 'O que esta proposta não resolve',
        texto:
          'Substituto não é equivalente: fluoroquinolona tem mais efeito adverso e ' +
          'seleciona resistência mais rápido; linezolida e daptomicina são de uso ' +
          'restrito. Confirmar o rótulo de alergia continua sendo a melhor conduta.',
      },
      {
        tipo: 'lista',
        titulo: 'Fontes desta proposta',
        itens: [
          'Clinical pathway de alergia a betalactâmicos — Children\'s Hospital of Philadelphia.',
          'Suspected allergy to beta-lactam antibiotics: an infectiological perspective.',
          'Assessment of the safety of alternative antibiotics in children with ' +
            'confirmed beta-lactam allergy.',
        ],
      },
    ],
  },

  // ---------------------------------------------------------------- 16
  {
    numero: 16,
    id: 'restritos',
    titulo: 'Antimicrobianos restritos',
    subtitulo: 'Só com cultura · formulário e notificação ao SCIH',
    grupo: 'seguranca',
    keywords: [
      'restrito', 'meropenem', 'formulario', 'notificacao', 'scih', 'carbapenemico',
      'ceftazidima', 'avibactam', 'torgena', 'ceftolozana', 'zerbaxa', 'linezolida',
      'vre', 'anfotericina', 'lipossomal', 'voriconazol', 'ampicilina', 'sulbactam',
      'unasyn', 'acinetobacter', 'cultura',
    ],
    blocos: [
      {
        tipo: 'alerta',
        severidade: 'critico',
        titulo: 'Não liberar empiricamente',
        texto:
          'Os agentes abaixo são a reserva do hospital: liberados apenas COM ' +
          'identificação microbiológica, nunca na suspeita. Meropenem é restrito num ' +
          'nível mais brando — pode entrar no empírico com formulário e notificação.',
      },
      { tipo: 'restritos' },
      {
        tipo: 'lista',
        titulo: 'Materiais necessários (item 4 do protocolo)',
        itens: [
          'Relatório de Microbiologia Institucional (IRAS) vigente — atualizado anualmente',
          'Formulário de solicitação de antimicrobianos restritos, quando aplicável',
          'Kit de coleta: hemoculturas (2 pares), urocultura, cultura de secreção traqueal',
          'Prontuário eletrônico ou físico para registro e reavaliação',
          'Ficha de notificação ao SCIH para antimicrobianos de uso restrito',
        ],
      },
      {
        tipo: 'alerta',
        severidade: 'atencao',
        titulo: 'Meropenem exige notificação',
        texto:
          'O carbapenêmico aparece em PAV tardia (> 5 dias), ITU associada a cateter ' +
          'vesical na UTI adulto e PAV em UTI neonatal/pediátrica. Preencher o formulário ' +
          'e notificar o SCIH.',
        fonte: 'Item 4 do protocolo',
      },
    ],
  },

  // ---------------------------------------------------------------- 17
  {
    numero: 17,
    id: 'definicoes',
    titulo: 'Termos e definições',
    subtitulo: 'Siglas usadas nas tabelas',
    grupo: 'referencia',
    keywords: ['sigla', 'definicao', 'glossario', 'iras', 'ipcs', 'pav', 'pnav', 'itu'],
    blocos: [
      {
        tipo: 'definicoes',
        titulo: 'Glossário',
        itens: [
          { termo: 'SCIH', def: 'Serviço de Controle de Infecção Hospitalar.' },
          { termo: 'IRAS', def: 'Infecções Relacionadas à Assistência à Saúde.' },
          { termo: 'ATB', def: 'Antibiótico / antimicrobiano.' },
          { termo: 'IPCS', def: 'Infecção Primária de Corrente Sanguínea.' },
          { termo: 'ICS-CVC', def: 'Infecção de corrente sanguínea associada a cateter venoso central.' },
          { termo: 'ISC', def: 'Infecção de Sítio Cirúrgico.' },
          { termo: 'ITU / ITU-CVD', def: 'Infecção do trato urinário / associada a cateter vesical de demora.' },
          { termo: 'PNAV', def: 'Pneumonia não associada à ventilação mecânica.' },
          { termo: 'PAV', def: 'Pneumonia associada à ventilação mecânica.' },
          { termo: 'TQT', def: 'Traqueostomia.' },
          {
            termo: 'Terapia empírica',
            def: 'Antimicrobiano iniciado antes da identificação do agente etiológico, ' +
              'baseado no perfil epidemiológico local e no sítio de infecção.',
          },
          {
            termo: 'Descalonamento',
            def: 'Adequação da terapia para antimicrobiano de menor espectro após o ' +
              'resultado das culturas.',
          },
          { termo: 'DA', def: 'Dose de ataque — dose inicial mais elevada para atingir rapidamente níveis terapêuticos.' },
          { termo: 'SONIH', def: 'Sistema Online de Notificação de Infecções Hospitalares do Paraná.' },
          { termo: 'BEPA', def: 'Boletim Epidemiológico Paulista.' },
          { termo: 'EV', def: 'Via endovenosa.' },
        ],
      },
    ],
  },

  // ---------------------------------------------------------------- 18
  {
    numero: 18,
    id: 'referencias',
    titulo: 'Validade e referências',
    subtitulo: 'Versão 20/03/2026 · válida até 20/03/2028',
    grupo: 'referencia',
    keywords: ['referencia', 'bibliografia', 'anvisa', 'sonih', 'bepa', 'sireva', 'validade'],
    blocos: [
      {
        tipo: 'lista',
        titulo: 'Aplicação (item 2)',
        itens: [
          'UTI adulto e Unidade Coronariana (UCO)',
          'Enfermarias adulto — clínicas e cirúrgicas',
          'UTI neonatal e pediátrica; UCI neonatal',
          'Enfermaria pediátrica',
          'Pronto-Socorro adulto e pediátrico',
        ],
      },
      {
        tipo: 'lista',
        titulo: 'Referências bibliográficas',
        itens: [
          'BRASIL. ANVISA. Programa Nacional de Prevenção e Controle de Infecções ' +
            'Relacionadas à Assistência à Saúde (PNPCIRAS) 2021–2025. Brasília, 2021.',
          'PARANÁ. Secretaria de Estado da Saúde. Boletim Epidemiológico SONIH. Curitiba, 2025.',
          'SÃO PAULO. Secretaria de Estado da Saúde. BEPA — Boletim Epidemiológico ' +
            'Paulista. Centro de Vigilância Epidemiológica, 2025.',
          'SÃO PAULO. Instituto Adolfo Lutz. SIREVA 2025: informação da vigilância das ' +
            'pneumonias e meningites bacterianas. São Paulo: IAL, 2025. 42 p.',
        ],
      },
      {
        tipo: 'alerta',
        severidade: 'info',
        titulo: 'Guia de consulta rápida',
        texto:
          'Este aplicativo reproduz o protocolo do SCIH na versão de 20/03/2026, ' +
          'válida até 20/03/2028. Em qualquer divergência, prevalece o protocolo ' +
          'institucional na íntegra. Erros ou lacunas devem ser comunicados ao SCIH.',
      },
    ],
  },

  // ---------------------------------------------------------------- 19
  {
    numero: 19,
    id: 'revisao-documento',
    titulo: 'Pontos para a próxima revisão',
    subtitulo: 'O que já foi resolvido, o que é proposta e o que segue em aberto',
    grupo: 'referencia',
    keywords: [
      'revisao', 'erro', 'digitacao', 'typo', 'inconsistencia', 'lacuna',
      'ambiguidade', 'corrigir', 'pendencia',
    ],
    blocos: [
      {
        tipo: 'alerta',
        severidade: 'info',
        titulo: 'Para que serve esta ficha',
        texto:
          'Levantamento dos pontos do documento que precisam de correção ou definição. ' +
          'Não altera conduta: serve de pauta para a revisão do protocolo. Cada item ' +
          'aparece sinalizado também no ponto do guia onde é relevante. Os itens ' +
          'marcados como RESOLVIDOS já estão aplicados no guia e aguardam apenas ' +
          'transcrição para o documento controlado.',
      },
      {
        tipo: 'regras',
        titulo: 'Resolvido — aplicar ao documento na próxima revisão',
        itens: [
          {
            n: '1',
            titulo: 'Nota ⁴ — corte etário · RESOLVIDO',
            texto:
              'Corte definido: **< 5 anos** associa Vancomicina; **≥ 5 anos** segue a ' +
              'nota ² do adulto.',
          },
          {
            n: '2',
            titulo: 'Nota ⁴ — nome da espécie · RESOLVIDO',
            texto:
              'Grafado "S. pneumonia e". Corrigido para *S. pneumoniae*, em itálico, ' +
              'como manda a nomenclatura binomial.',
          },
          {
            n: '4',
            titulo: 'Item 6.1 — via ausente · RESOLVIDO',
            texto:
              'Pele com necrose grafava "Ceftriaxona 2g/dia", sem a via. Definido ' +
              '__EV__, como nas demais linhas da tabela.',
          },
          {
            n: '5',
            titulo: 'Item 6.3 — célula vazia · RESOLVIDO',
            texto:
              'A linha de endocardite pediátrica não tinha a coluna CONDIÇÃO ' +
              'preenchida. Lida como __Aguda__, em paralelo com a linha do adulto.',
          },
          {
            n: '19',
            titulo: 'Piperacilina pediátrica (6.6) · RESOLVIDO',
            texto:
              'Mantida uma única dose: __75 a 100 mg/kg de piperacilina a cada 6 h__ ' +
              '(300 a 400 mg/kg/dia). O mg/kg incide **apenas sobre a piperacilina** — ' +
              'a proporção com tazobactam é 8:1.',
          },
          {
            n: '6',
            titulo: 'Cefepime — dose uniformizada · RESOLVIDO',
            texto:
              'Padronizado __1–2 g__ em todas as seções. Usar **2 g** em Pseudomonas, ' +
              'meningite, neutropenia febril e sepse/choque séptico; 1 g nas demais.',
          },
          {
            n: '7',
            titulo: 'Nomenclatura da piperacilina · RESOLVIDO',
            texto:
              'O nome comercial foi substituído pelo princípio ativo ' +
              '__Piperacilina/tazobactam__ em todo o texto exibido. Nomes comerciais ' +
              'permanecem apenas como sinônimo de busca.',
          },
          {
            n: '8',
            titulo: 'Intervalo da piperacilina · RESOLVIDO',
            texto:
              'A cada __6 h__ em sepse, choque séptico, infecção abdominal e ' +
              'Pseudomonas. A cada __8 h__ nas infecções não graves.',
          },
          {
            n: '9',
            titulo: 'Gentamicina na endocardite · RESOLVIDO',
            texto:
              'O documento traz __5–7 mg/kg 24/24h__, que é dose plena. Na endocardite ' +
              'a gentamicina entra como **sinergismo**: __1 mg/kg a cada 8 h__.',
          },
          {
            n: '10',
            titulo: 'Amicacina no neonato · RESOLVIDO',
            texto:
              'O documento traz __5–7 mg/kg até 8/8h__, que não discrimina maturidade ' +
              'renal. **Substituído** pela tabela por idade gestacional e pós-natal, ' +
              'na ficha de amicacina neonatal deste guia.',
          },
          {
            n: '11',
            titulo: 'PAV no quinto dia · RESOLVIDO',
            texto:
              'Limiar da PAV tardia definido como __≥ 5 dias__ de ventilação — o quinto ' +
              'dia já conta como tardia.',
          },
          {
            n: '12',
            titulo: 'UCO, Unidade Neurológica e ISC · RESOLVIDO',
            texto:
              'A __UCO__ e a __Unidade Neurológica__ seguem a tabela de UTI adulto. ' +
              'A ISC na UTI adulto adota o esquema da __enfermaria__.',
          },
          {
            n: '13',
            titulo: 'Critério de adulto e duração · RESOLVIDO',
            texto:
              'Adulto é __≥ 12 anos ou > 40 kg__. Duração pelas melhores práticas, ' +
              'conforme evolução, no __menor tempo possível__.',
          },
          {
            n: '16',
            titulo: 'Teto de dose · RESOLVIDO',
            texto:
              'Teto **diário** declarado por fármaco no catálogo do guia. Quando a dose ' +
              'por peso ultrapassa o teto ou a maior dose adulta do protocolo, o app ' +
              'avisa — **nunca corta a dose sozinho**.',
          },
          {
            n: '17',
            titulo: 'Azitromicina e função renal · RESOLVIDO',
            texto:
              'A ausência na tabela de ajuste **não é um esquecimento**: a eliminação é ' +
              'predominantemente biliar e a azitromicina __não requer ajuste__ por ' +
              'função renal. Registrada como tal na ficha de ajuste renal.',
          },
          {
            n: '18',
            titulo: 'Fórmula de peso ideal · RESOLVIDO',
            texto:
              'A tabela de ajuste exige "peso ideal" sem dizer qual fórmula. ' +
              '__Devine__ adotada como **padrão institucional** — é a convenção sobre a ' +
              'qual as faixas de aminoglicosídeo foram derivadas.',
          },
        ],
      },
      {
        tipo: 'regras',
        titulo: 'Proposta construída pelo guia — depende de aprovação do SCIH',
        itens: [
          {
            n: '14',
            titulo: 'Alergia a betalactâmicos',
            texto:
              'O protocolo não descreve esquema substituto, embora quase todo ele seja ' +
              'betalactâmico. A ficha de alergia agora traz uma **proposta com ' +
              'alternativa para CADA foco**, além da estratificação por tipo de reação. ' +
              'Os focos sem bom substituto (meningite, PAV, sepse, prótese) ficam ' +
              'sinalizados. **Precisa ser aprovada antes de virar conduta institucional.**',
          },
          {
            n: '15',
            titulo: 'Critério do "+/- Azitromicina"',
            texto:
              'A associação é facultativa na pneumonia comunitária e o protocolo não dá ' +
              'critério. O guia passou a exibir um critério **proposto** — pneumonia ' +
              'grave e suspeita de atípico, com recorte etário na pediatria — a partir ' +
              'de ATS/IDSA e PIDS/IDSA. **Sujeito a aprovação.**',
          },
        ],
      },
      {
        tipo: 'regras',
        titulo: 'Ainda sem definição',
        itens: [
          {
            n: '3',
            titulo: 'Item 6.6 — bloco duplicado',
            texto:
              'O par "Sepse s/ foco — 1ª opção / 2ª opção" aparece **duas vezes, ' +
              'idêntico**. O guia consolida em um par. Se a intenção era separar ' +
              'neonatal de > 28 dias, a segunda ocorrência **precisa ser reescrita** ' +
              'no documento — o guia não tem como adivinhar a diferença pretendida.',
          },
          {
            n: '20',
            titulo: 'Cefepime neonatal — 50 vs 30 mg/kg',
            texto:
              'Toda a seção 6.6 grafa __Cefepime 50 mg/kg 8/8h__ (150 mg/kg/dia), que é ' +
              'a dose pediátrica geral. O quadro institucional traz __30 mg/kg 12/12h__ ' +
              '(60 mg/kg/dia) no neonato — **2,5 vezes menos**. As linhas de PNM não ' +
              'associada a VM e de sepse não filtram idade, então o recém-nascido ' +
              'alcança a dose maior. **Definir qual vale**: a de 50 mg/kg reserva-se a ' +
              'meningite e *Pseudomonas*. As quatro linhas trazem a ressalva.',
          },
          {
            n: '26',
            titulo: 'Piperacilina no recém-nascido — fora da bula',
            texto:
              'As linhas de ITU, TGI e sepse 2ª opção da 6.6 dosam __75 a 100 mg/kg a ' +
              'cada 6 h__ sem filtrar idade, numa seção de UTI neonatal. A bula do ' +
              'produto **começa aos 2 meses** e o quadro institucional prevê no máximo ' +
              '__300 mg/kg/dia__ no neonato, **sem intervalo de 6/6h**. Definir a ' +
              'conduta para ≤ 28 dias.',
          },
          {
            n: '21',
            titulo: 'Amicacina neonatal — duas fontes',
            texto:
              'A ficha de amicacina neonatal (por idade gestacional/pós-natal) e o ' +
              'quadro pediátrico (por peso corpóreo/idade pós-natal) **não coincidem**. ' +
              'Definir qual é a referência institucional.',
          },
          {
            n: '22',
            titulo: 'Eritromicina — grafia do quadro',
            texto:
              'O quadro pediátrico grafa __12,5 mg/kg/dia – 6/6h__, incoerente (a dose ' +
              'usual é ~40 mg/kg/dia). Provável erro de digitação — **conferir** antes ' +
              'de padronizar. Sinalizado na ficha de doses pediátricas.',
          },
          {
            n: '23',
            titulo: 'Metronidazol — /dose ou /dia?',
            texto:
              '**A divergência mais relevante entre os dois documentos.** O quadro ' +
              'pediátrico grafa __15–30 mg/kg/dose 8/8h__ (45–90 mg/kg/dia), acima da ' +
              'faixa usual. O protocolo empírico prescreve __5–10 mg/kg/dose 6/6h__ ' +
              '(20–40 mg/kg/dia), que é a consagrada. Se o quadro quis dizer ' +
              '15–30 mg/kg/**dia**, os dois passam a coincidir. **Definir.**',
          },
          {
            n: '24',
            titulo: 'Oxacilina — faixas diferentes, ambas válidas',
            texto:
              'Quadro: __12,5–25 mg/kg/dose__ (50–100 mg/kg/dia, infecção leve a ' +
              'moderada). Protocolo: __50 mg/kg/dose__ (200 mg/kg/dia, infecção grave). ' +
              'Não é erro — são faixas de gravidades distintas, e os focos em que o ' +
              'protocolo indica oxacilina são graves. Vale **explicitar o critério**.',
          },
          {
            n: '25',
            titulo: 'Meropenem e clindamicina — extremos da faixa',
            texto:
              'O protocolo fixa meropenem em __20 mg/kg/dose__ (o quadro admite até 40, ' +
              'usado em meningite/*Pseudomonas*) e clindamicina em __5–10 mg/kg/dose__ ' +
              '(o quadro fixa 10; 5 mg/kg/dose fica abaixo da faixa usual). Revisar se ' +
              'o extremo inferior é intencional.',
          },
        ],
      },
    ],
  },

  // ---------------------------------------------------------------- 20
  {
    numero: 20,
    id: 'doses-pediatricas',
    titulo: 'Doses e diluições pediátricas',
    subtitulo: 'Por clearance e por idade neonatal · base Sanford',
    grupo: 'pediatria',
    keywords: [
      'dose', 'diluicao', 'pediatria', 'neonatal', 'clearance', 'sanford', 'infusao',
      'ajuste renal pediatrico', 'mg/kg', 'frasco', 'concentracao',
    ],
    blocos: [
      {
        tipo: 'alerta',
        severidade: 'info',
        titulo: 'Padronização das doses pediátricas',
        texto:
          'Quadro de doses e diluições da UTI Pediátrica do HU de Londrina, de base ' +
          'Sanford (45ª ed.), Nelson e Red Book. É a fonte da DOSE de cada droga por ' +
          'clearance e por idade neonatal — o protocolo empírico continua definindo ' +
          'QUAL droga usar em cada foco. Onde os dois divergem, o ponto é sinalizado.',
      },
      { tipo: 'doses-pediatricas' },
    ],
  },
]
