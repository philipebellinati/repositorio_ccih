# Manutenção do guia — como corrigir doses, regras e estrutura

Este documento é para quem vai manter o conteúdo clínico. Não exige saber
programar: **quase tudo é editar um número ou um texto dentro de `src/data/`.**

A regra de ouro do projeto: **o protocolo é dado, não código.** As tabelas que
aparecem na tela e as doses que a calculadora produz saem do mesmo arquivo — não
existe um lugar "de exibição" e outro "de cálculo" que possam divergir.

---

## Preparar o ambiente (uma vez só)

```bash
# 1. Instalar o Node.js 20 ou superior: https://nodejs.org
# 2. Dentro da pasta do projeto:
npm install
```

Ciclo de trabalho:

```bash
npm run dev     # abre em http://localhost:5173 e recarrega ao salvar
npm test        # 101 testes — RODE SEMPRE antes de publicar
npm run build   # gera a pasta dist/ para publicar
npm run build:single   # gera um arquivo .html único, para mandar por e-mail
```

**Se `npm test` falhar, não publique.** Os testes existem justamente para pegar
erro de dose — vale mais uma falha vermelha que uma prescrição errada no plantão.

---

## Onde fica cada coisa

| O que você quer mudar | Arquivo |
| --- | --- |
| Dose ou esquema de uma tabela do protocolo | `src/data/tables/secao-6-1.ts` … `secao-6-6.ts` |
| Nome, classe, teto ou aviso de um fármaco | `src/data/drugs.ts` |
| Tabela de ajuste por função renal | `src/data/ajuste-renal.ts` |
| Protocolo de vancomicina | `src/data/vancomicina.ts` |
| Amicacina neonatal | `src/data/amicacina-neonatal.ts` |
| Textos das fichas, alertas, glossário | `src/data/cards.ts` |
| Nome do hospital, versão, validade, responsável | `src/data/protocol.meta.ts` |
| Logotipo | `src/assets/logo.ts` |
| Cores do tema | `src/index.css` |

---

## Receita 1 — corrigir uma dose

Exemplo: a ceftriaxona da ITU pediátrica deve passar de 50 para 75 mg/kg.

Abra `src/data/tables/secao-6-3.ts`, ache o bloco `6.3.itu.1a` e mude **dois**
lugares:

```ts
{
  id: '6.3.itu.1a',
  // ...
  prescricoes: [
    {
      drugId: 'ceftriaxona',
      dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },  // ← aqui
      via: 'EV',
      intervalo: 'q12h',
    },
  ],
  textoOriginal: 'Ceftriaxona 75mg/kg EV 12/12h',   // ← e aqui
}
```

`textoOriginal` é o texto do documento impresso, exibido embaixo do esquema para
conferência. Mantenha os dois em sintonia.

**Campos de dose:**

- `doseFixa: { valor: 2, unidade: 'g' }` — dose fixa do adulto
- `doseFixa: { valor: [1, 2], unidade: 'g' }` — faixa "1 a 2 g"
- `dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' }` — mg/kg **por
  administração** (o padrão em pediatria)
- `dosePonderal: { valor: 10, unidade: 'mg/kg', base: 'dia' }` — mg/kg **por
  dia**, que o app divide pelo número de tomadas

**`base: 'dose'` x `base: 'dia'` é o erro mais caro possível aqui** — confundir
os dois erra a dose por 3 ou 4 vezes. Confira sempre como o documento grafa.

**Intervalos aceitos:** `q4h`, `q6h`, `q8h`, `q12h`, `q24h`.

---

## Receita 2 — mudar quando uma regra se aplica

Cada linha tem um `match`, que é a tradução da coluna "CONDIÇÃO" em lógica, e uma
`prioridade`. As regras do mesmo foco são testadas da maior prioridade para a
menor, e **a primeira que casar vence**.

```ts
{
  id: '6.5.pnm.pav-tardia',
  condicaoLabel: 'PAV Tardia (≥ 5 dias)',
  prioridade: 40,                                    // ← testada antes das menores
  match: (m) => typeof m.diasVentilacaoMecanica === 'number'
             && m.diasVentilacaoMecanica >= 5,       // ← a condição
  // ...
}
```

- **A linha padrão de cada foco tem `prioridade: 0` e `match: () => true`.** Ela é
  o fallback e deve existir exatamente uma por foco — há um teste que garante isso.
- Para tornar uma regra mais específica, dê a ela prioridade **maior** que a da
  regra que ela deve superar.

Condições disponíveis em `m` (a lista completa está em `src/domain/types.ts`,
interface `Modificadores`): `atbPrevio`, `aspirativa`, `litiaseRenal`,
`ituRecorrente`, `necrose`, `segundaOpcao`, `dispositivoInvasivo`,
`diasVentilacaoMecanica`, `suspeitaEnterococcusAnaerobio`, `isc`,
`sepseNeonatal`, `meningiteQuadroGrave`, `betalactamico3Meses`,
`resistenciaLocalPneumococo`, `suspeitaAtipico`.

Precisa de uma condição nova? Acrescente o campo em `Modificadores` e use no
`match`.

---

## Receita 3 — acrescentar um fármaco

Primeiro cadastre em `src/data/drugs.ts`:

```ts
ertapenem: {
  id: 'ertapenem',
  nome: 'Ertapenem',
  classe: 'Carbapenêmico',
  tetoAdultoPorDose: { valor: 1000, unidade: 'mg' },  // opcional
  tetoDiarioMg: 1000,                                  // opcional
  avisos: ['Sem ação contra Pseudomonas.'],            // opcional
},
```

Depois use o `id` numa prescrição. Há um teste que falha se você referenciar um
`drugId` que não existe no catálogo — de propósito.

**Campos opcionais úteis:**

- `tetoAdultoPorDose` — o app avisa quando a dose pediátrica calculada passa da
  dose de um adulto. Nunca corta a dose sozinho.
- `tetoDiarioMg` — avisa quando o total de 24 h estoura o teto.
- `protocoloExterno` — para fármaco cuja posologia vive em outro documento
  (é o caso da vancomicina): o app mostra alerta em vez de um número.
- `sinonimos` — nome comercial. **Aparece na busca mas não no texto exibido**,
  que é como o "Tazocin" continua encontrável sem ser prescrito por esse nome.

---

## Receita 4 — mexer na tabela de ajuste renal

Em `src/data/ajuste-renal.ts`:

```ts
{
  id: 'cefepime',
  nome: 'Cefepime',
  classe: 'antibacteriano',
  noProtocolo: true,          // ← aparece no topo da lista
  doseHabitual: '2 g 12/12h',
  doseAtaque: '...',          // opcional
  pesoDeReferencia: 'ajustado',  // 'atual' | 'ideal' | 'ajustado'
  esquemas: [
    {
      partida: 'a partir de 2 g 12/12h',
      indicacao: 'Dose usual',
      faixas: [
        { min: 60, max: null, rotulo: '> 60', dose: '2 g 12/12h' },
        { min: 30, max: 60,   rotulo: '30–60', dose: '2 g 1x/dia' },
      ],
      hemodialise: '500 mg 1x/dia + dose após HD',
    },
  ],
},
```

- `min` é **inclusivo**, `max` é **exclusivo**. `null` significa sem limite.
- Um teste garante que as faixas do mesmo esquema **não se sobrepõem**.
- Se o clearance cair num vão da tabela, o app diz que a tabela não cobre aquele
  valor — em vez de inventar dose.
- Doses escritas em mg/kg são convertidas automaticamente em miligramas, usando
  o peso indicado em `pesoDeReferencia`. Não precisa fazer conta.

Para marcar "sem ajuste renal": `semAjuste: true` e `esquemas: []`.

---

## Receita 5 — editar textos, alertas e fichas

Tudo em `src/data/cards.ts`. Cada ficha é um objeto com blocos:

```ts
{
  numero: 20,
  id: 'minha-ficha',
  titulo: 'Título em caixa alta',
  subtitulo: 'Linha de apoio',
  grupo: 'seguranca',        // fluxo | doses | adulto | uti-adulto |
                             // pediatria | uti-neoped | seguranca | referencia
  keywords: ['termos', 'para', 'busca'],
  blocos: [
    { tipo: 'alerta', severidade: 'critico', titulo: '...', texto: '...' },
    { tipo: 'lista', titulo: '...', itens: ['a', 'b'] },
    { tipo: 'regras', titulo: '...', itens: [{ n: '1', titulo: '...', texto: '...' }] },
    { tipo: 'tabela', titulo: '...', secaoId: '6.1' },
  ],
}
```

**Blocos disponíveis:** `alerta`, `lista`, `regras`, `definicoes`, `tabela`,
`calculadora`, `renal`, `vancomicina`, `amicacina-neonatal`, `cronometro`, `fluxo`.

**Severidade do alerta:** `info` (azul), `atencao` (amarelo), `critico` (vermelho).

**Marcação nos textos de `regras`:** `**negrito**` e `__destaque azul__`.

---

## Receita 6 — atualizar a versão do protocolo

`src/data/protocol.meta.ts`:

```ts
export const PROTOCOLO = {
  titulo: 'Protocolo de Antibioticoterapia Empírica',
  revisao: '20/03/2026',        // ← data da versão
  validade: '20/03/2028',
  setor: 'SCIH',
  instituicao: 'Hospital Evangélico de Londrina',
  responsavel: 'Dr. Philipe Bellinati — Coordenador do SCIH',
} as const
```

Ao publicar revisão nova, **troque também o nome do cache** em `public/sw.js`:

```js
const CACHE = 'guia-atb-empirico-v2'   // v1 → v2
```

Sem isso, quem já instalou o app pode continuar vendo a versão antiga por causa
do cache offline.

---

## Depois de qualquer mudança

```bash
npm test        # tem que passar
npm run build   # tem que compilar
```

Se um teste falhar apontando exatamente a dose que você mudou, **isso é
esperado**: ele estava travando o valor antigo. Abra `src/__tests__/` e atualize
o valor, deixando um comentário com o motivo da mudança.

Se falhar um teste que você não esperava, é sinal de que a mudança teve efeito
colateral em outro cenário. Vale investigar antes de seguir.
