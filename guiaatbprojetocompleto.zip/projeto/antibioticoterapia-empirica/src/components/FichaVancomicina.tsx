import { useEffect, useState } from 'react'
import { VANCO_ADULTO, VANCO_NEOPED } from '@/data/vancomicina'
import { converterDosePonderal } from '@/domain/dose-ponderal'
import { formatarNumero } from '@/domain/dosing'
import { Callout } from './ui/primitives'
import { cn } from '@/lib/utils'

/**
 * Ficha da Vancomicina.
 *
 * Adulto e neonatal/pediátrico têm lógicas de ajuste incompatíveis — o adulto
 * corrige em miligramas absolutos, o pediátrico em percentual, e só o adulto
 * faz dose de ataque. Por isso a ficha é um seletor exclusivo: as duas tabelas
 * nunca aparecem na mesma tela, para que ninguém leia a linha errada com pressa.
 *
 * A ficha PEDE OS DADOS logo no topo (peso e, no adulto, ClCr) e converte as
 * doses em miligramas ali mesmo — é o "solicitar dados para cálculo" ao entrar
 * na Vancomicina, em vez de deixar a conta em mg/kg para a beira-leito.
 */

/** Teto de dose adulta: 2 g por administração. */
const VANCO_MAX_MG = 2000

export function FichaVancomicina({
  populacaoInicial,
}: {
  /**
   * Aba a abrir. Vem do atalho nas tabelas: uma citação de Vancomicina na
   * seção 6.6 deve cair na tabela neonatal/pediátrica, não na do adulto —
   * são lógicas de ajuste incompatíveis.
   */
  populacaoInicial?: 'adulto' | 'neoped'
} = {}) {
  const [populacao, setPopulacao] = useState<'adulto' | 'neoped'>(
    populacaoInicial ?? 'adulto',
  )
  const [peso, setPeso] = useState<number | undefined>(undefined)
  const [clcr, setClcr] = useState<number | undefined>(undefined)

  // A ficha pode já estar montada quando o atalho é acionado de novo, com
  // outra população — por isso sincroniza, em vez de só usar valor inicial.
  useEffect(() => {
    if (populacaoInicial) setPopulacao(populacaoInicial)
  }, [populacaoInicial])

  return (
    <div className="space-y-4 px-4 py-4">
      <div className="flex gap-2" role="tablist" aria-label="População">
        {(
          [
            { id: 'adulto', rotulo: 'Adulto' },
            { id: 'neoped', rotulo: 'Neonatal e pediátrico' },
          ] as const
        ).map((op) => (
          <button
            key={op.id}
            type="button"
            role="tab"
            aria-selected={populacao === op.id}
            onClick={() => setPopulacao(op.id)}
            className={cn(
              'flex-1 rounded-md border px-3 py-2.5 text-sm font-bold uppercase tracking-wider transition-colors',
              populacao === op.id
                ? 'border-primary bg-primary/15 text-primary'
                : 'border-border bg-secondary/60 text-muted-foreground hover:bg-secondary',
            )}
          >
            {op.rotulo}
          </button>
        ))}
      </div>

      {/* ---- Dados para o cálculo ---- */}
      <div className="rounded-md border border-primary/30 bg-primary/5 p-3">
        <p className="kicker mb-2">Dados para o cálculo</p>
        <div className="flex flex-wrap gap-3">
          <label className="flex-1 min-w-[120px]">
            <span className="text-xs text-muted-foreground">Peso (kg)</span>
            <input
              type="number"
              inputMode="decimal"
              step="0.1"
              value={peso ?? ''}
              onChange={(e) => setPeso(e.target.value === '' ? undefined : Number(e.target.value))}
              placeholder="ex.: 70"
              aria-label="Peso em quilogramas"
              className="mt-1 w-full rounded-md border border-border bg-input px-2.5 py-2 text-base font-semibold text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-ring"
            />
          </label>
          {populacao === 'adulto' && (
            <label className="flex-1 min-w-[120px]">
              <span className="text-xs text-muted-foreground">ClCr (mL/min)</span>
              <input
                type="number"
                inputMode="decimal"
                step="1"
                value={clcr ?? ''}
                onChange={(e) => setClcr(e.target.value === '' ? undefined : Number(e.target.value))}
                placeholder="ex.: 80"
                aria-label="Clearance de creatinina em mL/min"
                className="mt-1 w-full rounded-md border border-border bg-input px-2.5 py-2 text-base font-semibold text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-ring"
              />
            </label>
          )}
        </div>
        {peso === undefined && (
          <p className="mt-2 text-xs text-muted-foreground">
            Informe o peso para as doses saírem em miligramas.
            {populacao === 'adulto' && ' O ClCr destaca o intervalo de manutenção.'}
          </p>
        )}
      </div>

      {populacao === 'adulto' ? <VancoAdulto peso={peso} clcr={clcr} /> : <VancoNeoPed peso={peso} />}
    </div>
  )
}

function Secao({ titulo, children }: { titulo: string; children: React.ReactNode }) {
  return (
    <section>
      <h4 className="kicker mb-2">{titulo}</h4>
      {children}
    </section>
  )
}

/** Converte "X mg/kg..." em mg para o peso, aplicando o teto opcional. */
function emMg(dose: string, peso: number | undefined, tetoMg?: number): string | undefined {
  if (peso === undefined) return undefined
  const c = converterDosePonderal(dose, peso)
  if (!c) return undefined
  if (tetoMg !== undefined) {
    const min = Math.min(c.min, tetoMg)
    const max = Math.min(c.max, tetoMg)
    const limitou = c.max > tetoMg
    const valor = min === max ? formatarNumero(min) : `${formatarNumero(min)} – ${formatarNumero(max)}`
    return `= ${valor} mg${limitou ? ` (limitado ao máximo de ${formatarNumero(tetoMg)} mg)` : ''}`
  }
  return c.texto
}

/** Faixa de ClCr do adulto correspondente à linha da tabela de manutenção. */
function linhaClcrAtiva(clcr: number | undefined, rotulo: string): boolean {
  if (clcr === undefined) return false
  if (rotulo === '> 90') return clcr > 90
  if (rotulo === '50–90') return clcr >= 50 && clcr <= 90
  if (rotulo === '< 50') return clcr < 50
  return false
}

function VancoAdulto({ peso, clcr }: { peso?: number; clcr?: number }) {
  const ataqueMg = emMg('25 a 30 mg/kg', peso, VANCO_MAX_MG)

  return (
    <div className="space-y-4">
      <Callout severidade="critico" titulo="Dose de ataque">
        <strong>{VANCO_ADULTO.ataque.dose}</strong> — máximo {VANCO_ADULTO.ataque.maxima}.{' '}
        {VANCO_ADULTO.ataque.observacao}
        {ataqueMg && (
          <span className="mt-1 block text-base font-bold text-foreground">
            {peso} kg {ataqueMg}
          </span>
        )}
      </Callout>

      <Secao titulo="Alvo de vale">
        <p className="text-sm leading-relaxed text-foreground/90">
          <span className="font-bold text-primary">{VANCO_ADULTO.alvoVale.faixa}</span>.{' '}
          {VANCO_ADULTO.alvoVale.observacao} {VANCO_ADULTO.alvoVale.abaixo}{' '}
          {VANCO_ADULTO.alvoVale.acima}
        </p>
        <p className="mt-1.5 text-xs text-muted-foreground">
          {VANCO_ADULTO.indicacaoMonitoramento}
        </p>
      </Secao>

      <Secao titulo="Manutenção por clearance">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[440px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="kicker pb-2 pr-3">ClCr (mL/min)</th>
                <th scope="col" className="kicker pb-2 pr-3">Dose</th>
                <th scope="col" className="kicker pb-2">1ª dosagem</th>
              </tr>
            </thead>
            <tbody>
              {VANCO_ADULTO.manutencao.map((l) => {
                const ativa = linhaClcrAtiva(clcr, l.clcr)
                const doseMg = emMg(l.dose, peso, VANCO_MAX_MG)
                return (
                  <tr
                    key={l.clcr}
                    className={cn(
                      'border-b border-border/60 align-top',
                      ativa && 'bg-primary/10',
                    )}
                  >
                    <td className="py-2 pr-3 font-semibold text-foreground">
                      {l.clcr}
                      {ativa && (
                        <span className="ml-1 text-[10px] font-bold uppercase text-primary">
                          ← ClCr {clcr}
                        </span>
                      )}
                    </td>
                    <td className="py-2 pr-3 text-primary">
                      {l.dose}
                      {l.intervalo !== 'ACM' && <span className="text-muted-foreground"> · {l.intervalo}</span>}
                      {doseMg && (
                        <span className="block text-xs font-semibold text-foreground">{doseMg}</span>
                      )}
                    </td>
                    <td className="py-2 text-xs text-muted-foreground">{l.primeiraDosagem}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-warning">Dose máxima: {VANCO_ADULTO.doseMaxima}.</p>
      </Secao>

      <Secao titulo="Correção conforme vancocinemia">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="kicker pb-2 pr-3">mcg/mL</th>
                <th scope="col" className="kicker pb-2 pr-3">Dose 8/8h</th>
                <th scope="col" className="kicker pb-2 pr-3">Dose 12/12h</th>
                <th scope="col" className="kicker pb-2">Dose 1x/dia</th>
              </tr>
            </thead>
            <tbody>
              {VANCO_ADULTO.correcao.map((l) => (
                <tr
                  key={l.nivel}
                  className={cn(
                    'border-b border-border/60 align-top',
                    l.nivel === '15,1–25' && 'bg-success/10',
                  )}
                >
                  <td className="py-2 pr-3 font-bold tabular-nums text-foreground">{l.nivel}</td>
                  <td className="py-2 pr-3 text-foreground/85">{l.q8h}</td>
                  <td className="py-2 pr-3 text-foreground/85">{l.q12h}</td>
                  <td className="py-2 text-foreground/85">{l.q24h}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Secao>

      <Secao titulo="Hemodiálise">
        <ul className="space-y-1">
          {VANCO_ADULTO.hemodialise.map((h, i) => (
            <li key={i} className="flex gap-2 text-sm text-foreground/90">
              <span aria-hidden className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-primary" />
              <span>{h}</span>
            </li>
          ))}
        </ul>
      </Secao>

      <Secao titulo="Observações">
        <ul className="space-y-1.5">
          {VANCO_ADULTO.notas.map((n, i) => (
            <li key={i} className="text-xs leading-relaxed text-muted-foreground">
              {n}
            </li>
          ))}
        </ul>
      </Secao>
    </div>
  )
}

function VancoNeoPed({ peso }: { peso?: number }) {
  const posNeonatalMg = emMg(VANCO_NEOPED.aposPeriodoNeonatal, peso, VANCO_MAX_MG)

  return (
    <div className="space-y-4">
      <Callout severidade="critico" titulo="Não se faz dose de ataque">
        {VANCO_NEOPED.semAtaque}
      </Callout>

      <Secao titulo="Neonato (< 28 dias) — por creatinina sérica">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[360px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="kicker pb-2 pr-3">Creatinina</th>
                <th scope="col" className="kicker pb-2">Dose</th>
              </tr>
            </thead>
            <tbody>
              {VANCO_NEOPED.neonatalPorCreatinina.map((l) => {
                const doseMg = emMg(l.dose, peso)
                return (
                  <tr key={l.creatinina} className="border-b border-border/60">
                    <td className="py-2 pr-3 font-semibold text-foreground">{l.creatinina}</td>
                    <td className="py-2 text-primary">
                      {l.dose} <span className="text-muted-foreground">· {l.intervalo}</span>
                      {doseMg && (
                        <span className="block text-xs font-semibold text-foreground">{doseMg}</span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          No neonato a manutenção é definida pela <strong>creatinina sérica</strong>, não
          pelo clearance.
        </p>
      </Secao>

      <Secao titulo="Após o período neonatal">
        <p className="text-sm text-foreground/90">{VANCO_NEOPED.aposPeriodoNeonatal}</p>
        {posNeonatalMg && (
          <p className="mt-1 text-sm font-semibold text-foreground">
            {peso} kg {posNeonatalMg} por dose
          </p>
        )}
      </Secao>

      <Secao titulo="Pediátrico com injúria renal aguda">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[360px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="kicker pb-2 pr-3">ClCr</th>
                <th scope="col" className="kicker pb-2">Dose</th>
              </tr>
            </thead>
            <tbody>
              {VANCO_NEOPED.pediatricoIRA.map((l) => {
                const doseMg = emMg(l.dose, peso)
                return (
                  <tr key={l.clcr} className="border-b border-border/60">
                    <td className="py-2 pr-3 font-semibold text-foreground">{l.clcr}</td>
                    <td className="py-2 text-primary">
                      {l.dose} <span className="text-muted-foreground">· {l.intervalo}</span>
                      {doseMg && (
                        <span className="block text-xs font-semibold text-foreground">{doseMg}</span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </Secao>

      <Secao titulo="Correção conforme vancocinemia">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[480px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="kicker pb-2 pr-3">Nível</th>
                <th scope="col" className="kicker pb-2 pr-3">Conduta</th>
                <th scope="col" className="kicker pb-2">Recoleta</th>
              </tr>
            </thead>
            <tbody>
              {VANCO_NEOPED.correcao.map((l) => (
                <tr
                  key={l.nivel}
                  className={cn(
                    'border-b border-border/60 align-top',
                    l.nivel.startsWith('15 a 20') && 'bg-success/10',
                  )}
                >
                  <td className="py-2 pr-3 font-bold tabular-nums text-foreground">{l.nivel}</td>
                  <td className="py-2 pr-3 text-foreground/85">{l.conduta}</td>
                  <td className="py-2 text-xs text-muted-foreground">{l.recoleta}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-warning">
          Diferente do adulto, aqui a correção é em <strong>percentual</strong> da dose
          vigente — não em miligramas fixos.
        </p>
      </Secao>

      <Secao titulo="Administração">
        <ul className="space-y-1">
          {VANCO_NEOPED.administracao.map((a, i) => (
            <li key={i} className="flex gap-2 text-sm text-foreground/90">
              <span aria-hidden className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-primary" />
              <span>{a}</span>
            </li>
          ))}
        </ul>
      </Secao>

      <Secao titulo="Tempo até o estado de equilíbrio">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[420px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th scope="col" className="kicker pb-2 pr-3">Idade</th>
                <th scope="col" className="kicker pb-2 pr-3">Meia-vida</th>
                <th scope="col" className="kicker pb-2">Equilíbrio</th>
              </tr>
            </thead>
            <tbody>
              {VANCO_NEOPED.estadoDeEquilibrio.map((l) => (
                <tr key={l.idade} className="border-b border-border/60">
                  <td className="py-2 pr-3 text-foreground/90">{l.idade}</td>
                  <td className="py-2 pr-3 tabular-nums text-muted-foreground">{l.meiaVida}</td>
                  <td className="py-2 tabular-nums text-primary">{l.equilibrio}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Secao>

      <Secao titulo="Observações">
        <ul className="space-y-1.5">
          {VANCO_NEOPED.notas.map((n, i) => (
            <li key={i} className="text-xs leading-relaxed text-muted-foreground">
              {n}
            </li>
          ))}
        </ul>
      </Secao>
    </div>
  )
}
