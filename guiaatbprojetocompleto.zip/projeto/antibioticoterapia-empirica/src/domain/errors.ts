/**
 * Erros de domínio.
 *
 * Regra de segurança clínica adotada: o motor NUNCA devolve um regime "melhor
 * palpite". Se a combinação de variáveis não estiver prevista no protocolo, ele
 * falha de forma explícita e a interface instrui o prescritor a acionar o SCIH.
 * Silenciar a lacuna seria o modo de falha mais perigoso deste tipo de app.
 */

export type DomainErrorCode =
  | 'INPUT_INVALIDO'
  | 'PESO_OBRIGATORIO'
  | 'PESO_FORA_DA_FAIXA'
  | 'SECAO_NAO_APLICAVEL'
  | 'FOCO_NAO_COBERTO'
  | 'REGRA_NAO_ENCONTRADA'
  | 'FARMACO_DESCONHECIDO'

export class ProtocolError extends Error {
  readonly code: DomainErrorCode
  /** Orientação acionável exibida ao usuário no lugar de um regime. */
  readonly orientacao: string

  constructor(code: DomainErrorCode, message: string, orientacao: string) {
    super(message)
    this.name = 'ProtocolError'
    this.code = code
    this.orientacao = orientacao
    // Mantém a cadeia de protótipos correta ao compilar para ES5/ES2020.
    Object.setPrototypeOf(this, ProtocolError.prototype)
  }
}

/** Orientação padrão para qualquer situação não prevista pelo protocolo. */
export const ORIENTACAO_SCIH =
  'Situação não contemplada pelo protocolo. Acione o SCIH / Programa de ' +
  'Racionalização de Antimicrobianos para definição individualizada e registre ' +
  'a discussão em prontuário.'
