import type { ProtocolRule } from '@/domain/types'

/**
 * 6.4 — IRAS, ENFERMARIA PEDIÁTRICA (página 4 do protocolo).
 *
 * Doses ponderais por administração (nota ³). Diferentemente do adulto (6.2),
 * aqui o protocolo separa IPCS associada e não associada a dispositivo — o que
 * torna o modificador `dispositivoInvasivo` decisivo.
 */
export const SECAO_6_4: readonly ProtocolRule[] = [
  // --- Pneumonia -----------------------------------------------------------
  {
    id: '6.4.pneumonia.aspirativa',
    secao: '6.4',
    focoId: 'pneumonia_hospitalar',
    condicaoLabel: 'Se aspirativa',
    prioridade: 10,
    match: (m) => m.aspirativa === true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
          observacoes: [
            'mg/kg calculado APENAS sobre o componente piperacilina (proporção 8:1). ' +
            'Bula: 100 mg/kg/dose de piperacilina a cada 6 ou 8 h em > 9 meses; ' +
            '80 mg/kg/dose a cada 8 h entre 2 e 9 meses. Máximo 24 g/dia. ' +
            'Acima de 40 kg, usar dose de adulto.',
          ],
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Piperacilina/tazobactam 75mg/kg EV 6/6h',
  },
  {
    id: '6.4.pneumonia.base',
    secao: '6.4',
    focoId: 'pneumonia_hospitalar',
    condicaoLabel: 'Pneumonia',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Cefepime 50mg/kg EV 8/8h',
  },

  // --- ITU -----------------------------------------------------------------
  {
    id: '6.4.itu.base',
    secao: '6.4',
    focoId: 'itu',
    condicaoLabel: 'ITU',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
          observacoes: [
            'mg/kg calculado APENAS sobre o componente piperacilina (proporção 8:1). ' +
            'Bula: 100 mg/kg/dose de piperacilina a cada 6 ou 8 h em > 9 meses; ' +
            '80 mg/kg/dose a cada 8 h entre 2 e 9 meses. Máximo 24 g/dia. ' +
            'Acima de 40 kg, usar dose de adulto.',
          ],
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Piperacilina/tazobactam 75mg/kg EV 6/6h',
  },

  // --- IPCS ----------------------------------------------------------------
  {
    id: '6.4.ipcs.cateter',
    secao: '6.4',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS assoc. a cateter',
    // Dispositivo presente → cobertura empírica para Gram-positivos de pele.
    prioridade: 10,
    match: (m) => m.dispositivoInvasivo === true,
    prescricoes: [
      {
        drugId: 'cefepime',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
      },
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q6h' },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Cefepime 50mg/kg EV 8/8h + Vancomicina¹',
  },
  {
    id: '6.4.ipcs.sem-dispositivo',
    secao: '6.4',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS não assoc. a dispositivos',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        dosePonderal: { valor: 50, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q8h',
      },
    ],
    notas: ['n3'],
    textoOriginal: 'Cefepime 50mg/kg EV 8/8h',
  },

  // --- ISC -----------------------------------------------------------------
  {
    id: '6.4.isc.base',
    secao: '6.4',
    focoId: 'isc',
    condicaoLabel: 'ISC',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q6h' },
      {
        drugId: 'piperacilina_tazobactam',
        dosePonderal: { valor: 75, unidade: 'mg/kg', base: 'dose' },
        via: 'EV',
        intervalo: 'q6h',
          observacoes: [
            'mg/kg calculado APENAS sobre o componente piperacilina (proporção 8:1). ' +
            'Bula: 100 mg/kg/dose de piperacilina a cada 6 ou 8 h em > 9 meses; ' +
            '80 mg/kg/dose a cada 8 h entre 2 e 9 meses. Máximo 24 g/dia. ' +
            'Acima de 40 kg, usar dose de adulto.',
          ],
      },
    ],
    notas: ['n1', 'n3'],
    textoOriginal: 'Vancomicina¹ + Piperacilina/tazobactam 75mg/kg EV 6/6h',
  },
]
