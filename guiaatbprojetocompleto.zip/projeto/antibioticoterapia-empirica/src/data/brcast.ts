/**
 * Dosagens do BrCAST-EUCAST — "Tabela de Pontos de Corte Clínicos",
 * válida a partir de 15-04-2026.
 *
 * O QUE ESTA TABELA É
 * São as dosagens que o EUCAST/BrCAST assume ao DEFINIR os pontos de corte
 * (breakpoints) de sensibilidade. Ou seja: o laboratório só pode dizer
 * "sensível" se a dose administrada for pelo menos a dose-padrão daqui. Uma
 * dose menor que a de referência invalida o laudo — o "S" do antibiograma
 * deixa de significar o que parece significar.
 *
 * POR ISSO ELA IMPORTA AO LADO DA TABELA INSTITUCIONAL
 * A tabela de ajuste do hospital diz como REDUZIR por função renal. O BrCAST
 * diz qual é o PISO para o breakpoint valer, e qual é a "dose alta" exigida em
 * situações específicas (meningite, *Pseudomonas*, *S. aureus*). Divergências
 * entre as duas são informação clínica, não erro de transcrição — por isso o
 * guia mostra as duas lado a lado em vez de sobrescrever uma com a outra.
 *
 * ADVERTÊNCIA DO PRÓPRIO DOCUMENTO
 * "Os pontos de corte do EUCAST são baseados nas seguintes dosagens. Regimes de
 * dosagem alternativos que resultem em exposição equivalente são aceitáveis. A
 * tabela não deve ser considerada uma orientação exaustiva para a dosagem na
 * prática clínica [...] Esta tabela não substitui as diretrizes específicas
 * locais, nacionais ou regionais."
 *
 * ESCOPO
 * Só constam os antimicrobianos que o guia já usa. O BrCAST lista muitos outros
 * (doripenem, dalbavancina, cefiderocol, tedizolida…) que foram deliberadamente
 * OMITIDOS: incluí-los sugeriria disponibilidade que a instituição não tem.
 *
 * A tabela do BrCAST é ANTIBACTERIANA. Antifúngicos e antivirais do guia
 * (fluconazol, voriconazol, anfotericina, micafungina, aciclovir, ganciclovir)
 * não têm entrada aqui — ver `SEM_COBERTURA_BRCAST`.
 */

export interface DoseBrcast {
  /** Casa com o `id` de `AJUSTE_RENAL` e, quando existe, com o `drugId`. */
  id: string
  nome: string
  /** Dosagem-padrão sobre a qual o ponto de corte foi definido. */
  padrao: string
  /** Regime de alta exposição. `undefined` quando o documento diz "Não há". */
  alta?: string
  /** Coluna "ITU não complicada" (cistite não complicada). */
  ituNaoComplicada?: string
  /** Coluna "Situações específicas" — meningite, Pseudomonas, S. aureus. */
  situacoes?: readonly string[]
}

export const DOSES_BRCAST: readonly DoseBrcast[] = [
  // --- Penicilinas ---------------------------------------------------------
  {
    id: 'penicilina_g',
    nome: 'Benzilpenicilina (penicilina G cristalina)',
    padrao: '0,6 g (1 MU) × 4 EV',
    alta: '1,2 g (2 MU) × 6 EV',
    situacoes: ['Meningite: 2,4 g (4 MU) × 6 EV'],
  },
  {
    id: 'ampicilina',
    nome: 'Ampicilina EV',
    padrao: '2 g × 3 EV',
    alta: '2 g × 4 EV',
    situacoes: ['Meningite: 2 g × 6 EV'],
  },
  {
    id: 'ampicilina_sulbactam',
    nome: 'Ampicilina-sulbactam EV',
    padrao: '(2 g ampicilina + 1 g sulbactam) × 3 EV',
    alta: '(2 g ampicilina + 1 g sulbactam) × 4 EV',
  },
  {
    id: 'amoxicilina_clavulanato',
    nome: 'Amoxicilina-clavulanato EV',
    padrao: '(1 g amoxicilina + 0,2 g clavulanato) × 3–4 EV',
    alta: '(2 g amoxicilina + 0,2 g clavulanato) × 3 EV',
  },
  {
    id: 'piperacilina_tazobactam',
    nome: 'Piperacilina-tazobactam',
    padrao:
      '(4 g piperacilina + 0,5 g tazobactam) × 4 EV em 30 min, ou × 3 EV em ' +
      'infusão estendida de 4 h',
    alta: '(4 g piperacilina + 0,5 g tazobactam) × 4 EV em infusão estendida de 3 h',
    situacoes: [
      'Dose menor — (4 g + 0,5 g) × 3 EV em 30 min — é adequada para ITU ' +
        'complicada, infecção intra-abdominal e pé diabético, mas não para ' +
        'infecções por isolados resistentes a cefalosporinas de 3ª geração.',
    ],
  },
  {
    id: 'oxacilina',
    nome: 'Oxacilina',
    padrao: '1 g × 4 EV',
    situacoes: ['As dosagens de alta exposição variam conforme a indicação.'],
  },

  // --- Cefalosporinas ------------------------------------------------------
  {
    id: 'cefazolina',
    nome: 'Cefazolina',
    padrao: '1 g × 3 EV',
    alta: '2 g × 3 EV',
    situacoes: ['*S. aureus*: exclusivamente dose alta.'],
  },
  {
    id: 'cefuroxima',
    nome: 'Cefuroxima EV',
    padrao: '0,75 g × 3 EV',
    alta: '1,5 g × 3 EV',
    ituNaoComplicada: '0,25 g × 2 VO',
  },
  {
    id: 'ceftriaxona',
    nome: 'Ceftriaxona',
    padrao: '2 g × 1 EV',
    alta: '2 g × 2 EV ou 4 g × 1 EV',
    situacoes: [
      'Meningite: 2 g × 2 EV ou 4 g × 1 EV.',
      '*S. aureus*: somente doses altas.',
      'Gonorreia não complicada: 0,5–1 g IM em dose única.',
    ],
  },
  {
    id: 'ceftazidima',
    nome: 'Ceftazidima',
    padrao: '1 g × 3 EV',
    alta: '2 g × 3 EV ou 1 g × 6 EV',
  },
  {
    id: 'cefepime',
    nome: 'Cefepima',
    padrao: '1 g × 3 EV ou 2 g × 2 EV',
    alta: '2 g × 3 EV',
    situacoes: [
      'Infecções graves por *P. aeruginosa*: 2 g × 3 EV em infusão estendida por 4 h.',
      '*S. aureus*: exclusivamente dose alta.',
    ],
  },
  {
    id: 'ceftazidima_avibactam',
    nome: 'Ceftazidima-avibactam',
    padrao: '(2 g ceftazidima + 0,5 g avibactam) × 3 EV durante 2 h',
  },
  {
    id: 'ceftolozana_tazobactam',
    nome: 'Ceftolozana-tazobactam',
    padrao:
      'ITU e intra-abdominal: (1 g ceftolozana + 0,5 g tazobactam) × 3 EV ' +
      'durante 1 h',
    alta:
      'Pneumonia hospitalar e PAV: (2 g ceftolozana + 1 g tazobactam) × 3 EV ' +
      'durante 1 h',
  },

  // --- Carbapenêmicos ------------------------------------------------------
  {
    id: 'ertapenem',
    nome: 'Ertapenem',
    padrao: '1 g × 1 EV durante 30 min',
  },
  {
    id: 'imipenem',
    nome: 'Imipenem',
    padrao: '0,5 g × 4 EV durante 30 min',
    alta: '1 g × 4 EV durante 30 min',
  },
  {
    id: 'meropenem',
    nome: 'Meropenem',
    padrao: '1 g × 3 EV durante 30 min',
    alta: '2 g × 3 EV durante 3 h',
    situacoes: ['Meningite: 2 g × 3 EV durante 3 h.'],
  },

  // --- Monobactâmico -------------------------------------------------------
  {
    id: 'aztreonam',
    nome: 'Aztreonam',
    padrao: '1 g × 3 EV',
    alta: '2 g × 4 EV',
    situacoes: [
      'Infecções graves por *P. aeruginosa*: 2 g × 4 EV em infusão estendida por 3 h.',
    ],
  },

  // --- Fluoroquinolonas ----------------------------------------------------
  {
    id: 'ciprofloxacino',
    nome: 'Ciprofloxacino',
    padrao: '0,5 g × 2 VO ou 0,4 g × 2 EV',
    alta: '0,75 g × 2 VO ou 0,4 g × 3 EV',
  },
  {
    id: 'levofloxacino',
    nome: 'Levofloxacino',
    padrao: '0,5 g × 1 VO ou 0,5 g × 1 EV',
    alta: '0,5 g × 2 VO ou 0,5 g × 2 EV',
  },
  {
    id: 'moxifloxacino',
    nome: 'Moxifloxacino',
    padrao: '0,4 g × 1 VO ou 0,4 g × 1 EV',
    situacoes: ['O documento não define regime de alta exposição.'],
  },
  {
    id: 'delafloxacino',
    nome: 'Delafloxacino',
    padrao: '0,45 g × 2 VO ou 0,3 g × 2 EV',
  },

  // --- Aminoglicosídeos ----------------------------------------------------
  {
    id: 'amicacina',
    nome: 'Amicacina',
    padrao: '25–30 mg/kg × 1 EV',
    situacoes: ['Dose única diária, baseada no peso — usar peso ajustado.'],
  },
  {
    id: 'gentamicina',
    nome: 'Gentamicina',
    padrao: '6–7 mg/kg × 1 EV',
    situacoes: ['Dose única diária, baseada no peso — usar peso ajustado.'],
  },

  // --- Glicopeptídeos e lipoglicopeptídeos ---------------------------------
  {
    id: 'vancomicina',
    nome: 'Vancomicina',
    padrao: '0,5 g × 4 EV ou 1 g × 2 EV, ou 2 g × 1 por infusão contínua',
    situacoes: [
      'Baseada no peso corporal. O monitoramento terapêutico (vancocinemia) deve ' +
        'orientar a dosagem.',
    ],
  },
  {
    id: 'teicoplanina',
    nome: 'Teicoplanina',
    padrao: '0,4 g × 1 EV',
    situacoes: ['As dosagens de alta exposição variam conforme a indicação.'],
  },
  {
    id: 'daptomicina',
    nome: 'Daptomicina',
    padrao:
      'Infecção complicada de pele e partes moles SEM bacteremia por ' +
      '*S. aureus*: 4 mg/kg × 1 EV',
    alta:
      'Infecção complicada de pele e partes moles COM bacteremia por ' +
      '*S. aureus*, e endocardite direita por *S. aureus*: 6 mg/kg × 1 EV',
    situacoes: [
      'Para corrente sanguínea e endocardite por *Enterococcus*, consultar os ' +
        'documentos de orientação do EUCAST.',
      'Não usar em pneumonia — inativada pelo surfactante.',
    ],
  },

  // --- Macrolídeos e lincosamidas ------------------------------------------
  {
    id: 'azitromicina',
    nome: 'Azitromicina',
    padrao: '0,5 g × 1 VO ou 0,5 g × 1 EV',
    situacoes: ['Gonorreia não complicada: 2 g VO em dose única.'],
  },
  {
    id: 'claritromicina',
    nome: 'Claritromicina',
    padrao: '0,25 g × 2 VO',
    situacoes: [
      'Onde há apresentação endovenosa, 0,5 g × 2 EV — principalmente no ' +
        'tratamento de pneumonia.',
    ],
  },
  {
    id: 'clindamicina',
    nome: 'Clindamicina',
    padrao: '0,3 g × 2 VO ou 0,6 g × 3 EV',
    situacoes: [
      'O regime de alta exposição refere-se à gravidade da infecção ou à ' +
        'penetração do antimicrobiano no local da infecção.',
    ],
  },

  // --- Tetraciclinas -------------------------------------------------------
  {
    id: 'doxiciclina',
    nome: 'Doxiciclina',
    padrao: '0,1 g × 1 VO',
    situacoes: ['As dosagens de alta exposição variam conforme a indicação.'],
  },
  {
    id: 'tigeciclina',
    nome: 'Tigeciclina',
    padrao: '0,1 g em dose de ataque, seguida de 50 mg × 2 EV',
  },

  // --- Oxazolidinona -------------------------------------------------------
  {
    id: 'linezolida',
    nome: 'Linezolida',
    padrao: '0,6 g × 2 VO ou 0,6 g × 2 EV',
    situacoes: ['Meningite: 0,6 g × 2 EV.'],
  },

  // --- Agentes diversos ----------------------------------------------------
  {
    id: 'polimixina_b',
    nome: 'Polimixina B',
    padrao: '15.000–25.000 UI/kg/dia EV, divididas 12/12h',
    alta: '30.000 UI/kg/dia EV, divididas 12/12h',
  },
  {
    id: 'polimixina_e',
    nome: 'Colistina (polimixina E)',
    padrao: '4,5 MU × 2 EV, com dose de ataque de 9 MU',
  },
  {
    id: 'fosfomicina',
    nome: 'Fosfomicina EV',
    padrao: '16–18 g/dia divididos em 3–4 doses',
    ituNaoComplicada: '3 g × 1 VO em dose única',
  },
  {
    id: 'metronidazol',
    nome: 'Metronidazol',
    padrao: '0,4 g × 3 VO ou 0,5 g × 3 EV',
  },
  {
    id: 'nitrofurantoina',
    nome: 'Nitrofurantoína',
    padrao: '—',
    ituNaoComplicada: '50–100 mg × 3–4 VO',
    situacoes: ['Uso restrito à ITU não complicada (cistite).'],
  },
  {
    id: 'sulfametoxazol_trimetoprima',
    nome: 'Sulfametoxazol-trimetoprima',
    padrao:
      '(0,8 g sulfametoxazol + 0,16 g trimetoprima) × 2 VO ou × 2 EV',
    alta: '(1,2 g sulfametoxazol + 0,24 g trimetoprima) × 2 VO ou × 2 EV',
    ituNaoComplicada: '0,16 g (trimetoprima) × 2 VO',
    situacoes: [
      'Meningite: (5 mg/kg até 0,48 g de trimetoprima + 25 mg/kg até 2,4 g de ' +
        'sulfametoxazol) × 3 EV.',
    ],
  },
]

/**
 * Fármacos do guia que o BrCAST NÃO cobre, e por quê.
 *
 * Registrar a ausência evita a leitura errada de que "faltou transcrever" — e
 * evita que alguém procure na tabela do BrCAST uma dose que ela nunca teve.
 */
export const SEM_COBERTURA_BRCAST: readonly { id: string; nome: string; motivo: string }[] = [
  {
    id: 'penicilina_benzatina',
    nome: 'Penicilina G benzatina',
    motivo:
      'O BrCAST define ponto de corte apenas para a benzilpenicilina (cristalina). ' +
      'A benzatina é formulação de depósito, com indicação e posologia próprias.',
  },
  {
    id: 'cefalotina',
    nome: 'Cefalotina',
    motivo:
      'Cefalosporina de 1ª geração fora da tabela do BrCAST — o documento traz ' +
      'cefazolina como representante da classe.',
  },
  {
    id: 'anfotericina_b_convencional',
    nome: 'Anfotericina B convencional',
    motivo: 'Antifúngico — a tabela de dosagens do BrCAST é antibacteriana.',
  },
  {
    id: 'anfotericina_b_lipossomal',
    nome: 'Anfotericina B lipossomal',
    motivo: 'Antifúngico — a tabela de dosagens do BrCAST é antibacteriana.',
  },
  {
    id: 'fluconazol',
    nome: 'Fluconazol',
    motivo: 'Antifúngico — a tabela de dosagens do BrCAST é antibacteriana.',
  },
  {
    id: 'voriconazol',
    nome: 'Voriconazol',
    motivo: 'Antifúngico — a tabela de dosagens do BrCAST é antibacteriana.',
  },
  {
    id: 'micafungina',
    nome: 'Micafungina',
    motivo: 'Antifúngico — a tabela de dosagens do BrCAST é antibacteriana.',
  },
  {
    id: 'aciclovir',
    nome: 'Aciclovir',
    motivo: 'Antiviral — a tabela de dosagens do BrCAST é antibacteriana.',
  },
  {
    id: 'ganciclovir',
    nome: 'Ganciclovir',
    motivo: 'Antiviral — a tabela de dosagens do BrCAST é antibacteriana.',
  },
]

export function findBrcast(id: string): DoseBrcast | undefined {
  return DOSES_BRCAST.find((d) => d.id === id)
}
