import { useState } from 'react'
import { pesoAjustado, pesoIdealDevine, type Sexo } from '@/domain/renal'
import { formatarNumero } from '@/domain/dosing'
import { Callout } from './ui/primitives'
import { cn } from '@/lib/utils'

/**
 * Peso de referência para aminoglicosídeos.
 *
 * Existe separada da calculadora renal de propósito: o peso ajustado depende
 * apenas de altura, sexo e peso real — exigir creatinina e idade para chegar
 * nele obrigaria o prescritor a preencher campos que não entram nesta conta.
 *
 * A tabela institucional exige peso AJUSTADO para amicacina e gentamicina. No
 * paciente obeso, calcular sobre o peso real superdosa; sobre o ideal,
 * subdosa — é o erro que esta tela existe para evitar.
 */

/** Doses de referência da tabela institucional, em mg/kg de peso ajustado. */
const ESQUEMAS = [
  { farmaco: 'Amicacina', ataque: 15, manutencao: '15 mg/kg 1x/dia se ClCr > 50' },
  { farmaco: 'Gentamicina', ataque: 5, manutencao: '5 mg/kg 1x/dia se ClCr > 80' },
  {
    farmaco: 'Gentamicina — sinergismo',
    ataque: 1,
    manutencao: '1 mg/kg a cada 8 h, apenas na endocardite',
  },
] as const

export function PesoAminoglicosideo() {
  const [peso, setPeso] = useState<number | undefined>(undefined)
  const [altura, setAltura] = useState<number | undefined>(undefined)
  const [sexo, setSexo] = useState<Sexo | undefined>(undefined)

  const completo =
    peso !== undefined && peso > 0 && altura !== undefined && altura > 0 && sexo !== undefined

  const ideal = completo ? pesoIdealDevine(altura, sexo) : undefined
  const ajustado = completo && ideal !== undefined ? pesoAjustado(peso, ideal) : undefined
  // Quando o paciente pesa menos que o ideal, a fórmula devolve o peso real —
  // vale sinalizar, porque a conta "parece" não ter sido aplicada.
  const usouPesoReal = completo && ajustado !== undefined && peso <= (ideal ?? 0)

  return (
    <div className="space-y-4 px-4 py-4">
      <div className="grid grid-cols-3 gap-3">
        {(
          [
            { rotulo: 'Peso real', valor: peso, set: setPeso, sufixo: 'kg', step: '0.1', ph: '95' },
            { rotulo: 'Altura', valor: altura, set: setAltura, sufixo: 'cm', step: '1', ph: '172' },
          ] as const
        ).map((c) => (
          <label key={c.rotulo} className="block">
            <span className="kicker">{c.rotulo}</span>
            <div className="mt-1 flex items-center gap-1.5">
              <input
                type="number"
                inputMode="decimal"
                step={c.step}
                value={c.valor ?? ''}
                placeholder={c.ph}
                onChange={(e) => c.set(e.target.value === '' ? undefined : Number(e.target.value))}
                aria-label={`${c.rotulo} para aminoglicosídeo`}
                className="w-full rounded-md border border-border bg-input px-2.5 py-2 text-base font-semibold text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-ring"
              />
              <span className="shrink-0 text-xs text-muted-foreground">{c.sufixo}</span>
            </div>
          </label>
        ))}

        <div>
          <span className="kicker">Sexo</span>
          <div className="mt-1 flex gap-1.5">
            {(['M', 'F'] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSexo(s)}
                aria-pressed={sexo === s}
                className={cn(
                  'flex-1 rounded-md border py-2 text-sm font-bold transition-colors',
                  sexo === s
                    ? 'border-primary bg-primary/15 text-primary'
                    : 'border-border bg-secondary/60 text-muted-foreground hover:bg-secondary',
                )}
              >
                {s === 'M' ? 'M' : 'F'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {!completo && (
        <p className="text-sm text-muted-foreground">
          Informe peso, altura e sexo. A creatinina não entra nesta conta — ela serve
          para o ajuste renal, na ficha 04.
        </p>
      )}

      {completo && ideal !== undefined && ajustado !== undefined && (
        <>
          <div className="rounded-md border border-primary/40 bg-primary/10 p-4">
            <p className="kicker">Peso a usar na prescrição</p>
            <p className="mt-1 text-3xl font-bold tabular-nums text-primary">
              {formatarNumero(ajustado)} <span className="text-base font-normal">kg</span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Real {formatarNumero(peso)} kg · Ideal {formatarNumero(ideal)} kg ·
              Pajustado = Pideal + 0,4 × (Patual − Pideal)
            </p>
          </div>

          {usouPesoReal && (
            <Callout severidade="info" titulo="Peso abaixo do ideal">
              O peso real é menor ou igual ao ideal, então o ajustado seria maior que o
              próprio paciente. Nesse caso vale o <strong>peso real</strong> — usar a
              fórmula crua superdosaria.
            </Callout>
          )}

          <div className="overflow-x-auto">
            <table className="w-full min-w-[420px] border-collapse text-sm">
              <caption className="sr-only">
                Doses de aminoglicosídeo para {formatarNumero(ajustado)} kg de peso ajustado
              </caption>
              <thead>
                <tr className="border-b border-border text-left">
                  <th scope="col" className="kicker pb-2 pr-3">Fármaco</th>
                  <th scope="col" className="kicker pb-2 pr-3">Ataque</th>
                  <th scope="col" className="kicker pb-2">Manutenção</th>
                </tr>
              </thead>
              <tbody>
                {ESQUEMAS.map((e) => (
                  <tr key={e.farmaco} className="border-b border-border/60 align-top">
                    <td className="py-2 pr-3 font-semibold text-foreground">{e.farmaco}</td>
                    <td className="py-2 pr-3 font-bold text-primary">
                      {formatarNumero(Math.round(e.ataque * ajustado))} mg
                      <span className="block text-[11px] font-normal text-muted-foreground">
                        {e.ataque} mg/kg
                      </span>
                    </td>
                    <td className="py-2 text-xs text-muted-foreground">{e.manutencao}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <Callout severidade="atencao" titulo="A manutenção depende do clearance">
            Os valores acima são a <strong>dose de ataque</strong>, que não se ajusta pela
            função renal. A manutenção muda conforme o ClCr — use a ficha 04 para a faixa
            aplicável, que já sai convertida com este mesmo peso ajustado.
          </Callout>
        </>
      )}

      <p className="text-[11px] leading-relaxed text-muted-foreground">
        Peso ideal pela fórmula de Devine, adotada como padrão institucional para
        compor o peso ajustado dos aminoglicosídeos.
      </p>
    </div>
  )
}
