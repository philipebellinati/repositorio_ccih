import type { Drug } from '@/domain/types'

/**
 * Catálogo de antimicrobianos citados no protocolo.
 *
 * `tetoAdultoPorDose` é a maior dose adulta prevista NO PRÓPRIO protocolo para
 * o fármaco. Serve exclusivamente como salvaguarda pediátrica: quando a dose
 * ponderal calculada ultrapassa a dose de um adulto, o app emite alerta
 * (nunca trunca a dose por conta própria). O protocolo não estabelece teto —
 * ver ambiguidade A-09 no README.
 */
export const DRUGS: Record<string, Drug> = {
  ceftriaxona: {
    id: 'ceftriaxona',
    nome: 'Ceftriaxona',
    classe: 'Cefalosporina de 3ª geração',
    tetoAdultoPorDose: { valor: 2000, unidade: 'mg' },
    tetoDiarioMg: 4000,
  },
  cefepime: {
    id: 'cefepime',
    nome: 'Cefepime',
    classe: 'Cefalosporina de 4ª geração',
    tetoAdultoPorDose: { valor: 2000, unidade: 'mg' },
    tetoDiarioMg: 6000,
    avisos: [
      'Adulto: usar 2 g em Pseudomonas, meningite, neutropenia febril e ' +
        'sepse/choque séptico. Fora dessas situações, a dose usual é menor — ver a ' +
        'ficha de ajuste por função renal.',
    ],
  },
  azitromicina: {
    id: 'azitromicina',
    nome: 'Azitromicina',
    classe: 'Macrolídeo',
    tetoAdultoPorDose: { valor: 500, unidade: 'mg' },
    tetoDiarioMg: 500,
    avisos: [
      'Eliminação predominantemente biliar: NÃO requer ajuste por função renal.',
    ],
  },
  clindamicina: {
    id: 'clindamicina',
    nome: 'Clindamicina',
    classe: 'Lincosamida',
    tetoAdultoPorDose: { valor: 900, unidade: 'mg' },
    tetoDiarioMg: 4800,
  },
  piperacilina_tazobactam: {
    id: 'piperacilina_tazobactam',
    nome: 'Piperacilina/tazobactam',
    sinonimos: ['Tazocin'],
    classe: 'Penicilina de espectro estendido + inibidor de betalactamase',
    tetoAdultoPorDose: { valor: 4500, unidade: 'mg' },
    // Teto diário do COMPONENTE PIPERACILINA, conforme bula (Zosyn/FDA).
    tetoDiarioMg: 24000,
    avisos: [
      'Em pediatria o mg/kg é calculado APENAS sobre o componente piperacilina ' +
        '(proporção 8:1). O frasco dispensado traz os dois componentes.',
      'Acima de 40 kg, usar dose de ADULTO — coerente com o critério ' +
        'institucional de adulto (≥ 12 anos ou > 40 kg).',
      'Dose diária máxima de 24 g de piperacilina.',
    ],
  },
  metronidazol: {
    id: 'metronidazol',
    nome: 'Metronidazol',
    classe: 'Nitroimidazólico',
    tetoAdultoPorDose: { valor: 500, unidade: 'mg' },
    tetoDiarioMg: 4000,
  },
  ciprofloxacino: {
    id: 'ciprofloxacino',
    nome: 'Ciprofloxacino',
    classe: 'Fluoroquinolona',
    tetoAdultoPorDose: { valor: 400, unidade: 'mg' },
    avisos: [
      'O protocolo não prevê fluoroquinolona nas tabelas pediátricas; uso em ' +
        '< 18 anos exige justificativa e discussão com o SCIH.',
    ],
  },
  oxacilina: {
    id: 'oxacilina',
    nome: 'Oxacilina',
    classe: 'Penicilina penicilinase-resistente',
    tetoAdultoPorDose: { valor: 2000, unidade: 'mg' },
    tetoDiarioMg: 12000,
  },
  gentamicina: {
    id: 'gentamicina',
    nome: 'Gentamicina',
    classe: 'Aminoglicosídeo',
    avisos: [
      'Usar PESO AJUSTADO: Pajustado = Pideal + 0,4 × (Patual − Pideal). ' +
        'A calculadora está na ficha de ajuste por função renal.',
      'Monitorar função renal. Dose máxima 7 mg/kg. A dose de 1 mg/kg a cada 8 h ' +
        'destina-se apenas a sinergismo na endocardite.',
    ],
  },
  amicacina: {
    id: 'amicacina',
    nome: 'Amicacina',
    classe: 'Aminoglicosídeo',
    avisos: [
      'Usar PESO AJUSTADO: Pajustado = Pideal + 0,4 × (Patual − Pideal). ' +
        'A calculadora está na ficha de ajuste por função renal.',
      'Monitorar função renal. Dose máxima 25–30 mg/kg/dia.',
      'No NEONATO o protocolo grafa "5–7 mg/kg até 8/8h", que não discrimina ' +
        'maturidade renal. Vale a TABELA NEONATAL por idade gestacional e ' +
        'pós-natal, que substitui esse valor — ficha de amicacina neonatal.',
    ],
  },
  ampicilina: {
    id: 'ampicilina',
    nome: 'Ampicilina',
    classe: 'Aminopenicilina',
  },
  meropenem: {
    id: 'meropenem',
    nome: 'Meropenem',
    classe: 'Carbapenêmico',
    tetoAdultoPorDose: { valor: 2000, unidade: 'mg' },
    tetoDiarioMg: 6000,
    avisos: [
      'Antimicrobiano de uso restrito: preencher o formulário de solicitação e ' +
        'notificar o SCIH (item 4 do protocolo).',
    ],
  },
  dexametasona: {
    id: 'dexametasona',
    nome: 'Dexametasona',
    classe: 'Corticosteroide adjuvante',
    tetoAdultoPorDose: { valor: 10, unidade: 'mg' },
    avisos: [
      'TIMING É DECISIVO: administrar de 10 a 20 minutos ANTES da primeira dose ' +
        'do antibiótico, ou junto com ela. Iniciada depois, perde o benefício.',
      'Duração de 4 dias. Adjuvante da meningite bacteriana — não substitui nem ' +
        'atrasa o antimicrobiano.',
    ],
  },
  vancomicina: {
    id: 'vancomicina',
    nome: 'Vancomicina',
    classe: 'Glicopeptídeo',
    protocoloExterno: 'Protocolo de Vancomicina',
    avisos: [
      'Nota ¹: a posologia não consta das tabelas empíricas. Ataque, manutenção ' +
        'por clearance e correção por vancocinemia estão na ficha de Vancomicina ' +
        'deste guia — adulto e neonatal/pediátrico têm tabelas distintas.',
    ],
  },
}

/** Acesso seguro ao catálogo — usado pelo motor, que trata a ausência como erro. */
export function findDrug(id: string): Drug | undefined {
  return DRUGS[id]
}
