import { describe, expect, it } from 'vitest'
import {
  ALTERNATIVAS_ALERGIA,
  RESTRITOS,
  DOSES_PEDIATRICAS,
  FOCOS,
} from '@/data'

/**
 * Invariantes das bases de dados acrescentadas na rodada de padronização.
 *
 * Não testam React nem layout — testam que os DADOS estão completos e coerentes,
 * que é onde mora o risco clínico. Um foco sem alternativa de alergia, um nome
 * comercial vazando para a tela ou um mg/kg com intervalo impossível passam
 * despercebidos a olho e são exatamente o que estes testes travam.
 */

// ---------------------------------------------------------------------------
describe('alternativas de alergia cobrem TODOS os focos', () => {
  const focosComAlternativa = new Set(ALTERNATIVAS_ALERGIA.map((a) => a.focoId))

  it('todo foco do catálogo tem uma alternativa sem betalactâmico', () => {
    const semAlternativa = Object.keys(FOCOS).filter((id) => !focosComAlternativa.has(id))
    expect(semAlternativa, `focos sem alternativa: ${semAlternativa.join(', ')}`).toEqual([])
  })

  it('toda alternativa aponta para um foco existente', () => {
    for (const a of ALTERNATIVAS_ALERGIA) {
      expect(FOCOS[a.focoId], a.focoId).toBeDefined()
    }
  })

  it('todo esquema traz ao menos uma droga destacada', () => {
    for (const a of ALTERNATIVAS_ALERGIA) {
      expect(a.esquema, a.focoId).toMatch(/__[^_]+__/)
    }
  })

  it('os focos sem bom substituto estão sinalizados, não escondidos', () => {
    // Meningite, PAV, sepse e prótese são os pontos frágeis reconhecidos.
    const incertos = ALTERNATIVAS_ALERGIA.filter((a) => a.incerto).map((a) => a.focoId)
    expect(incertos).toEqual(expect.arrayContaining(['meningite', 'pnm_vm']))
  })
})

// ---------------------------------------------------------------------------
describe('antimicrobianos restritos', () => {
  it('cada restrito declara classe e alvo microbiológico', () => {
    expect(RESTRITOS.length).toBeGreaterThanOrEqual(6)
    for (const r of RESTRITOS) {
      expect(r.classe, r.id).toBeTruthy()
      expect(r.alvo, r.id).toBeTruthy()
    }
  })

  it('os seis agentes definidos pelo SCIH estão na lista', () => {
    const ids = new Set(RESTRITOS.map((r) => r.id))
    for (const esperado of [
      'ceftazidima_avibactam',
      'ceftolozana_tazobactam',
      'linezolida',
      'anfotericina_lipossomal',
      'voriconazol',
      'ampicilina_sulbactam',
    ]) {
      expect(ids.has(esperado), esperado).toBe(true)
    }
  })
})

// ---------------------------------------------------------------------------
describe('doses pediátricas — transcrição do quadro do HU', () => {
  it('cada droga tem apresentação, diluição e ao menos uma faixa de clearance', () => {
    for (const d of DOSES_PEDIATRICAS) {
      expect(d.apresentacao, d.id).toBeTruthy()
      expect(d.diluicao, d.id).toBeTruthy()
      expect(d.clearance.length, d.id).toBeGreaterThan(0)
    }
  })

  it('as drogas restritas do quadro estão marcadas como tal', () => {
    for (const id of ['linezolida', 'anfotericina_lipossomal', 'voriconazol', 'ampicilina_sulbactam']) {
      const d = DOSES_PEDIATRICAS.find((x) => x.id === id)
      expect(d?.restrito, id).toBeTruthy()
    }
  })

  it('pesoCalc, quando existe, tem base e intervalo válidos', () => {
    const intervalosValidos = new Set([4, 6, 8, 12, 24])
    for (const d of DOSES_PEDIATRICAS) {
      if (!d.pesoCalc) continue
      expect(['dose', 'dia'], d.id).toContain(d.pesoCalc.base)
      expect(intervalosValidos.has(d.pesoCalc.intervaloHoras), `${d.id} intervalo`).toBe(true)
      const { valor } = d.pesoCalc
      const nums = Array.isArray(valor) ? valor : [valor]
      for (const n of nums) expect(n, d.id).toBeGreaterThan(0)
    }
  })

  it('nenhum nome comercial aparece em campo exibido (só em sinônimos)', () => {
    const marcas = /tazocin|unasyn|bactrim|synercid|zosyn|zerbaxa|torgena/i
    for (const d of DOSES_PEDIATRICAS) {
      const exibidos = [
        d.nome,
        d.classe ?? '',
        d.apresentacao,
        d.diluicao,
        d.infusao,
        ...(d.observacoes ?? []),
        d.alerta ?? '',
        d.restrito ?? '',
        d.neonatalNota ?? '',
        ...d.clearance.flatMap((c) => [c.faixa, c.dose]),
      ].join(' | ')
      expect(marcas.test(exibidos), `${d.id}: nome comercial em campo exibido`).toBe(false)
    }
  })
})
