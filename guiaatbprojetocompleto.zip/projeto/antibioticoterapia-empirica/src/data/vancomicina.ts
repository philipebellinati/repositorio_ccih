/**
 * Protocolo de Vancocinemia.
 *
 * Preenche a maior lacuna do protocolo empírico: onde as tabelas escrevem
 * "Vancomicina¹", a posologia vivia em documentos separados. São dois
 * protocolos distintos, com lógicas de ajuste diferentes:
 *
 *  • ADULTO — dose de ataque por peso real, manutenção por ClCr, correção por
 *    vancocinemia em miligramas absolutos (aumentar/diminuir 250–500 mg);
 *  • NEONATAL E PEDIÁTRICO — SEM dose de ataque, manutenção por creatinina
 *    sérica (neonato) ou ClCr (pediátrico), correção por vancocinemia em
 *    PERCENTUAL da dose vigente.
 *
 * Confundir as duas tabelas de correção é o erro mais provável de quem usa o
 * guia com pressa — por isso elas nunca aparecem juntas na interface.
 */

// ---------------------------------------------------------------------------
// ADULTO
// ---------------------------------------------------------------------------

export const VANCO_ADULTO = {
  ataque: {
    dose: '25 a 30 mg/kg de PESO REAL',
    maxima: '2 g',
    observacao: 'Independe da função renal.',
  },
  alvoVale: {
    faixa: '15 a 20 mg/L',
    abaixo: 'Valores < 10 mg/L podem gerar falha terapêutica e induzir resistência.',
    acima: 'Valores > 25 mg/L podem levar a toxicidade.',
    observacao:
      'O alvo de 15 a 20 mg/L vale tanto para infecções graves quanto não graves.',
  },
  indicacaoMonitoramento:
    'Monitorar em pacientes com tratamento previsto por mais de 48 horas.',
  manutencao: [
    { clcr: '> 90', dose: '15 mg/kg/dose', intervalo: '8/8h', primeiraDosagem: '1 h a 30 min antes da 4ª dose' },
    { clcr: '50–90', dose: '15 mg/kg/dose', intervalo: '12/12h', primeiraDosagem: '1 h a 30 min antes da 4ª dose' },
    { clcr: '< 50', dose: '15 mg/kg/dose', intervalo: '1x/dia', primeiraDosagem: '1 h a 30 min antes da 4ª dose' },
    {
      clcr: 'Hemodiálise',
      dose: '10 mg/kg ACM, conforme vancocinemia (máximo 1500 mg)',
      intervalo: 'ACM',
      primeiraDosagem: 'Após 48 h da 1ª dose; depois coletar diariamente na rotina',
    },
  ],
  doseMaxima: '2 g 8/8h',
  correcao: [
    {
      nivel: '< 5',
      q8h: 'Aumentar 500 mg, manter 8/8h. Se continuar não atingindo o nível, trocar o ATB',
      q12h: 'Alterar para 8/8h, mesma dose',
      q24h: 'Alterar para 12/12h, mesma dose',
    },
    {
      nivel: '5,1–10',
      q8h: 'Aumentar 500 mg, manter 8/8h',
      q12h: 'Aumentar 500 mg, manter 12/12h',
      q24h: 'Aumentar 500 mg, manter 1x/dia',
    },
    {
      nivel: '10,1–15',
      q8h: 'Aumentar 250 mg, manter 8/8h',
      q12h: 'Aumentar 250 mg, manter 12/12h',
      q24h: 'Aumentar 250 mg, manter 1x/dia',
    },
    {
      nivel: '15,1–25',
      q8h: 'Manter dose atual',
      q12h: 'Manter dose atual',
      q24h: 'Manter dose atual',
    },
    {
      nivel: '25–50',
      q8h: 'Suspender por 24 h; diminuir 250 mg, manter 8/8h',
      q12h: 'Suspender por 24 h; diminuir 250 mg, manter 12/12h',
      q24h: 'Suspender por 24 h; diminuir 250 mg, manter 1x/dia',
    },
    {
      nivel: '> 50',
      q8h: 'Suspender por 48 h',
      q12h: 'Suspender por 48 h',
      q24h: 'Suspender por 48 h',
    },
  ],
  notas: [
    'Suspensão por nível > 50: monitorar a vancocinemia até < 25 mg/L; ao atingir, ' +
      'retornar com dose 250 mg menor, ou conferir se a dose está em 15 mg/kg.',
    'Nível estável (duas vancocinemias seguidas entre 15 e 20 mg/L): se função renal ' +
      'normal e paciente hemodinamicamente estável, coletar 1x por semana; se função ' +
      'renal alterada ou instabilidade hemodinâmica, a cada 2 dias.',
    'Após ajustes, repetir a vancocinemia no vale da 4ª dose, ou após 48 h em doses 1x/dia.',
    'O pedido de dosagem sérica DEVE conter horário — pedidos sem horário não são coletados.',
    'Ao suspender por nível alto, deixar a prescrição em ACM: não gera horários de ' +
      'administração, mas mantém o medicamento na prescrição, contando os dias de ' +
      'tratamento e evitando esquecer que o paciente está em uso.',
  ],
  hemodialise: [
    'Dose de ataque 25 mg/kg (máximo 2 g).',
    'Manutenção 10 mg/kg, prescrita em ACM.',
    'Primeira dosagem 48 h após o ataque.',
    'Pedir dosagem diária, coletada na ROTINA.',
    'Se a dosagem estiver abaixo de 25 mg/L, realizar a dose do dia — prescrevendo na urgência.',
  ],
} as const

// ---------------------------------------------------------------------------
// NEONATAL E PEDIÁTRICO
// ---------------------------------------------------------------------------

export const VANCO_NEOPED = {
  semAtaque: 'Em neonatologia e pediatria NÃO se faz dose de ataque.',
  /** Neonato < 28 dias: a manutenção é definida pela CREATININA, não pelo ClCr. */
  neonatalPorCreatinina: [
    { creatinina: '< 0,7 mg/dL', dose: '15 mg/kg/dose', intervalo: '12/12h' },
    { creatinina: '0,7 a 0,9 mg/dL', dose: '20 mg/kg/dose', intervalo: '24/24h' },
    { creatinina: '1 a 1,2 mg/dL', dose: '15 mg/kg/dose', intervalo: '24/24h' },
    { creatinina: '1,3 a 1,6 mg/dL', dose: '10 mg/kg/dose', intervalo: '24/24h' },
    { creatinina: '> 1,6 mg/dL', dose: '15 mg/kg/dose', intervalo: '48/48h' },
  ],
  aposPeriodoNeonatal: '10 a 15 mg/kg a cada 6 h — máximo de 2 g/dia.',
  /** Pediátrico com injúria renal aguda: aí sim por ClCr. */
  pediatricoIRA: [
    { clcr: '> 50 mL/min', dose: '10 a 15 mg/kg/dose', intervalo: '6/6h' },
    { clcr: '10 a 50 mL/min', dose: '15 mg/kg/dose', intervalo: '24/24h' },
    { clcr: '< 10 mL/min', dose: '7,5 mg/kg/dose', intervalo: '48/48h ou 72/72h' },
  ],
  administracao: [
    'Dose de manutenção: infundir em 2 horas.',
    'Diluição em SF 0,9%: 5 mg de vancomicina por 1 mL.',
    'Coletar a vancocinemia no vale — 30 a 60 min antes da dose.',
  ],
  /** Correção em PERCENTUAL — diferente do adulto, que corrige em miligramas. */
  correcao: [
    { nivel: '< 5 mcg/mL', conduta: 'Aumentar a dose em 75%', recoleta: 'Antes da 4ª/5ª dose ajustada' },
    { nivel: '5 a 10 mcg/mL', conduta: 'Aumentar a dose em 50%', recoleta: 'Antes da 4ª/5ª dose ajustada' },
    { nivel: '11 a 14 mcg/mL', conduta: 'Aumentar a dose em 25%', recoleta: 'Antes da 4ª/5ª dose ajustada' },
    { nivel: '15 a 20 mcg/mL', conduta: 'Manter a dose', recoleta: 'Medir novamente em 48 h' },
    {
      nivel: '20 a 50 mcg/mL',
      conduta: 'Suspender por 24 h; reiniciar com redução de 20 a 30% da dose anterior',
      recoleta: 'Antes da 4ª/5ª dose ajustada',
    },
    {
      nivel: '> 50 mcg/mL',
      conduta: 'Suspender por 48 h; reiniciar com redução de 50% da dose anterior',
      recoleta: 'Antes da 4ª/5ª dose ajustada',
    },
  ],
  notas: [
    'Para infecção do SNC, considerar nível sérico terapêutico de 20 a 30 mcg/mL.',
    'Após duas medidas entre 15 e 20 mcg/mL: se função renal e hemodinâmica estáveis, ' +
      'monitorizar 1x por semana; se instáveis, a cada 48 h.',
  ],
  /** Tempo até o estado de equilíbrio, que define quando faz sentido coletar. */
  estadoDeEquilibrio: [
    { idade: 'Prematuro 27 a 30 semanas', meiaVida: '6,6 ± 0,4 h', equilibrio: '31–35 h' },
    { idade: 'Prematuro 31 a 36 semanas', meiaVida: '5,6 ± 0,4 h', equilibrio: '26–30 h' },
    { idade: 'Prematuro > 37 semanas', meiaVida: '4,9 ± 0,4 h', equilibrio: '23–27 h' },
    { idade: 'Recém-nascido a termo', meiaVida: '6,7 h', equilibrio: '34 h' },
    { idade: 'Lactente (≥ 1 mês e < 1 ano)', meiaVida: '4,1 h', equilibrio: '21 h' },
    { idade: 'Criança (2,5 a 11 anos)', meiaVida: '5,6 ± 2,1 h', equilibrio: '18–39 h' },
  ],
} as const
