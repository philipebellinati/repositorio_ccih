# Antibioticoterapia Empírica — guia de bolso

Guia de consulta rápida do **Protocolo de Antibioticoterapia Empírica** do SCIH do
Hospital Evangélico de Londrina (revisão de 20/03/2026, válida até 20/03/2028).

Abre no celular, não precisa instalar nada e funciona sem internet depois da primeira
visita.

---

## O que dá para fazer

| Recurso | Como funciona |
| --- | --- |
| **Busca por foco ou antibiótico** | Digitar `pav`, `meningite`, `cefepime` ou `tazocin` filtra as fichas **e** as linhas dentro das tabelas — cai direto na dose. |
| **16 fichas por contexto** | Chips de `Fluxo`, `Doses`, `Adulto`, `UTI adulto`, `Pediatria`, `UTI neo · ped`, `Segurança` e `Referência`. |
| **Modo alergia** | Marca em vermelho todo esquema que contém betalactâmico. O protocolo **não define substituto** — o guia sinaliza o problema, não inventa a troca (ver A-05). |
| **Calculadora de dose por peso** | Converte todas as posologias em mg/kg do protocolo e troca sozinha para o esquema pediátrico. |
| **Cronômetro de janelas** | Marca a suspeita clínica (janela de 1–3 h para a primeira dose) e a primeira dose (janela de 48–72 h para reavaliação). |
| **PWA offline** | Safari → Compartilhar → “Adicionar à tela de início”. Vira ícone e abre sem rede. |

---

## Arquitetura

O princípio de projeto é um só: **o protocolo é dado, não código.**

```
src/
├── domain/            # regras de negócio, sem React
│   ├── types.ts       # modelo do domínio + variáveis clínicas
│   ├── dosing.ts      # cálculo mg/kg, faixas, arredondamento, teto adulto
│   ├── engine.ts      # roteamento de seção → seleção de regra → alertas
│   ├── format.ts      # formatação das linhas para as tabelas do guia
│   └── errors.ts      # ProtocolError com orientação acionável
├── data/              # conteúdo clínico transcrito do PDF
│   ├── drugs.ts       # catálogo de antimicrobianos
│   ├── protocol.meta.ts # cabeçalho, fluxo, notas de rodapé, focos, seções
│   ├── tables/        # secao-6-1 … secao-6-6 (uma por tabela do PDF)
│   └── cards.ts       # as 16 fichas do guia
├── components/        # UI
├── pages/Guia.tsx     # tela única
└── __tests__/         # 59 testes sobre as regras clínicas
```

Consequências práticas:

- **As tabelas exibidas e as doses calculadas vêm da mesma fonte.** `TabelaSecao`
  renderiza a partir de `REGRAS_POR_SECAO`, exatamente o que o motor consome. Não há
  como a tela mostrar uma coisa e a calculadora outra.
- **Uma revisão do protocolo se absorve editando `src/data/`**, sem tocar no motor nem
  na interface.
- **Cada regra carrega `textoOriginal`**, o texto literal da célula do PDF, exibido sob
  cada esquema para conferência lado a lado com o documento impresso.

### Como uma linha do protocolo é modelada

Cada célula das tabelas vira uma `ProtocolRule` com um predicado `match` e uma
`prioridade`. As regras de um mesmo foco são avaliadas por prioridade decrescente e a
primeira que casa vence — assim as linhas condicionais (“Aspirativa”, “assoc. a
cateter”, “Se Enterococcus/anaeróbio”) sempre precedem a linha “1ª opção”, que é o
fallback de prioridade 0.

```ts
{
  id: '6.5.pnm.pav-tardia',
  secao: '6.5',
  focoId: 'pnm_vm',
  condicaoLabel: 'PAV Tardia (> 5 dias)',
  prioridade: 40,
  match: (m) => typeof m.diasVentilacaoMecanica === 'number' && m.diasVentilacaoMecanica > 5,
  prescricoes: [{ drugId: 'meropenem', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q8h' }],
  textoOriginal: 'Meropenem 2g EV 8/8h',
}
```

### Decisões de segurança clínica

1. **Nunca inventar conduta.** Se a combinação de variáveis não existe no protocolo, o
   motor lança `ProtocolError` com uma orientação para acionar o SCIH — jamais um
   “melhor palpite”. É o caso de infecção comunitária em neonato, por exemplo.
2. **Peso ausente não bloqueia o esquema.** A dose ponderal aparece como está no
   protocolo (`5–7 mg/kg/dia`) com aviso, e as demais doses do mesmo esquema seguem
   calculadas. Peso *inválido*, ao contrário, é erro — calcular sobre número errado é
   pior que não calcular.
3. **“+/-” nunca vira associação automática.** Itens facultativos saem separados do
   esquema principal, com o critério ao lado. A única promoção automática é a
   Vancomicina em meningite pediátrica, porque a nota ⁴ é imperativa — e ela vem sempre
   acompanhada do alerta correspondente.
4. **Teto pediátrico é salvaguarda, não truncamento.** Quando a dose por peso ultrapassa
   a maior dose adulta prevista no próprio protocolo, o app **avisa**; nunca corta a dose
   sozinho.
5. **Vancomicina não recebe dose.** Onde o protocolo escreve “Vancomicina¹”, o guia
   exibe alerta crítico remetendo ao Protocolo de Vancomicina institucional.

---

## Ambiguidades e lacunas do protocolo

Levantadas na leitura do PDF e sinalizadas dentro do próprio app. **Nenhuma foi
resolvida por conta própria** — todas aparecem como aviso ao usuário.

### Variáveis faltantes (impedem automação completa)

| # | Lacuna | Como o app se comporta |
| --- | --- | --- |
| A-01 | Não há ponto de corte entre **adulto e pediatria** (idade ou peso). | A escolha é do prescritor. O corte de 40 kg da calculadora é convenção do app e afeta só o destaque visual, nunca a dose. |
| A-02 | “Neonatal” x “> 28 dias” é usado sem definição explícita. | Adotado ≤ 28 dias de vida, única leitura compatível com o par de linhas de 6.6. Idade incoerente gera aviso. |
| A-03 | O “**+/- Azitromicina**” não tem critério objetivo. | Exibido como facultativo, com o critério em aberto declarado. |
| A-04 | **Cefepime “1-2 g”** sem critério de escolha da dose. | Faixa exibida integralmente, com observação. |
| A-05 | **Alergia a betalactâmicos** não tem esquema substituto. | Modo ALERGIA marca os esquemas afetados e direciona ao SCIH; não sugere troca. |
| A-06 | **Duração de tratamento** não é definida. | Aviso na ficha 02. |
| A-07 | PAV: “precoce (< 5 dias)” e “tardia (> 5 dias)” deixam o **5º dia** sem regra. | Classificado como precoce (menor espectro), com aviso na ficha 07. |
| A-08 | Em 6.6 o par “Sepse s/ foco — 1ª/2ª opção” aparece **duplicado**. | Consolidado em um par único, com aviso na ficha 10. |
| A-09 | Não há **teto de dose pediátrica**. | Alerta quando a dose calculada supera a maior dose adulta do protocolo. |
| A-10 | **Gentamicina**: peso de referência (real, ideal, ajustado) não especificado. | Aviso no catálogo do fármaco. |
| A-11 | **Amicacina “até 8/8h”**: intervalo mínimo por idade não definido. | Exibido q8h com aviso para individualizar. |
| A-12 | Não há tabela para **infecção comunitária em neonato**. | Motor recusa e orienta a acionar o SCIH. |
| A-13 | Nota ⁴ diz “menores de **a** anos” (erro de digitação). | Aplicado < 5 anos, que é o explicitado na frase principal da mesma nota. Sinalizado na ficha 12. |
| A-14 | **Dexametasona** em meningite não é mencionada. | Aviso na ficha 12. |
| A-15 | Não há **ajuste de dose por função renal**. | Aviso na ficha 13. |

### Inconsistências menores de transcrição

- “**Tazocin**” (nome comercial) é usado em 6.2 enquanto as demais seções usam
  “Piperacilina/tazobactam”. O app prescreve pelo princípio ativo e registra o sinônimo,
  buscável.
- 6.1 pele com necrose grafa “Ceftriaxona 2g/dia” sem a via; interpretado como EV, como
  em todas as demais linhas da tabela.
- A endocardite pediátrica (6.3) não tem célula de CONDIÇÃO; rotulada “Aguda”, como no
  cabeçalho da linha.
- **A endocardite do adulto depende de peso** (Gentamicina 5–7 mg/kg), o que não é óbvio
  numa tabela de doses fixas. O app trata o caso explicitamente.

---

## Desenvolvimento

```bash
npm install
npm run dev           # servidor de desenvolvimento
npm test              # 59 testes das regras clínicas
npm run typecheck     # tsc --noEmit
npm run build         # typecheck + build de produção
npm run build:single  # arquivo HTML único, self-contained
```

### Distribuição como arquivo único

`npm run build:single` gera `dist-single/guia-antibioticoterapia-empirica.html` (~250 KB)
com CSS e JavaScript embutidos. Como o app não faz nenhuma requisição de rede — todo o
conteúdo clínico vive no bundle —, esse arquivo abre e funciona offline por construção:
serve para intranet sem deploy, anexo de e-mail ou pendrive, sem depender de servidor
estático.

### Ícones do PWA

O repositório versiona apenas `public/icon.svg`, que já atende ao manifest. O
`apple-touch-icon` do iOS, porém, **exige PNG**. Rode uma vez antes do primeiro deploy:

```bash
npm run icons   # grava public/icon-180.png, icon-192.png e icon-512.png
```

Depois, descomente a linha `apple-touch-icon` no `index.html`. Sem esse passo o app
continua instalável, mas o iOS usa uma miniatura da página no lugar do ícone.

### Sobre os testes

A suíte não persegue cobertura de linhas — ela prova que **cada célula das tabelas
6.1–6.6 é alcançável e devolve o esquema impresso no documento**. Um erro ali é um erro
de prescrição. Destaques:

- varredura por força bruta sobre todo o espaço de modificadores, provando que **nenhuma
  regra do protocolo é inalcançável**;
- verificação de que cada foco de cada seção tem exatamente um fallback de prioridade 0;
- as substituições de 6.6 (“trocar Gentamicina por Cefepime”) são testadas como
  substituição, não associação;
- integridade referencial: todo `drugId` e todo `focoId` existem nos catálogos.

## Deploy na Vercel

O `vercel.json` já está configurado. Como o projeto vive numa subpasta do repositório,
defina o **Root Directory** do projeto Vercel como `antibioticoterapia-empirica`.

```bash
npx vercel --prod
```

---

## Aviso

Guia de consulta rápida. **Em qualquer divergência vale o protocolo institucional na
íntegra.** Não substitui julgamento clínico nem dispensa a avaliação do SCIH. Erros ou
lacunas devem ser comunicados ao Serviço de Controle de Infecção Hospitalar.

Responsabilidade técnica: Dr. Philipe Bellinati — Coordenador do SCIH.
