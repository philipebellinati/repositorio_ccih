import { useMemo, useState } from 'react'
import { Lock, AlertTriangle, Search } from 'lucide-react'
import { DOSES_PEDIATRICAS, type DosePediatrica } from '@/data'
import { arredondarMg, formatarMg, isFaixa } from '@/domain/dosing'
import type { Quantidade } from '@/domain/types'

/**
 * Doses e diluições pediátricas — quadro da UTI Pediátrica do HU de Londrina.
 *
 * É uma FICHA DE REFERÊNCIA, não um motor de decisão: mostra a dose por faixa
 * de clearance e a grade neonatal de cada droga. Quando há peso informado e a
 * dose-normal é um mg/kg limpo, converte em miligramas por dose e por dia — mas
 * só nesses casos, porque doses por superfície, UI ou mg/kg/dia heterogêneo não
 * têm conversão segura por peso.
 */
export function DosesPediatricas({ pesoKg }: { pesoKg?: number }) {
  const [filtro, setFiltro] = useState('')

  const lista = useMemo(() => {
    const t = filtro.trim().toLowerCase()
    if (!t) return DOSES_PEDIATRICAS
    return DOSES_PEDIATRICAS.filter((d) => {
      const alvos = [d.nome, d.classe ?? '', ...(d.sinonimos ?? [])].join(' ').toLowerCase()
      return alvos.includes(t)
    })
  }, [filtro])

  return (
    <div className="space-y-3 px-4 py-4">
      <div className="rounded-md border border-primary/30 bg-primary/5 p-3 text-xs leading-relaxed text-foreground/90">
        Fonte institucional das doses pediátricas (base Sanford 45ª ed., Nelson e Red
        Book). Diz a <strong>dose de cada droga</strong>; o protocolo empírico continua
        dizendo <strong>qual droga</strong> usar em cada foco. As doses estão fiéis ao
        documento — pontos ambíguos levam aviso de conferência.
      </div>

      <label className="block">
        <span className="sr-only">Filtrar antimicrobiano</span>
        <div className="relative">
          <Search
            aria-hidden
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
          />
          <input
            type="search"
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
            placeholder="Filtrar por antimicrobiano"
            className="w-full rounded-md border border-border bg-input py-2.5 pl-9 pr-3 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-ring"
          />
        </div>
      </label>

      {pesoKg !== undefined && (
        <p className="text-xs text-muted-foreground">
          Peso <strong className="text-foreground">{pesoKg} kg</strong> — doses com mg/kg
          limpo aparecem convertidas em miligramas.
        </p>
      )}

      {lista.length === 0 ? (
        <p className="py-4 text-sm text-muted-foreground">
          Nenhum antimicrobiano corresponde a “{filtro}”.
        </p>
      ) : (
        <div className="space-y-2.5">
          {lista.map((d) => (
            <DrogaCard key={d.id} d={d} pesoKg={pesoKg} />
          ))}
        </div>
      )}
    </div>
  )
}

/** Converte a dose-normal em mg por dose e por dia, quando o peso permite. */
function converter(
  d: DosePediatrica,
  pesoKg: number,
): { porDose: Quantidade; porDia: Quantidade } | undefined {
  if (!d.pesoCalc) return undefined
  const { valor, base, intervaloHoras } = d.pesoCalc
  const dosesDia = 24 / intervaloHoras
  const aplica = (fn: (n: number) => number): Quantidade =>
    isFaixa(valor) ? [fn(valor[0]), fn(valor[1])] : fn(valor as number)

  if (base === 'dose') {
    const porDose = aplica((mgkg) => arredondarMg(mgkg * pesoKg))
    const porDia = aplica((mgkg) => arredondarMg(mgkg * pesoKg * dosesDia))
    return { porDose, porDia }
  }
  // base 'dia'
  const porDia = aplica((mgkg) => arredondarMg(mgkg * pesoKg))
  const porDose = aplica((mgkg) => arredondarMg((mgkg * pesoKg) / dosesDia))
  return { porDose, porDia }
}

function DrogaCard({ d, pesoKg }: { d: DosePediatrica; pesoKg?: number }) {
  const calc = pesoKg !== undefined ? converter(d, pesoKg) : undefined

  return (
    <div className="overflow-hidden rounded-md border border-border bg-secondary/30">
      <div className="border-b border-border bg-secondary/50 px-3 py-2">
        <div className="flex items-start gap-2">
          {d.restrito && <Lock className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden />}
          <div className="min-w-0">
            <h4 className="text-sm font-bold text-foreground">{d.nome}</h4>
            {d.classe && (
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
                {d.classe}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-2 px-3 py-2.5 text-sm">
        {d.restrito && (
          <p className="rounded border-l-2 border-destructive/60 bg-destructive/5 py-1 pl-2 text-xs text-foreground/90">
            <strong className="text-destructive">Uso restrito. </strong>
            {d.restrito}
          </p>
        )}

        {calc && (
          <div className="rounded-md border border-primary/40 bg-primary/10 p-2.5">
            <p className="kicker">Para {pesoKg} kg (clearance normal)</p>
            <p className="mt-0.5 text-base font-bold tabular-nums text-primary">
              {formatarMg(calc.porDose)}
              <span className="text-xs font-normal text-muted-foreground"> por dose</span>
            </p>
            <p className="text-xs text-muted-foreground">
              Total no dia: {formatarMg(calc.porDia)}
            </p>
          </div>
        )}

        <div>
          <p className="kicker mb-1">Dose por clearance</p>
          <ul className="space-y-0.5">
            {d.clearance.map((f) => (
              <li key={f.faixa} className="flex gap-2 text-[13px] leading-snug">
                <span className="min-w-[92px] shrink-0 font-semibold text-muted-foreground">
                  {f.faixa}
                </span>
                <span className="text-foreground/90">{f.dose}</span>
              </li>
            ))}
          </ul>
        </div>

        {d.neonatal && (
          <div>
            <p className="kicker mb-1">Neonatal</p>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[300px] border-collapse text-[12px]">
                <thead>
                  <tr className="text-left text-muted-foreground">
                    <th className="py-1 pr-2 font-semibold">Peso · idade</th>
                    <th className="py-1 pr-2 font-semibold">≤ 7 dias</th>
                    <th className="py-1 font-semibold">8–28 dias</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t border-border/60">
                    <td className="py-1 pr-2 font-semibold text-muted-foreground">≤ 2 kg</td>
                    <td className="py-1 pr-2 text-foreground/90">{d.neonatal.ate2kg.ate7d}</td>
                    <td className="py-1 text-foreground/90">{d.neonatal.ate2kg.d8a28}</td>
                  </tr>
                  <tr className="border-t border-border/60">
                    <td className="py-1 pr-2 font-semibold text-muted-foreground">&gt; 2 kg</td>
                    <td className="py-1 pr-2 text-foreground/90">{d.neonatal.acima2kg.ate7d}</td>
                    <td className="py-1 text-foreground/90">{d.neonatal.acima2kg.d8a28}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {d.neonatalNota && (
          <p className="text-xs leading-snug text-muted-foreground">{d.neonatalNota}</p>
        )}

        <p className="text-[11px] leading-snug text-muted-foreground">
          {d.apresentacao} · Diluição: {d.diluicao} · Infusão: {d.infusao}
        </p>

        {d.observacoes?.map((o, i) => (
          <p key={i} className="text-[11px] leading-snug text-muted-foreground">
            {o}
          </p>
        ))}

        {d.alerta && (
          <p className="flex items-start gap-1 rounded border-l-2 border-warning/60 bg-warning/5 py-1 pl-2 text-[11px] leading-snug text-foreground/90">
            <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-warning" aria-hidden />
            <span>{d.alerta}</span>
          </p>
        )}
      </div>
    </div>
  )
}
