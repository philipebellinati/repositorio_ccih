import type { ProtocolRule } from '@/domain/types'

/**
 * 6.2 — IRAS, ENFERMARIA ADULTO (página 3 do protocolo).
 *
 * "Tazocin" no documento original é o nome comercial de piperacilina/tazobactam;
 * o app prescreve pelo princípio ativo e registra o sinônimo no catálogo.
 */
export const SECAO_6_2: readonly ProtocolRule[] = [
  // --- Pneumonia hospitalar ------------------------------------------------
  {
    id: '6.2.pneumonia.aspirativa',
    secao: '6.2',
    focoId: 'pneumonia_hospitalar',
    condicaoLabel: 'Se aspirativa',
    // Sub-linha marcada com bullet no PDF: SUBSTITUI o esquema base, não soma.
    prioridade: 10,
    match: (m) => m.aspirativa === true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam 4,5g EV 8/8h',
  },
  {
    id: '6.2.pneumonia.base',
    secao: '6.2',
    focoId: 'pneumonia_hospitalar',
    condicaoLabel: 'Pneumonia hospitalar',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'O protocolo prevê faixa de 1 a 2 g sem definir o critério de escolha ' +
            '(ambiguidade A-04). Considerar gravidade, peso e função renal.',
        ],
      },
    ],
    textoOriginal: 'Cefepime 1-2g EV 8/8h',
  },

  // --- ITU hospitalar ------------------------------------------------------
  {
    id: '6.2.itu.base',
    secao: '6.2',
    focoId: 'itu',
    condicaoLabel: 'ITU hospitalar',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam 4,5g EV 8/8h',
  },

  // --- IPCS ----------------------------------------------------------------
  {
    id: '6.2.ipcs.base',
    secao: '6.2',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
    ],
    notas: ['n1'],
    textoOriginal: 'Vancomicina¹ + Cefepime 1-2g EV 8/8h',
  },

  // --- Infecção de prótese -------------------------------------------------
  {
    id: '6.2.protese.base',
    secao: '6.2',
    focoId: 'protese',
    condicaoLabel: 'Infecção de prótese',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
    ],
    notas: ['n1'],
    textoOriginal: 'Vancomicina¹ + Cefepime 1-2g EV 8/8h',
  },

  // --- ISC -----------------------------------------------------------------
  {
    id: '6.2.isc.base',
    secao: '6.2',
    focoId: 'isc',
    condicaoLabel: 'ISC',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    notas: ['n1'],
    textoOriginal: 'Vancomicina¹ + Piperacilina/tazobactam 4,5g EV 6/6h',
  },
]
