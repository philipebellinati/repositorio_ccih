/**
 * Alternativas SEM betalactâmico, por foco, para o paciente com alergia
 * verdadeira (reação grave ou IgE-mediada) a betalactâmicos.
 *
 * NATUREZA DESTE MÓDULO — ler antes de usar
 * O protocolo institucional NÃO descreve esquema substituto. Todo o conteúdo
 * aqui é PROPOSTA, construída a partir de literatura publicada (Sanford Guide;
 * diretrizes IDSA por sítio; artigos de stewardship de alergia), para discussão
 * e aprovação do SCIH. Enquanto não aprovado, a conduta no alérgico é
 * individualizada com o SCIH/Infectologia.
 *
 * PRINCÍPIO
 * Antes de trocar, estratificar a reação (ficha de alergia): ~90% dos rótulos
 * não se confirmam, e reação leve/tardia tolera cefalosporina/carbapenêmico. A
 * troca não betalactâmica é para reação grave ou IgE-mediada.
 *
 * `incerto: true` marca o foco em que NÃO há alternativa não betalactâmica
 * satisfatória — é onde o guia avisa, em vez de dar uma dose com falsa
 * segurança. Foi o pedido explícito: "o que você não encontrar, me avise".
 */

export interface AlternativaAlergia {
  /** Casa com o id do foco em `FOCOS`. */
  focoId: string
  /** Nome legível do foco. */
  foco: string
  /** Esquema proposto sem betalactâmico. Aceita marcação `__destaque__`/*itálico*. */
  esquema: string
  /** Ressalva clínica específica do foco. */
  ressalva?: string
  /**
   * Sem alternativa não betalactâmica confiável: o guia avisa e remete à
   * Infectologia, em vez de sugerir uma troca frágil.
   */
  incerto?: boolean
}

/**
 * Substituto direto de CADA betalactâmico do protocolo.
 *
 * A alternativa por FOCO responde "o que faço nesta infecção". Esta responde
 * "o que ponho no lugar DESTA droga" — que é a pergunta de quem está olhando
 * uma prescrição pronta e precisa trocar um item. As duas aparecem juntas no
 * modo alergia, porque uma não substitui a outra.
 *
 * Aztreonam é monobactâmico: não tem reatividade cruzada clinicamente
 * relevante com penicilinas, e por isso é a espinha dorsal da substituição de
 * Gram-negativo. A exceção é reação prévia a CEFTAZIDIMA, com quem compartilha
 * a cadeia lateral.
 */
export interface SubstitutoDireto {
  /** Casa com o `drugId` do catálogo. */
  drugId: string
  /** O que colocar no lugar. Aceita `__destaque__` e *itálico*. */
  substituto: string
  /** Por que esse substituto cobre o mesmo espectro. */
  razao?: string
}

export const SUBSTITUTOS_BETALACTAMICO: readonly SubstitutoDireto[] = [
  {
    drugId: 'ceftriaxona',
    substituto: '__Aztreonam__ + __vancomicina__, ou __levofloxacino__ em monoterapia',
    razao:
      'Aztreonam cobre o Gram-negativo; a vancomicina cobre o Gram-positivo que a ' +
      'ceftriaxona pegava. Na pneumonia, a quinolona respiratória resolve sozinha.',
  },
  {
    drugId: 'cefepime',
    substituto: '__Aztreonam__ (ou __ciprofloxacino__) + __vancomicina__ se houver risco de MRSA',
    razao: 'Aztreonam mantém a cobertura antipseudomonas que justifica o cefepime.',
  },
  {
    drugId: 'piperacilina_tazobactam',
    substituto: '__Aztreonam + metronidazol__, ou __ciprofloxacino + metronidazol__',
    razao:
      'O metronidazol repõe o anaeróbio que o tazobactam cobria; aztreonam ou ' +
      'ciprofloxacino repõem o Gram-negativo, incluindo *Pseudomonas*.',
  },
  {
    drugId: 'meropenem',
    substituto:
      '__Aztreonam + vancomicina__, associando __amicacina__ ou __ciprofloxacino__ ' +
      'conforme a gravidade; __metronidazol__ se houver foco abdominal',
    razao:
      'Nenhum agente isolado reproduz o espectro do carbapenêmico — a troca é ' +
      'uma combinação e deve passar pela Infectologia.',
  },
  {
    drugId: 'oxacilina',
    substituto: '__Vancomicina__; alternativas: __daptomicina__ (não em pulmão) ou __clindamicina__',
    razao: 'Alvo é o *S. aureus* sensível; o glicopeptídeo cobre MSSA e MRSA.',
  },
  {
    drugId: 'ampicilina',
    substituto: '__Vancomicina__ (inclusive para *Enterococcus*); no neonato, discutir com a Infectologia',
    razao:
      'A ampicilina entra sobretudo por *Enterococcus* e *Listeria*. Para *Listeria*, ' +
      'a alternativa é __sulfametoxazol/trimetoprima__.',
  },
]

/** Substituto direto de um fármaco, quando existir. */
export function substitutoDe(drugId: string): SubstitutoDireto | undefined {
  return SUBSTITUTOS_BETALACTAMICO.find((s) => s.drugId === drugId)
}

export const ALTERNATIVAS_ALERGIA: readonly AlternativaAlergia[] = [
  {
    focoId: 'pneumonia',
    foco: 'Pneumonia comunitária',
    esquema:
      '__Levofloxacino__ ou __moxifloxacino__ em monoterapia — cobrem típicos e ' +
      'atípicos.',
    ressalva: 'Moxifloxacino não cobre *Pseudomonas*; se houver risco, usar levofloxacino.',
  },
  {
    focoId: 'pneumonia_hospitalar',
    foco: 'Pneumonia hospitalar (não-VM)',
    esquema:
      '__Aztreonam__ (Gram-negativo, incl. *Pseudomonas*) ou __ciprofloxacino/' +
      'levofloxacino__, associado a __vancomicina__ ou __linezolida__ se houver ' +
      'risco de MRSA.',
    ressalva:
      'Aztreonam é monobactâmico, sem reatividade cruzada relevante — exceto se a ' +
      'reação prévia foi à ceftazidima. Discutir cobertura com o SCIH.',
  },
  {
    focoId: 'pnm_vm',
    foco: 'Pneumonia em UTI (PAV/PNAV)',
    esquema:
      '__Aztreonam + aminoglicosídeo__ (amicacina/gentamicina) para Gram-negativo/' +
      '*Pseudomonas*, associado a __vancomicina__ ou __linezolida__ para MRSA.',
    ressalva:
      'Esquema de exceção — acionar SCIH/Infectologia. Sem betalactâmico, a ' +
      'cobertura antipseudomonas fica mais frágil; considerar dessensibilização se ' +
      'a reação não for do tipo grave não IgE.',
    incerto: true,
  },
  {
    focoId: 'itu',
    foco: 'Infecção do trato urinário',
    esquema:
      '__Ciprofloxacino__ ou __aminoglicosídeo__ (gentamicina/amicacina); ' +
      '__aztreonam__ como alternativa.',
    ressalva: 'Na suspeita de ESBL, discutir com o SCIH — a fluoroquinolona pode falhar.',
  },
  {
    focoId: 'abdominal',
    foco: 'Infecção abdominal',
    esquema:
      '__Ciprofloxacino + metronidazol__ — o próprio protocolo já traz esse esquema ' +
      'como 2ª opção. Alternativa: __aztreonam + metronidazol__.',
  },
  {
    focoId: 'tgi',
    foco: 'Infecção do TGI (IRAS)',
    esquema: '__Ciprofloxacino + metronidazol__ ou __aztreonam + metronidazol__.',
  },
  {
    focoId: 'pele_partes_moles',
    foco: 'Pele e partes moles',
    esquema:
      '__Vancomicina__ (MRSA); __clindamicina__ agrega ação antitoxina. Na forma ' +
      'necrosante, __clindamicina + ciprofloxacino__.',
    ressalva: 'Alternativas a vancomicina: linezolida ou daptomicina (esta, não em pulmão).',
  },
  {
    focoId: 'sepse_sem_foco',
    foco: 'Sepse sem foco',
    esquema:
      '__Vancomicina + aztreonam__, com __aminoglicosídeo__ ou __ciprofloxacino__ ' +
      'conforme a gravidade e o risco de *Pseudomonas*.',
    ressalva: 'Amplo, porém frágil sem betalactâmico — acionar SCIH/Infectologia precocemente.',
    incerto: true,
  },
  {
    focoId: 'meningite',
    foco: 'Meningite bacteriana',
    esquema:
      '__Vancomicina + moxifloxacino__ (penetração no SNC) — considerar ' +
      '__sulfametoxazol/trimetoprima__ se houver risco de *Listeria* (neonato, ' +
      '> 50 anos, imunossupressão).',
    ressalva:
      'Situação de exceção — acionar a Infectologia imediatamente. Nenhum substituto ' +
      'não betalactâmico cobre bem *S. pneumoniae* e *N. meningitidis* no SNC; a ' +
      'DESSENSIBILIZAÇÃO à ceftriaxona é preferível quando a reação não for grave não IgE.',
    incerto: true,
  },
  {
    focoId: 'endocardite',
    foco: 'Endocardite aguda',
    esquema:
      '__Vancomicina__ para Gram-positivo, com __gentamicina__ em dose de sinergismo ' +
      '(1 mg/kg 8/8h). __Daptomicina__ é alternativa em bacteremia/endocardite direita.',
    ressalva: 'Definir agente e esquema com a Infectologia — a etiologia muda a escolha.',
  },
  {
    focoId: 'osteoarticular',
    foco: 'Infecção óssea / articular',
    esquema:
      '__Vancomicina__ ou __daptomicina__ ou __clindamicina__ (Gram-positivo), ' +
      'associando __ciprofloxacino/levofloxacino__ se houver Gram-negativo.',
    ressalva: 'Terapia prolongada — conduzir com Ortopedia e Infectologia.',
  },
  {
    focoId: 'ipcs',
    foco: 'IPCS / ICS-CVC',
    esquema:
      '__Vancomicina__ (cateter, Gram-positivo) associada a __aztreonam__, ' +
      '__aminoglicosídeo__ ou __ciprofloxacino__ para Gram-negativo.',
    ressalva: 'Avaliar remoção do cateter. Ajustar após hemoculturas.',
  },
  {
    focoId: 'protese',
    foco: 'Infecção de prótese',
    esquema:
      '__Vancomicina + ciprofloxacino/levofloxacino__; __rifampicina__ como ' +
      'adjuvante quando há biofilme em material, conforme a Infectologia.',
    ressalva:
      'Decisão conjunta com Ortopedia/Infectologia e cirurgia de controle de foco — ' +
      'esquema e duração dependem do material e da retenção do implante.',
    incerto: true,
  },
  {
    focoId: 'isc',
    foco: 'Infecção de sítio cirúrgico',
    esquema:
      '__Vancomicina__ (Gram-positivo de pele) associada, conforme o sítio operado, ' +
      'a __ciprofloxacino__ e/ou __metronidazol__ (cirurgia abdominal/colorretal).',
    ressalva: 'O sítio cirúrgico define os agentes prováveis — individualizar com o SCIH.',
  },
]
