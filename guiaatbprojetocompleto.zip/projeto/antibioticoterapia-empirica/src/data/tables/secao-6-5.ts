import type { ProtocolRule } from '@/domain/types'

/**
 * 6.5 — IRAS, UTI ADULTO (página 4 do protocolo).
 *
 * É a tabela com a árvore de decisão mais profunda: pneumonia se ramifica por
 * ventilação mecânica e tempo de VM; ITU e IPCS se ramificam pela presença de
 * dispositivo invasivo. Todo escalonamento para carbapenêmico está aqui.
 */
export const SECAO_6_5: readonly ProtocolRule[] = [
  // --- Pneumonia: PNAV / PAV precoce / PAV tardia --------------------------
  {
    id: '6.5.pnm.pav-tardia',
    secao: '6.5',
    focoId: 'pnm_vm',
    condicaoLabel: 'PAV Tardia (≥ 5 dias)',
    // Maior prioridade da seção: VM prolongada é o principal preditor local de
    // Gram-negativo multirresistente → carbapenêmico.
    //
    // O documento grafa "< 5" e "> 5", deixando o 5º dia sem regra. Por
    // definição do SCIH, o dia 5 é TARDIA — o limiar passa a ser ≥ 5.
    prioridade: 40,
    match: (m) => typeof m.diasVentilacaoMecanica === 'number' && m.diasVentilacaoMecanica >= 5,
    prescricoes: [
      { drugId: 'meropenem', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q8h' },
    ],
    textoOriginal: 'Meropenem 2g EV 8/8h',
  },
  {
    id: '6.5.pnm.pav-precoce-aspirativa',
    secao: '6.5',
    focoId: 'pnm_vm',
    condicaoLabel: 'PAV Precoce (< 5 dias) — Aspirativa',
    prioridade: 35,
    match: (m) =>
      typeof m.diasVentilacaoMecanica === 'number' &&
      m.diasVentilacaoMecanica < 5 &&
      m.aspirativa === true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam EV 4,5g 6/6h',
  },
  {
    id: '6.5.pnm.pav-precoce',
    secao: '6.5',
    focoId: 'pnm_vm',
    condicaoLabel: 'PAV Precoce (< 5 dias)',
    prioridade: 30,
    match: (m) => typeof m.diasVentilacaoMecanica === 'number' && m.diasVentilacaoMecanica < 5,
    prescricoes: [
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
    ],
    textoOriginal: 'Cefepime 1-2g EV 8/8h',
  },
  {
    id: '6.5.pnm.nao-vm-aspirativa',
    secao: '6.5',
    focoId: 'pnm_vm',
    condicaoLabel: 'PNM não associada a VM — Aspirativa',
    prioridade: 20,
    match: (m) => m.diasVentilacaoMecanica === undefined && m.aspirativa === true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam EV 4,5g 8/8h',
  },
  {
    id: '6.5.pnm.nao-vm',
    secao: '6.5',
    focoId: 'pnm_vm',
    condicaoLabel: 'PNM não associada a VM',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
    ],
    textoOriginal: 'Cefepime 1-2g EV 8/8h',
  },

  // --- ITU -----------------------------------------------------------------
  {
    id: '6.5.itu.cateter',
    secao: '6.5',
    focoId: 'itu',
    condicaoLabel: 'ITU assoc. a cateter vesical',
    prioridade: 10,
    match: (m) => m.dispositivoInvasivo === true,
    prescricoes: [
      { drugId: 'meropenem', doseFixa: { valor: 2, unidade: 'g' }, via: 'EV', intervalo: 'q8h' },
    ],
    textoOriginal: 'Meropenem 2g EV 8/8h',
  },
  {
    id: '6.5.itu.sem-dispositivo',
    secao: '6.5',
    focoId: 'itu',
    condicaoLabel: 'ITU não assoc. a dispositivos',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam EV 4,5g 6/6h',
  },

  // --- IPCS ----------------------------------------------------------------
  {
    id: '6.5.ipcs.cvc',
    secao: '6.5',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS assoc. a cateter (CVC)',
    prioridade: 10,
    match: (m) => m.dispositivoInvasivo === true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
    ],
    notas: ['n1'],
    textoOriginal: 'Vancomicina¹ + Cefepime 1-2g EV 8/8h',
  },
  {
    id: '6.5.ipcs.sem-dispositivo',
    secao: '6.5',
    focoId: 'ipcs',
    condicaoLabel: 'IPCS não assoc. a dispositivos',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
    ],
    textoOriginal: 'Cefepime 1-2g EV 8/8h',
  },

  // --- Infecção do TGI -----------------------------------------------------
  {
    id: '6.5.tgi.base',
    secao: '6.5',
    focoId: 'tgi',
    condicaoLabel: 'Infecção TGI',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam 4,5g EV 6/6h',
  },

  // --- ISC -----------------------------------------------------------------
  {
    id: '6.5.isc.base',
    secao: '6.5',
    focoId: 'isc',
    condicaoLabel: 'ISC',
    // O documento não traz ISC na tabela de UTI adulto. Por definição do SCIH,
    // adota-se aqui o mesmo esquema da enfermaria adulto (item 6.2).
    prioridade: 0,
    match: () => true,
    prescricoes: [
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    notas: ['n1'],
    textoOriginal: 'Vancomicina¹ + Piperacilina/tazobactam 4,5g EV 6/6h (adotado do item 6.2)',
  },

  // --- Sepse sem foco determinado ------------------------------------------
  {
    id: '6.5.sepse.enterococcus',
    secao: '6.5',
    focoId: 'sepse_sem_foco',
    condicaoLabel: 'Se Enterococcus / anaeróbio',
    // Cefepime não cobre Enterococcus nem anaeróbios → troca por pip/tazo.
    prioridade: 10,
    match: (m) => m.suspeitaEnterococcusAnaerobio === true,
    prescricoes: [
      {
        drugId: 'piperacilina_tazobactam',
        doseFixa: { valor: 4.5, unidade: 'g' },
        via: 'EV',
        intervalo: 'q6h',
        observacoes: [
          'A cada 6 h em sepse, choque séptico, infecção abdominal e Pseudomonas. ' +
            'A cada 8 h nas infecções não graves.',
        ],
      },
    ],
    textoOriginal: 'Piperacilina/tazobactam EV 4,5g 6/6h',
  },
  {
    id: '6.5.sepse.base',
    secao: '6.5',
    focoId: 'sepse_sem_foco',
    condicaoLabel: 'Sepse sem foco determinado',
    prioridade: 0,
    match: () => true,
    prescricoes: [
      {
        drugId: 'cefepime',
        doseFixa: { valor: [1, 2], unidade: 'g' },
        via: 'EV',
        intervalo: 'q8h',
        observacoes: [
          'Usar 2 g em Pseudomonas, meningite, neutropenia febril e sepse/choque ' +
            'séptico. Nas demais situações, 1 g.',
        ],
      },
      { drugId: 'vancomicina', via: 'EV', intervalo: 'q12h' },
    ],
    notas: ['n1'],
    textoOriginal: 'Cefepime 1-2g EV 8/8h + Vancomicina¹',
  },
]
