import { useMemo, useState } from 'react'
import { AlertTriangle } from 'lucide-react'
import {
  ckdEpi,
  cockcroftGault,
  pesoAjustado,
  pesoIdealDevine,
  superficieCorporal,
  validarEntradaRenal,
  type Sexo,
} from '@/domain/renal'
import { AJUSTE_RENAL, faixaAplicavel, type AjusteFarmaco } from '@/data/ajuste-renal'
import { normalizar } from '@/lib/utils'
import { formatarNumero } from '@/domain/dosing'
import { converterDosePonderal } from '@/domain/dose-ponderal'
import { Callout } from './ui/primitives'
import { cn } from '@/lib/utils'

/**
 * Calculadora de função renal e de peso de referência.
 *
 * Devolve CKD-EPI e Cockcroft-Gault lado a lado de propósito. As tabelas
 * institucionais de ajuste foram construídas sobre ClCr (Cockcroft-Gault), e
 * o CKD-EPI sai indexado por 1,73 m² — então o app mostra os dois e usa
 * explicitamente o valor ABSOLUTO para escolher a faixa de dose.
 */

function Campo({
  rotulo,
  valor,
  onChange,
  sufixo,
  step = '1',
  placeholder,
}: {
  rotulo: string
  valor: number | undefined
  onChange: (v: number | undefined) => void
  sufixo: string
  step?: string
  placeholder?: string
}) {
  return (
    <label className="block">
      <span className="kicker">{rotulo}</span>
      <div className="mt-1 flex items-center gap-1.5">
        <input
          type="number"
          inputMode="decimal"
          step={step}
          value={valor ?? ''}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value === '' ? undefined : Number(e.target.value))}
          aria-label={rotulo}
          className="w-full rounded-md border border-border bg-input px-2.5 py-2 text-base font-semibold text-foreground outline-none focus:border-primary focus:ring-1 focus:ring-ring"
        />
        <span className="shrink-0 text-xs text-muted-foreground">{sufixo}</span>
      </div>
    </label>
  )
}

export function CalculadoraRenal() {
  const [creatinina, setCreatinina] = useState<number | undefined>(undefined)
  const [idade, setIdade] = useState<number | undefined>(undefined)
  const [peso, setPeso] = useState<number | undefined>(undefined)
  const [altura, setAltura] = useState<number | undefined>(undefined)
  const [sexo, setSexo] = useState<Sexo | undefined>(undefined)
  const [farmacoAberto, setFarmacoAberto] = useState<string | null>(null)
  const [filtro, setFiltro] = useState('')

  const entrada = {
    ...(creatinina !== undefined ? { creatininaMgDl: creatinina } : {}),
    ...(idade !== undefined ? { idadeAnos: idade } : {}),
    ...(peso !== undefined ? { pesoKg: peso } : {}),
    ...(altura !== undefined ? { alturaCm: altura } : {}),
    ...(sexo ? { sexo } : {}),
  }
  const erros = validarEntradaRenal(entrada)
  const completo = erros.length === 0

  const calculo = useMemo(() => {
    if (!completo || creatinina === undefined || idade === undefined) return null
    if (peso === undefined || altura === undefined || !sexo) return null

    const ideal = pesoIdealDevine(altura, sexo)
    const ajustado = pesoAjustado(peso, ideal)
    return {
      ckd: ckdEpi(creatinina, idade, sexo, peso, altura),
      cg: cockcroftGault(creatinina, idade, sexo, ajustado),
      cgPesoReal: cockcroftGault(creatinina, idade, sexo, peso),
      pesoIdeal: ideal,
      pesoAjustado: ajustado,
      sc: superficieCorporal(peso, altura),
    }
  }, [completo, creatinina, idade, peso, altura, sexo])

  // A faixa de dose é escolhida pelo ClCr ABSOLUTO. Cockcroft-Gault com peso
  // ajustado é a referência das tabelas institucionais.
  const clcrParaTabela = calculo?.cg.absoluto

  /**
   * Peso a usar no cálculo ponderal de cada fármaco.
   *
   * A tabela institucional exige peso AJUSTADO para os aminoglicosídeos e peso
   * ATUAL para os demais. Errar essa escolha muda a dose de forma relevante no
   * paciente obeso — por isso o peso usado é sempre exibido junto do resultado.
   */
  const pesoDeCalculo = (f: AjusteFarmaco): { kg: number; rotulo: string } | undefined => {
    if (!calculo || peso === undefined) return undefined
    if (f.pesoDeReferencia === 'ajustado') return { kg: calculo.pesoAjustado, rotulo: 'ajustado' }
    if (f.pesoDeReferencia === 'ideal') return { kg: calculo.pesoIdeal, rotulo: 'ideal' }
    // Sem exigência declarada, a convenção é o peso real.
    return { kg: peso, rotulo: 'real' }
  }

  // Ordem: primeiro os fármacos que o protocolo empírico prescreve — são os que
  // o plantonista busca —, depois o restante da tabela institucional.
  const visiveis: AjusteFarmaco[] = useMemo(() => {
    const termo = normalizar(filtro)
    const casa = (f: AjusteFarmaco) =>
      termo === '' || normalizar(f.nome).includes(termo) || normalizar(f.id).includes(termo)
    const peso = (f: AjusteFarmaco) => (f.noProtocolo ? 0 : 1)
    return AJUSTE_RENAL.filter(casa).sort(
      (a, b) => peso(a) - peso(b) || a.nome.localeCompare(b.nome, 'pt-BR'),
    )
  }, [filtro])

  return (
    <div className="space-y-4 px-4 py-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Campo rotulo="Creatinina" valor={creatinina} onChange={setCreatinina} sufixo="mg/dL" step="0.01" placeholder="1,0" />
        <Campo rotulo="Idade" valor={idade} onChange={setIdade} sufixo="anos" placeholder="65" />
        <Campo rotulo="Peso" valor={peso} onChange={setPeso} sufixo="kg" step="0.1" placeholder="70" />
        <Campo rotulo="Altura" valor={altura} onChange={setAltura} sufixo="cm" placeholder="170" />

        <div className="col-span-2 sm:col-span-1">
          <span className="kicker">Sexo</span>
          <div className="mt-1 flex gap-2">
            {(['M', 'F'] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSexo(s)}
                aria-pressed={sexo === s}
                className={cn(
                  'flex-1 rounded-md border py-2 text-sm font-bold transition-colors',
                  sexo === s
                    ? 'border-primary bg-primary/15 text-primary'
                    : 'border-border bg-secondary/60 text-muted-foreground hover:bg-secondary',
                )}
              >
                {s === 'M' ? 'Masc.' : 'Fem.'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {!completo && (
        <p className="text-sm text-muted-foreground">
          Preencha todos os campos para calcular. {erros[0]}
        </p>
      )}

      {calculo && (
        <>
          {/* ---- Resultados ---- */}
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <div className="rounded-md border border-primary/40 bg-primary/10 p-3">
              <p className="kicker">Cockcroft-Gault · peso ajustado</p>
              <p className="mt-1 text-2xl font-bold tabular-nums text-primary">
                {formatarNumero(calculo.cg.absoluto)}{' '}
                <span className="text-sm font-normal">mL/min</span>
              </p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                É este valor que o guia usa nas tabelas de ajuste
              </p>
            </div>

            <div className="rounded-md border border-border bg-secondary/40 p-3">
              <p className="kicker">CKD-EPI 2021</p>
              <p className="mt-1 text-2xl font-bold tabular-nums text-foreground">
                {formatarNumero(calculo.ckd.indexado)}{' '}
                <span className="text-sm font-normal">mL/min/1,73m²</span>
              </p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">
                Desindexado: {formatarNumero(calculo.ckd.absoluto)} mL/min · SC{' '}
                {formatarNumero(calculo.sc)} m²
              </p>
            </div>
          </div>

          <Callout severidade="atencao" titulo="CKD-EPI não é intercambiável com ClCr">
            O CKD-EPI estima a TFG <strong>normalizada para 1,73 m²</strong>, enquanto as
            tabelas de ajuste de antimicrobianos foram construídas sobre o ClCr absoluto
            de Cockcroft-Gault. Usar o valor indexado direto na tabela subdosa o paciente
            grande e superdosa o pequeno. Para estadiamento de doença renal use o
            indexado; para <strong>escolher dose</strong>, o absoluto.
          </Callout>

          {/* ---- Pesos ---- */}
          <div className="rounded-md border border-border bg-secondary/40 p-3">
            <p className="kicker mb-2">Pesos de referência</p>
            <dl className="grid grid-cols-3 gap-2 text-sm">
              <div>
                <dt className="text-xs text-muted-foreground">Real</dt>
                <dd className="font-semibold text-foreground">{formatarNumero(peso!)} kg</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Ideal (Devine)</dt>
                <dd className="font-semibold text-foreground">
                  {formatarNumero(calculo.pesoIdeal)} kg
                </dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Ajustado</dt>
                <dd className="font-semibold text-primary">
                  {formatarNumero(calculo.pesoAjustado)} kg
                </dd>
              </div>
            </dl>
            <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
              Pajustado = Pideal + 0,4 × (Patual − Pideal). É o peso exigido pela tabela
              institucional para <strong>amicacina e gentamicina</strong>. A fórmula de peso
              ideal segue a fórmula de Devine, adotada como padrão institucional.
            </p>
          </div>

          {/* ---- Ajuste por fármaco ---- */}
          <div>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <p className="kicker">Ajuste por fármaco</p>
              <input
                type="search"
                value={filtro}
                onChange={(e) => setFiltro(e.target.value)}
                placeholder="Filtrar fármaco"
                aria-label="Filtrar fármaco na tabela de ajuste"
                className="w-40 rounded-md border border-border bg-input px-2.5 py-1.5 text-xs text-foreground outline-none placeholder:text-muted-foreground focus:border-primary"
              />
            </div>
            <div className="space-y-2">
              {visiveis.map((f) => {
                const aberto = farmacoAberto === f.id
                return (
                  <div key={f.id} className="overflow-hidden rounded-md border border-border">
                    <button
                      type="button"
                      onClick={() => setFarmacoAberto(aberto ? null : f.id)}
                      aria-expanded={aberto}
                      className="flex w-full items-center justify-between gap-2 bg-secondary/50 px-3 py-2.5 text-left hover:bg-secondary"
                    >
                      <span className="flex min-w-0 items-center gap-2">
                        <span className="truncate text-sm font-bold text-foreground">
                          {f.nome}
                        </span>
                        {f.noProtocolo && (
                          <span className="shrink-0 rounded border border-primary/40 bg-primary/15 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-primary">
                            no protocolo
                          </span>
                        )}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {f.semAjuste
                          ? 'sem ajuste renal'
                          : clcrParaTabela !== undefined && f.esquemas[0]
                            ? (faixaAplicavel(f.esquemas[0], clcrParaTabela)?.dose ?? 'ver faixas')
                            : 'ver faixas'}
                      </span>
                    </button>

                    {aberto && (
                      <div className="space-y-3 px-3 py-3">
                        {f.doseHabitual && (
                          <p className="text-sm">
                            <span className="kicker">Dose habitual</span>
                            <br />
                            <span className="text-foreground/90">{f.doseHabitual}</span>
                          </p>
                        )}

                        {f.doseAtaque && (
                          <p className="text-sm">
                            <span className="kicker">Dose de ataque</span>
                            <br />
                            <span className="text-foreground/90">{f.doseAtaque}</span>
                          </p>
                        )}

                        {(() => {
                          const pr = pesoDeCalculo(f)
                          const temPonderal =
                            f.esquemas.some((e) =>
                              e.faixas.some((fx) => /mg\s*\/\s*kg/i.test(fx.dose)),
                            ) || /mg\s*\/\s*kg/i.test(f.doseAtaque ?? '')
                          if (!pr || !temPonderal) return null
                          const ataque = f.doseAtaque
                            ? converterDosePonderal(f.doseAtaque, pr.kg)
                            : undefined
                          return (
                            <div className="rounded border border-primary/40 bg-primary/10 px-2.5 py-2 text-sm">
                              <p className="text-primary">
                                Cálculo com peso <strong>{pr.rotulo}</strong> ={' '}
                                <strong>{formatarNumero(pr.kg)} kg</strong>
                              </p>
                              {ataque && (
                                <p className="mt-0.5 text-foreground/90">
                                  Ataque {ataque.texto.replace('= ', '')}
                                </p>
                              )}
                            </div>
                          )
                        })()}

                        {f.esquemas.map((esq, i) => {
                          const faixa =
                            clcrParaTabela !== undefined
                              ? faixaAplicavel(esq, clcrParaTabela)
                              : undefined
                          return (
                            <div key={i} className="rounded border border-border/70 p-2.5">
                              <p className="text-xs font-bold uppercase tracking-wider text-primary">
                                {esq.partida}
                              </p>
                              {esq.indicacao && (
                                <p className="mt-0.5 text-[11px] text-muted-foreground">
                                  {esq.indicacao}
                                </p>
                              )}
                              <ul className="mt-2 space-y-1">
                                {esq.faixas.map((fx) => {
                                  const pr = pesoDeCalculo(f)
                                  const emMg = pr
                                    ? converterDosePonderal(fx.dose, pr.kg)
                                    : undefined
                                  return (
                                    <li
                                      key={fx.rotulo}
                                      className={cn(
                                        'flex gap-2 rounded px-2 py-1 text-sm',
                                        faixa === fx
                                          ? 'bg-primary/20 font-semibold text-primary'
                                          : 'text-foreground/85',
                                      )}
                                    >
                                      <span className="w-16 shrink-0 tabular-nums">{fx.rotulo}</span>
                                      <span>
                                        {fx.dose}
                                        {emMg && (
                                          <span
                                            className={cn(
                                              'ml-1.5 font-bold',
                                              faixa === fx ? 'text-primary' : 'text-foreground',
                                            )}
                                          >
                                            {emMg.texto}
                                          </span>
                                        )}
                                      </span>
                                    </li>
                                  )
                                })}
                              </ul>
                              {esq.hemodialise && (
                                <p className="mt-2 text-xs text-muted-foreground">
                                  <strong>Hemodiálise:</strong> {esq.hemodialise}
                                </p>
                              )}
                              {clcrParaTabela !== undefined && !faixa && esq.faixas.length > 0 && (
                                <p className="mt-2 flex items-center gap-1.5 text-xs text-warning">
                                  <AlertTriangle className="h-3.5 w-3.5 shrink-0" aria-hidden />
                                  A tabela institucional não define conduta para este
                                  clearance — confirmar com a Farmácia Clínica.
                                </p>
                              )}
                            </div>
                          )
                        })}

                        {(f.observacoes ?? []).map((o, i) => (
                          <p key={i} className="text-xs leading-relaxed text-muted-foreground">
                            {o}
                          </p>
                        ))}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
